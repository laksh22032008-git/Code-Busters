import subprocess, json, re, html, sys
API = "https://commons.wikimedia.org/w/api.php"
UA = "ResQFood-photo-search/1.0 (local dev project)"
def search(term):
    cmd = ["curl","-s","-A",UA,"-G",API,"--data-urlencode",f"gsrsearch={term}",
      "-d","action=query","-d","generator=search","-d","gsrnamespace=6","-d","gsrlimit=10",
      "-d","prop=imageinfo","-d","iiprop=url|size|extmetadata|mime","-d","iiurlwidth=1200","-d","format=json"]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        print("  curl error", r.returncode, r.stderr.strip()); return
    try: data = json.loads(r.stdout)
    except Exception as e: print("  json error", e, r.stdout[:200]); return
    pages = data.get("query",{}).get("pages",{})
    for p in sorted(pages.values(), key=lambda p: p.get("index",99)):
        ii = (p.get("imageinfo") or [None])[0]
        if not ii: continue
        meta = lambda k: html.unescape(re.sub(r"<[^>]+>","",ii.get("extmetadata",{}).get(k,{}).get("value",""))).strip()
        print(f"  {ii.get('mime')} {ii.get('width')}x{ii.get('height')} | {meta('LicenseShortName')} | {p.get('title')} | {ii.get('descriptionurl')}")
for term in sys.argv[1:]:
    print("== search:", term); search(term)
