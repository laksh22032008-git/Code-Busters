import subprocess, json, re, html, sys
API = "https://commons.wikimedia.org/w/api.php"
UA = "ResQFood-photo-search/1.0 (local dev project)"
OK = re.compile(r"^(CC0|Public domain|CC BY(-SA)? \d(\.\d)?)$", re.I)
for term in sys.argv[1:]:
    cmd = ["curl","-s","-A",UA,"-G",API,"--data-urlencode",f"gsrsearch={term}",
      "-d","action=query","-d","generator=search","-d","gsrnamespace=6","-d","gsrlimit=20",
      "-d","prop=imageinfo","-d","iiprop=url|size|extmetadata|mime","-d","iiurlwidth=1200","-d","format=json"]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0: print("CURL ERROR", term, r.returncode, r.stderr.strip()); continue
    pages = json.loads(r.stdout).get("query",{}).get("pages",{})
    print("== ", term)
    for p in sorted(pages.values(), key=lambda p: p.get("index",99)):
        ii = (p.get("imageinfo") or [None])[0]
        if not ii or ii.get("mime") != "image/jpeg": continue
        w, h = ii["width"], ii["height"]
        lic = html.unescape(re.sub(r"<[^>]+>","",ii.get("extmetadata",{}).get("LicenseShortName",{}).get("value",""))).strip()
        if w < h or not OK.match(lic): continue
        print(f"  {w}x{h} {lic} {p['title'][5:75]}")
