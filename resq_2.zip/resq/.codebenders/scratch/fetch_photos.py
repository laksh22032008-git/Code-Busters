import subprocess, json, os, re, html, sys
OUT = "public/food/photos"
SPECS = [
 ("pulao","vegetable pulao rice"),("paneer-meal","paneer curry rice meal"),
 ("biryani","chicken biryani"),("veg-biryani","vegetable biryani"),
 ("chapati-curry","chapati curry roti"),("rice-thali","south indian thali meal"),
 ("sandwich","sandwich food"),("bakery","bakery bread loaves"),
 ("croissant","croissant pastry"),("idli-dosa","idli dosa south indian"),
 ("millet-bowl","millet bowl healthy food"),("chicken-wrap","chicken wrap"),
]
API = "https://commons.wikimedia.org/w/api.php"
UA = "ResQFood-photo-fetch/1.0 (local dev project)"
BAD_TITLE = re.compile(r"logo|map|diagram|drawing|illustration|icon|svg|flag|chart", re.I)
def curl_json(term):
    cmd = ["curl","-s","-A",UA,"-G",API,"--data-urlencode",f"gsrsearch={term}",
      "-d","action=query","-d","generator=search","-d","gsrnamespace=6","-d","gsrlimit=8",
      "-d","prop=imageinfo","-d","iiprop=url|size|extmetadata|mime","-d","iiurlwidth=1200","-d","format=json"]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0: return None, f"curl exit {r.returncode}: {r.stderr.strip()}"
    try: return json.loads(r.stdout), None
    except Exception as e: return None, f"json error: {e}; head={r.stdout[:200]!r}"
def licence_ok(name):
    n = name.upper()
    if "NC" in n.split() or "-NC" in n or "NC-" in n or " NC" in n or "ND" in n.replace("-",' ').split(): return False
    return n.startswith("CC0") or "PUBLIC DOMAIN" in n or n.startswith("PUBLIC DOMAIN") or re.match(r"^CC BY(-SA)?(\s|$|\d)", n) is not None or n.startswith("CC BY")
def meta(ii, key):
    v = ii.get("extmetadata",{}).get(key,{}).get("value","")
    return html.unescape(re.sub(r"<[^>]+>","",v)).strip()
def candidates(term):
    data, err = curl_json(term)
    if err: print("  API ERROR:", err); return []
    pages = (data or {}).get("query",{}).get("pages",{})
    out = []
    for p in sorted(pages.values(), key=lambda p: p.get("index",99)):
        ii = (p.get("imageinfo") or [None])[0]
        if not ii: continue
        title = p.get("title","")
        if ii.get("mime") != "image/jpeg": continue
        if ii.get("width",0) < ii.get("height",0): continue
        if BAD_TITLE.search(title): continue
        lic = meta(ii,"LicenseShortName")
        if not licence_ok(lic): 
            print(f"  reject licence '{lic}': {title}"); continue
        thumb = ii.get("thumburl") or ii.get("url")
        out.append(dict(title=title, thumb=thumb, lic=lic, artist=meta(ii,"Artist") or "unknown", page=ii.get("descriptionurl")))
    return out
results = {}
for slug, term in SPECS:
    print(f"== {slug}: '{term}'")
    cands = candidates(term)
    if not cands and term:
        print("  no candidates")
    ok = False; attempts = 0
    for c in cands:
        if attempts >= 3: break
        attempts += 1
        dest = os.path.join(OUT, slug + ".jpg")
        r = subprocess.run(["curl","-L","-sS","-A",UA,"-o",dest,c["thumb"]], capture_output=True, text=True)
        if r.returncode != 0:
            print(f"  curl error {r.returncode}: {r.stderr.strip()}"); continue
        ft = subprocess.run(["file","-b",dest],capture_output=True,text=True).stdout.strip()
        size = os.path.getsize(dest)
        print(f"  try {attempts}: {c['title']} | {c['lic']} | {ft} | {size} bytes")
        if "JPEG" in ft and size > 30*1024:
            ok = True
            results[slug] = dict(c, file=slug+".jpg", size=size)
            break
        else:
            os.remove(dest)
    if not ok: print(f"  SKIPPED {slug}")
    results.setdefault(slug, None) if not ok else None
json.dump({k:v for k,v in results.items()}, open(".codebenders/scratch/results.json","w"), indent=1, ensure_ascii=False)
print("OK count:", sum(1 for v in results.values() if v))
