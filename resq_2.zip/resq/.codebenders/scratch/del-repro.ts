import { deleteListing, seedProviderState } from '/Users/koushalkn/Desktop/resq/src/provider/store.ts';
import { providerListingViews } from '/Users/koushalkn/Desktop/resq/src/provider/derive.ts';
import { getListings } from '/Users/koushalkn/Desktop/resq/src/data/listings.ts';

const now = Date.now();
const state = seedProviderState(now);
for (const view of providerListingViews(state, now)) {
  const id = view.record.id;
  const r = deleteListing(state, id, getListings(now), now);
  console.log(JSON.stringify({ id, status: view.status, ok: r.ok, error: r.ok ? null : r.error }));
}
