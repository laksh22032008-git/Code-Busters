/**
 * Reservation workflow check: post 20 portions, claim 4, assert remaining 16, reject a duplicate
 * claim, reject a claim of 17, cancel, assert remaining 20, reject a claim after the deadline.
 *
 * Run with: npx tsx scripts/workflow-check.ts
 */
import assert from 'node:assert/strict';
import {
  cancelClaim,
  claimListing,
  postListing,
  providerListingViews,
  seedProviderState,
} from '../src/provider/store';
import type { PostListingInput, ProviderState, Result } from '../src/provider/types';
import { MAX_PORTIONS_PER_CLAIM } from '../src/lib/reservation';

const MIN = 60 * 1000;
const DEMO = 'Demo seeker';
const DUPLICATE_MESSAGE =
  'You already have an active claim on this listing. Cancel it before claiming again.';

let failures = 0;

function check(label: string, fn: () => void): void {
  try {
    fn();
    console.log(`PASS ${label}`);
  } catch (error) {
    failures += 1;
    console.log(`FAIL ${label}: ${error instanceof Error ? error.message : String(error)}`);
  }
}

function errorOf(result: Result<unknown>): string {
  return result.ok ? '' : result.error;
}

function remainingOf(state: ProviderState, listingId: string, now: number): number {
  const view = providerListingViews(state, now).find((item) => item.record.id === listingId);
  return view?.portionsRemaining ?? -1;
}

function listingInput(portions: number, now: number): PostListingInput {
  return {
    name: 'Workflow Check Meal Box',
    category: 'Meals',
    isVeg: true,
    portions,
    isFree: false,
    price: 50,
    originalPrice: 150,
    allocation: 'open',
    pickupStart: new Date(now + 30 * MIN).toISOString(),
    pickupDeadline: new Date(now + 120 * MIN).toISOString(),
    area: '',
    handling: { preparedAt: '', storage: '', reheating: '', providerNote: '' },
    allergens: [],
    image: '/food/photos/pulao.jpg',
  };
}

async function main(): Promise<void> {
  const now = Date.now();
  const seeded = seedProviderState(now);
  const posted = postListing(seeded, listingInput(MAX_PORTIONS_PER_CLAIM, now), now);
  if (!posted.ok || !posted.value) {
    console.log(`FAIL post 20-portion listing: ${posted.ok ? 'no record returned' : posted.error}`);
    process.exitCode = 1;
    return;
  }
  const listingId = posted.value.id;
  const deadlineMs = Date.parse(posted.value.pickupDeadline);
  let state: ProviderState = posted.state;
  check('post 20-portion listing starts with 20 remaining', () =>
    assert.equal(remainingOf(state, listingId, now), MAX_PORTIONS_PER_CLAIM),
  );

  const first = claimListing(state, [], listingId, 4, DEMO, now);
  check('claim 4 portions succeeds', () => assert.equal(first.ok, true, errorOf(first)));
  if (first.ok) state = first.state;
  const claimId = first.ok ? (first.value?.id ?? '') : '';

  check('remaining is 16 after claiming 4', () => assert.equal(remainingOf(state, listingId, now), 16));

  const duplicate = claimListing(state, [], listingId, 4, DEMO, now);
  check('second claim of 4 by the same seeker is rejected', () => {
    assert.equal(duplicate.ok, false);
    assert.equal(errorOf(duplicate), DUPLICATE_MESSAGE);
  });

  // The demo seeker already holds an active claim here, so the duplicate check rejects this first.
  const tooMany = claimListing(state, [], listingId, 17, DEMO, now);
  check('claim of 17 is rejected', () => {
    assert.equal(tooMany.ok, false);
    assert.equal(errorOf(tooMany), DUPLICATE_MESSAGE);
  });

  // Separate listing with no claims, so the remaining-count check is what rejects 17.
  const fresh = postListing(seeded, listingInput(16, now), now);
  const freshId = fresh.ok && fresh.value ? fresh.value.id : '';
  const freshState: ProviderState = fresh.ok ? fresh.state : seeded;
  const shortClaim = claimListing(freshState, [], freshId, 17, DEMO, now);
  check('claim of 17 on a 16-portion listing with no claims is rejected with the exact count', () =>
    assert.equal(errorOf(shortClaim), 'Only 16 portions are left.'),
  );

  const cancelled = cancelClaim(state, claimId, [], now);
  check('cancel the 4-portion claim succeeds', () => assert.equal(cancelled.ok, true, errorOf(cancelled)));
  if (cancelled.ok) state = cancelled.state;

  check('remaining is back to 20 after cancelling', () => assert.equal(remainingOf(state, listingId, now), 20));
  check('cancelled claim stays in state with status cancelled', () => {
    const claim = state.claims.find((item) => item.id === claimId);
    assert.equal(claim?.status, 'cancelled');
  });

  const afterDeadline = claimListing(state, [], listingId, 4, DEMO, deadlineMs + MIN);
  check('claim at deadline + 1 minute is rejected', () =>
    assert.equal(errorOf(afterDeadline), 'The pickup window for this listing has closed.'),
  );

  const rebooked = claimListing(state, [], listingId, 4, DEMO, now);
  if (rebooked.ok) state = rebooked.state;
  const cancelLate = cancelClaim(state, rebooked.ok ? (rebooked.value?.id ?? '') : '', [], deadlineMs + MIN);
  check('cancel after the deadline is rejected', () =>
    assert.equal(errorOf(cancelLate), 'The pickup window has closed, so this reservation cannot be cancelled.'),
  );

  if (failures > 0) {
    console.log(`${failures} assertion(s) failed.`);
    process.exitCode = 1;
  } else {
    console.log('All assertions passed.');
  }
}

main().catch((error: unknown) => {
  console.log(`FAIL unexpected error: ${error instanceof Error ? error.message : String(error)}`);
  process.exitCode = 1;
});
