/**
 * Run with: npx tsx scripts/pickup-check.ts (Node 18+ and tsx required)
 *
 * Offline pickup-workflow checks for the provider store. No browser, no network, no test runner.
 * Each check prints "PASS <name>" or "FAIL <name>: <message>", and the script ends with "N passed, M failed".
 *
 * Dependencies on src/provider/store.ts:
 *   - MAX_PICKUP_ATTEMPTS = 5 wrong codes before a lock, and PICKUP_LOCK_MS = 5 minutes.
 *     Those constants are file-local in store.ts and are not imported here. Checks 4 and 5 rely on
 *     the 5-wrong-code limit and on the 5-minute lock. If either value changes, update those checks.
 *   - The lock message starts with "Too many incorrect codes" and the wrong-code message is
 *     "That pickup code does not match.".
 *
 * Fixed clock: NOW below. Nothing here reads Date.now().
 * The state is built inline, so the demo seed data (seedProviderState) is never used.
 */
import assert from 'node:assert/strict';
import { PROVIDER_BUSINESS_NAME } from '../src/data/vendors';
import type { PostListingInput, PickupClaim, ProviderListingRecord, ProviderState, Result, ReportReason } from '../src/provider/types';
import { remainingFor } from '../src/provider/derive';
import {
  cancelClaim,
  claimListing,
  confirmPickup,
  expiryNotifications,
  getImpact,
  postListing,
  reportListing,
} from '../src/provider/store';

const MIN = 60_000;
const HOUR = 60 * MIN;
const NOW = Date.UTC(2025, 5, 1, 10, 0);
const SEEKER = 'Demo Seeker';
const LISTING_NAME = 'Test Dal Rice';
const SECOND_NAME = 'Test Bread Box';

let passed = 0;
let failed = 0;

function iso(ms: number): string {
  return new Date(ms).toISOString();
}

function check(name: string, fn: () => void): void {
  try {
    fn();
    passed += 1;
    console.log(`PASS ${name}`);
  } catch (err) {
    failed += 1;
    process.exitCode = 1;
    const message = err instanceof Error ? err.message : String(err);
    console.log(`FAIL ${name}: ${message}`);
  }
}

function freshState(): ProviderState {
  return {
    version: 1,
    profile: {
      businessName: PROVIDER_BUSINESS_NAME,
      businessType: 'Caterer',
      description: '',
      area: 'Koramangala',
      hours: '',
      contactPlaceholder: '',
      preferences: [],
    },
    listings: [],
    claims: [],
    notifications: [],
  };
}

function input(name: string, portions: number, now: number): PostListingInput {
  return {
    name,
    category: 'Meals',
    isVeg: true,
    portions,
    isFree: false,
    price: 50,
    originalPrice: 120,
    allocation: 'open',
    pickupStart: iso(now - MIN),
    pickupDeadline: iso(now + 2 * HOUR),
    area: 'Koramangala',
    handling: {
      preparedAt: iso(now - HOUR),
      storage: 'Keep chilled',
      reheating: 'Heat until hot',
      providerNote: '',
    },
    allergens: [],
    image: '',
  };
}

/** Unwraps a successful result, or throws with the store's error text. value is set only by actions that return one. */
function okOf<T>(result: Result<T>, label: string): { state: ProviderState; value: T } {
  if (!result.ok) throw new Error(`${label} was rejected: ${result.error}`);
  return { state: result.state, value: result.value as T };
}

/** Unwraps a rejected result and returns its error text. Throws if the action unexpectedly succeeded. */
function failOf<T>(result: Result<T>, label: string): { error: string; state: ProviderState | undefined } {
  if (result.ok) throw new Error(`${label} unexpectedly succeeded`);
  return { error: result.error, state: result.state };
}

function postOne(
  state: ProviderState,
  name: string,
  portions: number,
  now: number,
): { state: ProviderState; listing: ProviderListingRecord } {
  const { state: next, value } = okOf(postListing(state, input(name, portions, now), now), `post ${name}`);
  return { state: next, listing: value };
}

function claimOne(
  state: ProviderState,
  listingId: string,
  portions: number,
  now: number,
): { state: ProviderState; claim: PickupClaim } {
  const { state: next, value } = okOf(
    claimListing(state, [], listingId, portions, SEEKER, now),
    `claim ${portions} portions`,
  );
  return { state: next, claim: value };
}

function hasMessage(state: ProviderState, message: string): boolean {
  return (state.notifications ?? []).some((item) => item.message === message);
}

// 1. Post a listing with 20 portions and an open pickup window.
check('1 post listing with 20 portions', () => {
  const { listing } = postOne(freshState(), LISTING_NAME, 20, NOW);
  assert.equal(listing.portionsTotal, 20);
});

// 2. Claim 4 portions as a demo seeker.
let afterClaim: ProviderState | null = null;
let claimId = '';
let claimCode = '';
check('2 claim 4 portions as demo seeker', () => {
  const posted = postOne(freshState(), LISTING_NAME, 20, NOW);
  const { state, claim } = claimOne(posted.state, posted.listing.id, 4, NOW);
  assert.ok(claim.code.length > 0, 'claim has no pickup code');
  afterClaim = state;
  claimId = claim.id;
  claimCode = claim.code;
});

// 3. A single wrong code is rejected with the wrong-code message.
check('3 wrong code is rejected', () => {
  assert.ok(afterClaim, 'no claim state from check 2');
  const { error } = failOf(confirmPickup(afterClaim, claimId, 'WRONG-000', NOW), 'wrong code');
  assert.equal(error, 'That pickup code does not match.');
});

// 4. Five consecutive wrong codes, then the correct code is refused by the lock.
let lockedState: ProviderState | null = null;
check('4 five wrong codes then correct code is locked', () => {
  const posted = postOne(freshState(), LISTING_NAME, 20, NOW);
  const { state: start, claim } = claimOne(posted.state, posted.listing.id, 4, NOW);
  let current: ProviderState = start;
  for (let i = 0; i < 5; i += 1) {
    const { error, state } = failOf(confirmPickup(current, claim.id, 'WRONG-000', NOW), `wrong code ${i + 1}`);
    assert.equal(error, 'That pickup code does not match.');
    if (state === undefined) throw new Error(`wrong code ${i + 1} did not save the attempt count`);
    current = state;
  }
  const { error } = failOf(confirmPickup(current, claim.id, claim.code, NOW), 'correct code while locked');
  assert.ok(error.startsWith('Too many incorrect codes'), `unexpected message: ${error}`);
  lockedState = current;
  claimId = claim.id;
  claimCode = claim.code;
});

// 5. After 6 minutes the lock has passed and the correct code succeeds.
let collectedState: ProviderState | null = null;
check('5 correct code after 6 minutes succeeds', () => {
  assert.ok(lockedState, 'no locked state from check 4');
  const { state } = okOf(confirmPickup(lockedState, claimId, claimCode, NOW + 6 * MIN), 'correct code after lock');
  collectedState = state;
});

// 6. Confirming the same claim again is refused.
check('6 second confirm on same claim says already collected', () => {
  assert.ok(collectedState, 'no collected state from check 5');
  const { error } = failOf(confirmPickup(collectedState, claimId, claimCode, NOW + 6 * MIN), 'second confirm');
  assert.ok(error.includes('already collected'), `unexpected message: ${error}`);
});

// 7. Cancelling a claim returns its portions to the listing.
check('7 cancel claim returns portions', () => {
  const first = postOne(freshState(), LISTING_NAME, 20, NOW);
  const second = postOne(first.state, SECOND_NAME, 20, NOW);
  const { state: claimed, claim } = claimOne(second.state, second.listing.id, 4, NOW);
  const { state: cancelled } = okOf(cancelClaim(claimed, claim.id, [], NOW), 'cancel claim');
  const record = cancelled.listings.find((item) => item.id === second.listing.id);
  if (!record) throw new Error('listing missing after cancel');
  assert.equal(remainingFor(record, cancelled.claims), 20);
});

// 8. Confirming after the listing's pickup deadline is refused as expired.
check('8 confirm after pickup deadline is expired', () => {
  const posted = postOne(freshState(), LISTING_NAME, 20, NOW);
  const { state, claim } = claimOne(posted.state, posted.listing.id, 4, NOW);
  const { error } = failOf(confirmPickup(state, claim.id, claim.code, NOW + 3 * HOUR), 'late confirm');
  const expiryMessages = ['This claim has expired.', 'The pickup window for this listing has closed.'];
  assert.ok(expiryMessages.includes(error), `unexpected message: ${error}`);
});

// 9. Notifications come from real store events, with exact text.
check('9a reservation notice after claim', () => {
  const posted = postOne(freshState(), LISTING_NAME, 20, NOW);
  const { state } = claimOne(posted.state, posted.listing.id, 4, NOW);
  assert.ok(hasMessage(state, `Reservation confirmed: 4 portion(s) of ${LISTING_NAME}. Show code at pickup.`));
});

check('9b cancellation notice after cancel', () => {
  const posted = postOne(freshState(), LISTING_NAME, 20, NOW);
  const { state, claim } = claimOne(posted.state, posted.listing.id, 4, NOW);
  const { state: cancelled } = okOf(cancelClaim(state, claim.id, [], NOW), 'cancel claim');
  assert.ok(hasMessage(cancelled, `Reservation cancelled: 4 portion(s) of ${LISTING_NAME} returned to the listing.`));
});

check('9c pickup notice after confirm', () => {
  const posted = postOne(freshState(), LISTING_NAME, 20, NOW);
  const { state, claim } = claimOne(posted.state, posted.listing.id, 4, NOW);
  const { state: collected } = okOf(confirmPickup(state, claim.id, claim.code, NOW), 'confirm pickup');
  assert.ok(hasMessage(collected, `Pickup confirmed: 4 portion(s) of ${LISTING_NAME} collected.`));
});

check('9d expiry notice added once, then none', () => {
  const posted = postOne(freshState(), LISTING_NAME, 20, NOW);
  const { state, claim } = claimOne(posted.state, posted.listing.id, 4, NOW);
  const later = NOW + 3 * HOUR;
  const first = expiryNotifications(state, later);
  const id = `expiry-${claim.id}`;
  const notices = (first.notifications ?? []).filter((item) => item.id === id);
  assert.equal(notices.length, 1, 'expected exactly one expiry notice');
  assert.equal(
    notices[0]?.message,
    `Pickup window closed for ${LISTING_NAME}. Unclaimed portions were not collected.`,
  );
  const second = expiryNotifications(first, later);
  assert.equal(second, first, 'second call should return the same state object');
  const again = (second.notifications ?? []).filter((item) => item.id === id);
  assert.equal(again.length, 1, 'second call added a notice');
});

// 10. Impact counts only confirmed collections.
check('10 impact counts only collected portions', () => {
  const posted = postOne(freshState(), LISTING_NAME, 20, NOW);
  const firstClaim = claimOne(posted.state, posted.listing.id, 4, NOW);
  const collected = okOf(
    confirmPickup(firstClaim.state, firstClaim.claim.id, firstClaim.claim.code, NOW),
    'confirm first claim',
  );
  const reserved = claimOne(collected.state, posted.listing.id, 4, NOW);
  const impact = getImpact(reserved.state, NOW);
  assert.equal(impact.collected, 4);
});

// 11. A report with an unknown reason is refused.
check('11 report with unknown reason is rejected', () => {
  const posted = postOne(freshState(), LISTING_NAME, 20, NOW);
  const bogus: string = 'Made up reason';
  failOf(reportListing(posted.state, [], posted.listing.id, bogus as ReportReason, NOW), 'unknown report reason');
});

console.log(`${passed} passed, ${failed} failed`);
