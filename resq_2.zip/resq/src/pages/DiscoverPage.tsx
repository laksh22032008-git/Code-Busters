import { useMemo } from 'react';
import { FoodGrid } from '../components/FoodGrid';
import { FilterBar } from '../components/FilterBar';
import { HeroGreeting } from '../components/HeroGreeting';
import { MapPreview } from '../components/MapPreview';
import { SearchBar } from '../components/SearchBar';
import { Section } from '../components/Section';
import { BusinessModelSection } from '../components/BusinessModelSection';
import { useAppState } from '../context/AppStateContext';
import { isOpenForClaim, isUrgent } from '../lib/availability';
import { filterListings } from '../lib/filterListings';

export function DiscoverPage() {
  const { listings, now, category, query, availableOnly, sort, location } = useAppState();

  const filtered = useMemo(
    () => filterListings(listings, { category, query, availableOnly, sort }, now),
    [listings, category, query, availableOnly, sort, now],
  );

  const open = useMemo(() => listings.filter((item) => isOpenForClaim(item, now)), [listings, now]);

  const urgent = useMemo(
    () =>
      open
        .filter((item) => isUrgent(item, now))
        .sort((a, b) => Date.parse(a.pickupDeadline) - Date.parse(b.pickupDeadline))
        .slice(0, 6),
    [open, now],
  );

  const recent = useMemo(
    () =>
      [...listings].sort((a, b) => Date.parse(b.addedAt) - Date.parse(a.addedAt)).slice(0, 3),
    [listings],
  );

  const featured = useMemo(
    () =>
      filterListings(
        open,
        { category: 'all', query: '', availableOnly: false, sort: 'distance' },
        now,
      ).slice(0, 3),
    [open, now],
  );

  return (
    <div className="discover-page">
      <HeroGreeting />
      <div className="discover-tools">
        <SearchBar />
        <FilterBar />
      </div>

      {urgent.length > 0 ? (
        <div className="urgent-section">
          <p className="urgent-kicker">Pickup soon</p>
          <Section title="Urgent pickup" subtitle="Closing within the hour or nearly gone">
            <div className="urgent-list">
              <FoodGrid listings={urgent} />
            </div>
          </Section>
        </div>
      ) : null}
      <Section title="Food near you" subtitle={`${filtered.length} pickups in ${location}`}>
        <FoodGrid listings={filtered} />
      </Section>
      <Section title="Recently added" subtitle="Fresh listings from the last few hours">
        <FoodGrid listings={recent} />
      </Section>
      <Section title="Featured nearby" subtitle="The three closest pickups right now">
        <FoodGrid listings={featured} />
      </Section>
      <MapPreview />
      <BusinessModelSection />
    </div>
  );
}
