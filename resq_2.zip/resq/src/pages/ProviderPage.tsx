import { ProviderIntro } from '../components/ProviderIntro';

export function ProviderPage() {
  return <ProviderIntro />;
}
