import { PlaceholderPage } from '../components/PlaceholderPage';
import { RoleSwitcher } from '../components/RoleSwitcher';

export function ProfilePage() {
  return (
    <PlaceholderPage
      title="Profile"
      description="Account details, dietary preferences and pickup history will live here. You are browsing as a guest."
      demoLabel="Edit profile (demo)"
      demoFeature="profile editing"
    >
      <div className="profile-role">
        <h2>Switch demo role</h2>
        <RoleSwitcher />
      </div>
    </PlaceholderPage>
  );
}
