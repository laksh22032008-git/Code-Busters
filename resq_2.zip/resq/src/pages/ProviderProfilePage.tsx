import { useState, type FormEvent } from 'react';
import { ProviderPageHeader } from '../components/provider/ProviderPageHeader';
import { ProfileFields } from '../components/provider/ProfileFields';
import { useAppState } from '../context/AppStateContext';
import {
  EMPTY_VENDOR_LOCATION,
  type ProviderProfile,
  type VendorLocation,
} from '../provider/types';
import '../styles/provider-profile.css';

const NAME_MIN = 2;
const NAME_MAX = 60;

function validateName(value: string): string | null {
  const length = value.trim().length;
  if (length === 0) return 'Enter a business name.';
  if (length < NAME_MIN || length > NAME_MAX) {
    return `Business name must be ${NAME_MIN} to ${NAME_MAX} characters.`;
  }
  return null;
}

function sameLocation(a: VendorLocation, b: VendorLocation): boolean {
  return (
    a.addressLine === b.addressLine &&
    a.landmark === b.landmark &&
    a.latitude === b.latitude &&
    a.longitude === b.longitude &&
    a.capturedVia === b.capturedVia
  );
}

function sameProfile(a: ProviderProfile, b: ProviderProfile): boolean {
  return (
    a.businessName === b.businessName &&
    a.businessType === b.businessType &&
    a.description === b.description &&
    a.area === b.area &&
    a.hours === b.hours &&
    a.contactPlaceholder === b.contactPlaceholder &&
    a.preferences.length === b.preferences.length &&
    a.preferences.every((item) => b.preferences.includes(item)) &&
    sameLocation(a.location ?? EMPTY_VENDOR_LOCATION, b.location ?? EMPTY_VENDOR_LOCATION)
  );
}

export function ProviderProfilePage() {
  const { provider, updateProfile } = useAppState();
  const [baseline, setBaseline] = useState<ProviderProfile>(provider.profile);
  const [draft, setDraft] = useState<ProviderProfile>(provider.profile);
  const [nameTouched, setNameTouched] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const nameError = validateName(draft.businessName);
  const isDirty = !sameProfile(draft, baseline);

  function handleChange(patch: Partial<ProviderProfile>) {
    setDraft((current) => ({ ...current, ...patch }));
    setSubmitError(null);
  }

  // Functional merge so an async geolocation result cannot overwrite a field typed in the meantime.
  function handleLocationChange(patch: Partial<VendorLocation>) {
    setDraft((current) => ({
      ...current,
      location: { ...(current.location ?? EMPTY_VENDOR_LOCATION), ...patch },
    }));
    setSubmitError(null);
  }

  function handleDiscard() {
    setDraft(baseline);
    setSubmitError(null);
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setNameTouched(true);
    if (validateName(draft.businessName)) return;
    const result = updateProfile(draft);
    if (result.ok) {
      setBaseline(result.state.profile);
      setDraft(result.state.profile);
      setSubmitError(null);
    } else {
      setSubmitError(result.error);
    }
  }

  return (
    <section className="provider-profile">
      <ProviderPageHeader
        title="Business profile"
        subtitle="Shown to food seekers on your listings. Demo data only."
      />
      <form className="profile-form" onSubmit={handleSubmit} noValidate>
        <ProfileFields
          draft={draft}
          savedContactPlaceholder={baseline.contactPlaceholder}
          nameError={nameTouched ? nameError : null}
          onChange={handleChange}
          onLocationChange={handleLocationChange}
          onNameBlur={() => setNameTouched(true)}
        />
        {submitError && (
          <p className="profile-error" role="alert">
            {submitError}
          </p>
        )}
        <div className="profile-actions">
          <button
            type="button"
            className="profile-btn profile-btn--secondary"
            onClick={handleDiscard}
            disabled={!isDirty}
          >
            Discard
          </button>
          <button type="submit" className="profile-btn profile-btn--primary" disabled={!isDirty}>
            Save changes
          </button>
        </div>
      </form>
    </section>
  );
}
