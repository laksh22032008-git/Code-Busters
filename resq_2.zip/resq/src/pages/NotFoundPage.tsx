import { Link } from 'react-router-dom';

export function NotFoundPage() {
  return (
    <section className="not-found">
      <h1 className="page-title">Page not found</h1>
      <p className="page-description">The page you were looking for does not exist.</p>
      <Link to="/discover" className="primary-button">
        Back to Discover
      </Link>
    </section>
  );
}
