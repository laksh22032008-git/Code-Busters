import { useCallback, useState } from 'react';
import { ProviderPageHeader } from '../components/provider/ProviderPageHeader';
import { QuickPostModal } from '../components/provider/QuickPostModal';
import { useAppState } from '../context/AppStateContext';
import { getDashboardMetrics } from '../provider/store';
import '../styles/provider-overview.css';

export function ProviderOverviewPage() {
  const { provider, now } = useAppState();
  const [postOpen, setPostOpen] = useState(false);
  const closePost = useCallback(() => setPostOpen(false), []);
  const metrics = getDashboardMetrics(provider, now);
  const today = new Date(now).toLocaleDateString('en-IN', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
  });

  const action = (
    <button type="button" className="primary-button overview-action" onClick={() => setPostOpen(true)}>
      Post surplus food
    </button>
  );

  const tiles = [
    { label: 'Active listings', value: metrics.activeListings },
    { label: 'Portions available', value: metrics.portionsAvailable },
    { label: 'Portions claimed', value: metrics.portionsClaimed },
    { label: 'Pickups awaiting', value: metrics.pickupsAwaiting },
    { label: 'Portions rescued', value: metrics.portionsRescued },
  ];

  return (
    <div className="provider-overview">
      <ProviderPageHeader
        title="Overview"
        subtitle={`Good to see you, ${provider.profile.businessName}. Today is ${today}`}
        action={action}
      />

      <section className="overview-kpis" aria-label="Key figures">
        {tiles.map((tile) => (
          <article key={tile.label} className="overview-kpi">
            <p className="overview-kpi-value">{tile.value}</p>
            <p className="overview-kpi-label">{tile.label}</p>
          </article>
        ))}
      </section>

      <section className="overview-panel" aria-labelledby="overview-expiring-title">
        <h2 className="overview-panel-title" id="overview-expiring-title">
          Expiring within an hour
        </h2>
        {metrics.expiringSoon.length === 0 ? (
          <p className="overview-empty">No listings are expiring in the next hour.</p>
        ) : (
          <ul className="overview-list">
            {metrics.expiringSoon.map((view) => (
              <li key={view.record.id} className="overview-list-item">
                <span className="overview-list-name">{view.record.name}</span>
                <span className="overview-list-meta">{view.portionsRemaining} portions left</span>
                <span className="overview-list-time">
                  Pick up by{' '}
                  {new Date(view.record.pickupDeadline).toLocaleTimeString('en-IN', {
                    hour: 'numeric',
                    minute: '2-digit',
                  })}
                </span>
              </li>
            ))}
          </ul>
        )}
      </section>

      {postOpen && <QuickPostModal onClose={closePost} />}
    </div>
  );
}
