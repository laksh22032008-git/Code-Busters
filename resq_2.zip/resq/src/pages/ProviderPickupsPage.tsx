import { useMemo, useState } from 'react';
import { PickupVerifyPanel } from '../components/provider/PickupVerifyPanel';
import { ProviderPageHeader } from '../components/provider/ProviderPageHeader';
import {
  CLAIM_STATUS_LABEL,
  CLAIM_STATUS_TONE,
  formatClock,
  formatPortions,
} from '../components/provider/opsFormat';
import { StatusPill } from '../components/provider/StatusPill';
import { useAppState } from '../context/AppStateContext';
import type { ClaimStatus, PickupClaim, ProviderListingRecord } from '../provider/types';
import '../styles/provider-ops.css';

type Section = 'ready' | 'reserved' | 'collected' | 'closed';

const SECTIONS: { key: Section; title: string }[] = [
  { key: 'ready', title: 'Ready for pickup' },
  { key: 'reserved', title: 'Reserved' },
  { key: 'collected', title: 'Collected' },
  { key: 'closed', title: 'Expired or cancelled' },
];

interface PickupItem {
  claim: PickupClaim;
  record: ProviderListingRecord;
  status: ClaimStatus;
  section: Section;
}

// A reserved or ready claim whose listing deadline has passed is shown as expired.
function effectiveStatus(claim: PickupClaim, record: ProviderListingRecord, now: number): ClaimStatus {
  if ((claim.status === 'reserved' || claim.status === 'ready') && Date.parse(record.pickupDeadline) <= now) {
    return 'expired';
  }
  return claim.status;
}

function sectionFor(status: ClaimStatus): Section {
  if (status === 'ready') return 'ready';
  if (status === 'reserved') return 'reserved';
  if (status === 'collected') return 'collected';
  return 'closed';
}

interface PickupRowProps {
  item: PickupItem;
  error: string | null;
  verifying: boolean;
  onMarkReady: () => void;
  onStartVerify: () => void;
  onStopVerify: () => void;
}

function PickupRow({ item, error, verifying, onMarkReady, onStartVerify, onStopVerify }: PickupRowProps) {
  const { claim, record, status } = item;
  return (
    <li className="ops-pickup">
      <div className="ops-pickup-main">
        <p className="ops-row-name">{record.name}</p>
        <p className="ops-pickup-meta">
          {formatPortions(claim.portions)} for {claim.collectorName}, claimed {formatClock(claim.claimedAt)}
        </p>
        <span className="pickup-code">{claim.code}</span>
      </div>
      <StatusPill label={CLAIM_STATUS_LABEL[status]} tone={CLAIM_STATUS_TONE[status]} />
      <div className="ops-pickup-actions">
        {status === 'reserved' && (
          <button type="button" className="ops-button" onClick={onMarkReady}>
            Mark ready
          </button>
        )}
        {status === 'ready' && !verifying && (
          <button type="button" className="ops-button-solid" onClick={onStartVerify}>
            Confirm collection
          </button>
        )}
      </div>
      {error && (
        <p className="ops-error" role="alert">
          {error}
        </p>
      )}
      {status === 'ready' && verifying && (
        <PickupVerifyPanel claimId={claim.id} onDone={onStopVerify} onCancel={onStopVerify} />
      )}
    </li>
  );
}

export function ProviderPickupsPage() {
  const { provider, now, markClaimReady } = useAppState();
  const [verifyId, setVerifyId] = useState<string | null>(null);
  const [rowError, setRowError] = useState<{ claimId: string; message: string } | null>(null);

  const items = useMemo(() => {
    const records = new Map<string, ProviderListingRecord>(
      provider.listings.map((record) => [record.id, record] as const),
    );
    const list: PickupItem[] = [];
    for (const claim of provider.claims) {
      const record = records.get(claim.listingId);
      if (!record) continue;
      const status = effectiveStatus(claim, record, now);
      list.push({ claim, record, status, section: sectionFor(status) });
    }
    return list.sort((a, b) => Date.parse(b.claim.claimedAt) - Date.parse(a.claim.claimedAt));
  }, [provider, now]);

  const handleMarkReady = (claimId: string): void => {
    const result = markClaimReady(claimId);
    setRowError(result.ok ? null : { claimId, message: result.error });
  };

  return (
    <div className="ops-page">
      <ProviderPageHeader title="Pickups" subtitle="Mark reserved pickups ready, then confirm collection with the code." />

      {items.length === 0 && <p className="ops-empty">No pickups yet. Claims on your listings appear here.</p>}

      {SECTIONS.map((section) => {
        const rows = items.filter((item) => item.section === section.key);
        if (rows.length === 0) return null;
        return (
          <section key={section.key} className="ops-section" aria-labelledby={`ops-section-${section.key}`}>
            <h2 className="ops-section-title" id={`ops-section-${section.key}`}>
              {section.title}
            </h2>
            <ul className="ops-pickup-list">
              {rows.map((item) => (
                <PickupRow
                  key={item.claim.id}
                  item={item}
                  error={rowError?.claimId === item.claim.id ? rowError.message : null}
                  verifying={verifyId === item.claim.id}
                  onMarkReady={() => handleMarkReady(item.claim.id)}
                  onStartVerify={() => setVerifyId(item.claim.id)}
                  onStopVerify={() => setVerifyId(null)}
                />
              ))}
            </ul>
          </section>
        );
      })}
    </div>
  );
}
