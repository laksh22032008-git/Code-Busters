import { useCallback, useMemo, useState } from 'react';
import { ListingDetailDialog } from '../components/provider/ListingDetailDialog';
import { ProviderPageHeader } from '../components/provider/ProviderPageHeader';
import {
  LISTING_STATUS_LABEL,
  LISTING_STATUS_TONE,
  formatClock,
} from '../components/provider/opsFormat';
import { StatusPill } from '../components/provider/StatusPill';
import { useAppState } from '../context/AppStateContext';
import { providerListingViews } from '../provider/store';
import type { ListingStatus, ProviderListingView } from '../provider/types';
import '../styles/provider-ops.css';

type ListingFilter = 'all' | ListingStatus;

const FILTERS: { value: ListingFilter; label: string }[] = [
  { value: 'all', label: 'All' },
  { value: 'active', label: 'Active' },
  { value: 'fully-claimed', label: 'Fully claimed' },
  { value: 'expired', label: 'Expired' },
  { value: 'collected', label: 'Collected' },
  { value: 'cancelled', label: 'Cancelled' },
];

interface ListingRowProps {
  view: ProviderListingView;
  onOpen: () => void;
}

function ListingRow({ view, onOpen }: ListingRowProps) {
  const { record } = view;
  return (
    <li className="ops-row-item">
      <button type="button" className="ops-row" onClick={onOpen}>
        <img className="ops-thumb" src={record.image} alt="" />
        <span className="ops-row-main">
          <span className="ops-row-name">{record.name}</span>
          <span className="ops-row-tags">
            <span className="ops-tag">{record.price === 0 ? 'Free' : 'Discounted'}</span>
            <span className="ops-row-time">Pick up by {formatClock(record.pickupDeadline)}</span>
          </span>
        </span>
        <span className="ops-stats">
          <span className="ops-stat">
            <span className="ops-stat-label">Posted</span>
            <span className="ops-stat-value">{record.portionsTotal}</span>
          </span>
          <span className="ops-stat">
            <span className="ops-stat-label">Remaining</span>
            <span className="ops-stat-value">{view.portionsRemaining}</span>
          </span>
          <span className="ops-stat">
            <span className="ops-stat-label">Claimed</span>
            <span className="ops-stat-value">{view.portionsClaimed}</span>
          </span>
        </span>
        <StatusPill label={LISTING_STATUS_LABEL[view.status]} tone={LISTING_STATUS_TONE[view.status]} />
      </button>
    </li>
  );
}

export function ProviderListingsPage() {
  const { provider, now } = useAppState();
  const [filter, setFilter] = useState<ListingFilter>('all');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const closeDialog = useCallback(() => setSelectedId(null), []);

  const views = useMemo(
    () =>
      [...providerListingViews(provider, now)].sort(
        (a, b) => Date.parse(b.record.addedAt) - Date.parse(a.record.addedAt),
      ),
    [provider, now],
  );
  const visible = filter === 'all' ? views : views.filter((view) => view.status === filter);
  const selected = views.find((view) => view.record.id === selectedId) ?? null;

  const countFor = (value: ListingFilter): number =>
    value === 'all' ? views.length : views.filter((view) => view.status === value).length;

  return (
    <div className="ops-page">
      <ProviderPageHeader
        title="My Listings"
        subtitle="Review everything you have posted. Open a listing to edit it, mark it unavailable or cancel it."
      />

      <div className="ops-segment" role="group" aria-label="Filter listings by status">
        {FILTERS.map((item) => (
          <button
            key={item.value}
            type="button"
            className="ops-segment-button"
            aria-pressed={filter === item.value}
            onClick={() => setFilter(item.value)}
          >
            {item.label} <span className="ops-segment-count">{countFor(item.value)}</span>
          </button>
        ))}
      </div>

      {visible.length === 0 ? (
        <p className="ops-empty">No listings in this status.</p>
      ) : (
        <ul className="ops-list" aria-label="Listings">
          {visible.map((view) => (
            <ListingRow key={view.record.id} view={view} onOpen={() => setSelectedId(view.record.id)} />
          ))}
        </ul>
      )}

      {selected && <ListingDetailDialog view={selected} onClose={closeDialog} />}
    </div>
  );
}
