import { AdminIntro } from '../components/AdminIntro';

export function AdminPage() {
  return <AdminIntro />;
}
