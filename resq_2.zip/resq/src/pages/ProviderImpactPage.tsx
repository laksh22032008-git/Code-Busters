import { ProviderPageHeader } from '../components/provider/ProviderPageHeader';
import { BusinessModelSection } from '../components/BusinessModelSection';
import { useAppState } from '../context/AppStateContext';
import { CO2E_KG_PER_KG_DIVERTED, IMPACT_ASSUMPTIONS, KG_PER_MEAL } from '../lib/impactConstants';
import { getImpact, type ImpactSummary } from '../provider/store';
import type { ProviderState } from '../provider/types';
import '../styles/provider-impact.css';
import '../styles/impact-kpi.css';

const MS_PER_MINUTE = 60 * 1000;

const FUNNEL_STAGES = [
  {
    key: 'posted',
    label: 'Listed',
    explanation: 'Portions you listed.',
  },
  {
    key: 'claimed',
    label: 'Claimed',
    explanation: 'Portions reserved or ready for pickup, not yet rescued.',
  },
  {
    key: 'collected',
    label: 'Collected',
    explanation: 'Portions confirmed collected by a pickup verification.',
  },
] as const;

function percent(part: number, whole: number): number {
  if (whole <= 0) return 0;
  return Math.min(100, Math.max(0, (part / whole) * 100));
}

/** Mean minutes from listing addedAt to claim collectedAt, over collected claims with timestamps. Null if none. */
function avgPickupMinutes(state: ProviderState): number | null {
  const addedById = new Map(state.listings.map((record) => [record.id, Date.parse(record.addedAt)]));
  const samples: number[] = [];
  for (const claim of state.claims) {
    if (claim.status !== 'collected' || claim.collectedAt === '') continue;
    const added = addedById.get(claim.listingId);
    const collectedMs = Date.parse(claim.collectedAt);
    if (added === undefined || Number.isNaN(added) || Number.isNaN(collectedMs)) continue;
    samples.push((collectedMs - added) / MS_PER_MINUTE);
  }
  if (samples.length === 0) return null;
  return samples.reduce((total, value) => total + value, 0) / samples.length;
}

/** Impact figures. Meals and kg come from getImpact (confirmed collections only); pickup time from confirmed claims. */
function impactMetrics(state: ProviderState, impact: ImpactSummary) {
  return {
    mealsSaved: impact.mealsEstimate,
    divertedKg: Math.round(impact.collectedKg * 10) / 10,
    co2eKg: Math.round(impact.collectedKg * CO2E_KG_PER_KG_DIVERTED),
    avgPickupMin: avgPickupMinutes(state),
  };
}

export function ProviderImpactPage() {
  const { provider, now } = useAppState();
  const impact = getImpact(provider, now);

  const counts = { posted: impact.posted, claimed: impact.claimed, collected: impact.collected };
  const claimedNotCollected = Math.max(0, impact.claimed - impact.collected);
  const unclaimed = Math.max(0, impact.posted - impact.claimed);
  const collectedPct = percent(impact.collected, impact.posted);
  const claimedPct = percent(claimedNotCollected, impact.posted);
  const unclaimedPct = percent(unclaimed, impact.posted);

  const weeklyMax = impact.weekly.reduce((max, point) => Math.max(max, point.collected), 0);
  const metrics = impactMetrics(provider, impact);
  const pickupLabel = metrics.avgPickupMin === null ? '--' : String(Math.round(metrics.avgPickupMin));

  return (
    <div className="provider-impact">
      <ProviderPageHeader title="Impact" subtitle="Only confirmed collections count as rescued food." />

      <section className="impact-section" aria-labelledby="impact-funnel-heading">
        <h2 id="impact-funnel-heading" className="impact-heading">
          Pickup funnel
        </h2>
        <ol className="impact-funnel">
          {FUNNEL_STAGES.map((stage) => (
            <li key={stage.key} className={`impact-stage impact-stage--${stage.key}`}>
              <span className="impact-stage-label">{stage.label}</span>
              <span className="impact-stage-value">{counts[stage.key]}</span>
              <span className="impact-stage-note">{stage.explanation}</span>
            </li>
          ))}
        </ol>
      </section>

      <section className="impact-section" aria-labelledby="impact-metrics-heading">
        <h2 id="impact-metrics-heading" className="impact-heading">
          Impact metrics
        </h2>
        <ul className="impact-metrics">
          <li className="impact-metric impact-metric--featured">
            <span className="impact-metric-label">Meals Saved</span>
            <span className="impact-metric-value mono">{metrics.mealsSaved}</span>
            <span className="impact-metric-note">Confirmed kg ÷ {KG_PER_MEAL} kg per meal.</span>
          </li>
          <li className="impact-metric">
            <span className="impact-metric-label">Food Waste Diverted (kg)</span>
            <span className="impact-metric-value mono">{metrics.divertedKg}</span>
            <span className="impact-metric-note">Confirmed kg: collected portions × {KG_PER_MEAL} kg, or listing quantity prorated by collected share.</span>
          </li>
          <li className="impact-metric">
            <span className="impact-metric-label">CO₂e Avoided (kg)</span>
            <span className="impact-metric-value mono">{metrics.co2eKg}</span>
            <span className="impact-metric-note">Diverted kg × {CO2E_KG_PER_KG_DIVERTED} kg CO₂e.</span>
          </li>
          <li className="impact-metric">
            <span className="impact-metric-label">Avg Pickup Time (mins)</span>
            <span className="impact-metric-value mono">{pickupLabel}</span>
            <span className="impact-metric-note">
              {metrics.avgPickupMin === null
                ? 'No collected pickup has a timestamp yet, so this shows --.'
                : 'Listing added → claim marked collected, averaged across collected claims.'}
            </span>
          </li>
        </ul>

        <details className="impact-methodology">
          <summary className="impact-methodology-summary">Math and assumptions</summary>
          <ul className="impact-methodology-list">
            <li>Listed = portions on non-cancelled listings. Claimed = portions with an active or collected claim. Collected = portions with a confirmed pickup.</li>
            <li>Meals Saved = round(confirmed kg ÷ {KG_PER_MEAL}).</li>
            <li>Food Waste Diverted (kg) = confirmed kg, where confirmed kg = collected portions × {KG_PER_MEAL} (uses the listing&apos;s quantityKg when present, prorated by collected share).</li>
            <li>CO₂e Avoided (kg) = round(diverted kg × {CO2E_KG_PER_KG_DIVERTED}).</li>
            <li>Avg Pickup Time (mins) = mean of (claim collectedAt − listing addedAt) in minutes across collected claims; shows -- when no collected timestamp exists.</li>
          </ul>
          <ul className="impact-methodology-list">
            {IMPACT_ASSUMPTIONS.map((line) => (
              <li key={line}>{line}</li>
            ))}
          </ul>
          <p className="impact-methodology-note">
            All figures use synthetic demo data for Koramangala and Indiranagar.
          </p>
        </details>
      </section>

      <section className="impact-section" aria-labelledby="impact-split-heading">
        <h2 id="impact-split-heading" className="impact-heading">
          Share of posted portions
        </h2>
        {impact.posted === 0 ? (
          <p className="impact-empty">No listings posted yet.</p>
        ) : (
          <>
            <div className="impact-bar" role="img" aria-label={`Of ${impact.posted} posted: ${impact.collected} collected, ${claimedNotCollected} claimed but not collected, ${unclaimed} unclaimed.`}>
              <div className="impact-bar-segment impact-bar-segment--collected" style={{ width: `${collectedPct}%` }} />
              <div className="impact-bar-segment impact-bar-segment--claimed" style={{ width: `${claimedPct}%` }} />
              <div className="impact-bar-segment impact-bar-segment--unclaimed" style={{ width: `${unclaimedPct}%` }} />
            </div>
            <ul className="impact-legend">
              <li><span className="impact-swatch impact-swatch--collected" aria-hidden="true" />Collected: {impact.collected}</li>
              <li><span className="impact-swatch impact-swatch--claimed" aria-hidden="true" />Claimed, not collected: {claimedNotCollected}</li>
              <li><span className="impact-swatch impact-swatch--unclaimed" aria-hidden="true" />Unclaimed: {unclaimed}</li>
            </ul>
          </>
        )}
      </section>

      <section className="impact-section" aria-labelledby="impact-meals-heading">
        <h2 id="impact-meals-heading" className="impact-heading">
          Meals
        </h2>
        <p className="impact-meals">Estimated meals rescued: {impact.mealsEstimate}</p>
        <p className="impact-note">Meals = confirmed kg ÷ {KG_PER_MEAL} kg per meal, rounded.</p>
      </section>

      <section className="impact-section" aria-labelledby="impact-weekly-heading">
        <h2 id="impact-weekly-heading" className="impact-heading">
          Weekly activity
        </h2>
        <p className="impact-chart-caption" id="impact-weekly-caption">
          Collected portions, last 7 days
        </p>
        <div className="impact-chart" aria-hidden="true">
          {impact.weekly.map((point) => (
            <div key={point.date} className="impact-chart-col" title={`${point.label}: ${point.collected}`}>
              <div className="impact-chart-bar-track">
                <div
                  className="impact-chart-bar"
                  style={{
                    height: point.collected > 0 && weeklyMax > 0 ? `${(point.collected / weeklyMax) * 100}%` : '2px',
                  }}
                />
              </div>
              <span className="impact-chart-day">{point.label}</span>
            </div>
          ))}
        </div>
        <ul className="impact-visually-hidden">
          {impact.weekly.map((point) => (
            <li key={point.date}>
              {point.label}: {point.collected} collected
            </li>
          ))}
        </ul>
      </section>

      <BusinessModelSection />
      <p className="impact-footnote">
        Figures come from this demo's local data and do not represent a real audited record.
      </p>
    </div>
  );
}
