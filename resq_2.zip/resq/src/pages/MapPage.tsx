import { useMemo, useState } from 'react';
import { FilterBar } from '../components/FilterBar';
import { MapView } from '../components/MapView';
import { MarkerPreview } from '../components/MarkerPreview';
import { NearbyPanel } from '../components/NearbyPanel';
import { SearchBar } from '../components/SearchBar';
import { useAppState } from '../context/AppStateContext';
import { filterListings } from '../lib/filterListings';

export function MapPage() {
  const { listings, now, category, query, availableOnly, sort, openListing } = useAppState();
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const filtered = useMemo(
    () => filterListings(listings, { category, query, availableOnly, sort }, now),
    [listings, category, query, availableOnly, sort, now],
  );

  const selected = filtered.find((item) => item.id === selectedId) ?? null;

  return (
    <div className="map-page">
      <h1 className="page-title">Map</h1>
      <div className="discover-tools">
        <SearchBar />
        <FilterBar />
      </div>
      <div className="map-layout">
        <div className="map-area">
          <MapView listings={filtered} selectedId={selectedId} onSelect={setSelectedId} />
          {selected ? (
            <MarkerPreview listing={selected} onViewDetails={openListing} />
          ) : (
            <p className="map-hint">Select a marker on the map to preview a pickup.</p>
          )}
        </div>
        <NearbyPanel listings={filtered} selectedId={selectedId} onSelect={setSelectedId} />
      </div>
    </div>
  );
}
