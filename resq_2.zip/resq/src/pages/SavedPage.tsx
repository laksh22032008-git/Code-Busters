import { Link } from 'react-router-dom';
import { FoodGrid } from '../components/FoodGrid';
import { useAppState } from '../context/AppStateContext';

export function SavedPage() {
  const { listings, saved } = useAppState();
  const savedListings = listings.filter((item) => saved.has(item.id));

  return (
    <section className="saved-page">
      <h1 className="page-title">Saved</h1>
      <p className="page-description">Food you have saved for later. Saved items stay on this device.</p>
      {savedListings.length === 0 ? (
        <div className="empty-state">
          <p>Nothing saved yet.</p>
          <Link to="/discover" className="primary-button">
            Discover food
          </Link>
        </div>
      ) : (
        <FoodGrid listings={savedListings} />
      )}
    </section>
  );
}
