import { useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAppState } from '../context/AppStateContext';
import type { ReservationView } from '../provider/types';
import '../styles/reservations.css';

type Tab = 'upcoming' | 'past';

const STATUS_LABEL: Record<ReservationView['reservationStatus'], string> = {
  reserved: 'Reserved',
  collected: 'Collected',
  cancelled: 'Cancelled',
  expired: 'Expired',
};

const STATUS_PILL: Record<ReservationView['reservationStatus'], string> = {
  reserved: 'hl-pill',
  collected: 'hl-pill hl-pill--neutral',
  cancelled: 'hl-pill hl-pill--muted',
  expired: 'hl-pill hl-pill--muted',
};

function formatWhen(iso: string): string {
  return new Date(iso).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' });
}

interface ReservationRowProps {
  item: ReservationView;
}

function ReservationRow({ item }: ReservationRowProps) {
  const { cancelClaim, removeReservation, showToast } = useAppState();
  const submittingRef = useRef(false);
  const removingRef = useRef(false);
  const [confirming, setConfirming] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { claim, reservationStatus } = item;

  function confirmCancel() {
    if (submittingRef.current) return;
    submittingRef.current = true;
    const result = cancelClaim(claim.id);
    submittingRef.current = false;
    if (result.ok) {
      setConfirming(false);
      setError(null);
      showToast('Reservation cancelled. The portions are back on the listing.');
    } else {
      setError(result.error);
    }
  }

  function removeFromList() {
    if (removingRef.current) return;
    removingRef.current = true;
    const result = removeReservation(claim.id);
    if (result.ok) {
      setError(null);
      return;
    }
    removingRef.current = false;
    setError(result.error);
  }

  return (
    <li className="reservation-row">
      <img className="reservation-thumb" src={item.imageSrc} alt="" />
      <div className="reservation-main">
        <div className="reservation-heading">
          <p className="reservation-name">{item.listingName}</p>
          <span className={`${STATUS_PILL[reservationStatus]} reservation-status reservation-status-${reservationStatus}`}>
            {STATUS_LABEL[reservationStatus]}
          </span>
        </div>
        <p className="reservation-vendor">{item.vendorName}</p>
        <p className="reservation-meta">
          {claim.portions === 1 ? '1 portion' : `${claim.portions} portions`} · Pick up by{' '}
          {formatWhen(item.pickupDeadline)}
        </p>
        <p className="reservation-meta">Reserved {formatWhen(claim.claimedAt)}</p>
        <p className="reservation-code">
          Code <span className="reservation-code-value">{claim.code}</span>
        </p>
      </div>
      {reservationStatus === 'reserved' ? (
        <div className="reservation-actions">
          {confirming ? (
            <>
              <p className="reservation-confirm-text">Cancel this reservation? The portions return to the listing.</p>
              <div className="reservation-confirm-buttons">
                <button
                  type="button"
                  className="reservation-button"
                  onClick={() => {
                    setConfirming(false);
                    setError(null);
                  }}
                >
                  Keep it
                </button>
                <button type="button" className="reservation-button reservation-button-danger" onClick={confirmCancel}>
                  Yes, cancel
                </button>
              </div>
            </>
          ) : (
            <button type="button" className="reservation-button" onClick={() => setConfirming(true)}>
              Cancel reservation
            </button>
          )}
          {error ? (
            <p role="alert" className="reservation-error">
              {error}
            </p>
          ) : null}
        </div>
      ) : null}
      {reservationStatus !== 'reserved' ? (
        <div className="reservation-actions">
          <button
            type="button"
            className="reservation-button"
            aria-label="Remove this reservation from your list"
            onClick={removeFromList}
          >
            Remove
          </button>
          {error ? (
            <p role="alert" className="reservation-error">
              {error}
            </p>
          ) : null}
        </div>
      ) : null}
    </li>
  );
}

export function ReservationsPage() {
  const { reservations } = useAppState();
  const [tab, setTab] = useState<Tab>('upcoming');
  const upcoming = reservations.filter((item) => item.reservationStatus === 'reserved');
  const past = reservations.filter((item) => item.reservationStatus !== 'reserved');
  const visible = tab === 'upcoming' ? upcoming : past;

  return (
    <section className="reservations-page">
      <h1 className="page-title">My reservations</h1>
      <p className="page-description">Pickups you have claimed on this device.</p>

      <div className="reservation-tabs" role="group" aria-label="Show reservations">
        <button
          type="button"
          className="reservation-tab"
          aria-pressed={tab === 'upcoming'}
          onClick={() => setTab('upcoming')}
        >
          Upcoming <span className="reservation-count">{upcoming.length}</span>
        </button>
        <button type="button" className="reservation-tab" aria-pressed={tab === 'past'} onClick={() => setTab('past')}>
          Past <span className="reservation-count">{past.length}</span>
        </button>
      </div>

      {visible.length === 0 ? (
        tab === 'upcoming' ? (
          <div className="empty-state">
            <p>No upcoming pickups.</p>
            <Link to="/discover" className="text-link">
              Find food near you
            </Link>
          </div>
        ) : (
          <div className="empty-state">
            <p>Past pickups will appear here.</p>
          </div>
        )
      ) : (
        <ul className="reservation-list">
          {visible.map((item) => (
            <ReservationRow key={item.claim.id} item={item} />
          ))}
        </ul>
      )}
    </section>
  );
}
