import { useCallback, useEffect, useRef, useState } from 'react';
import { migrateVendorNames, seedProviderState } from './store';
import type { ProviderState } from './types';

export const PROVIDER_KEY = 'resqfood.provider.v1';

function readProvider(): ProviderState {
  try {
    const raw = window.localStorage.getItem(PROVIDER_KEY);
    if (raw) {
      const parsed: unknown = JSON.parse(raw);
      if (typeof parsed === 'object' && parsed !== null && 'version' in parsed && parsed.version === 1) {
        return migrateVendorNames(parsed as ProviderState);
      }
    }
  } catch {
    // Corrupt JSON falls through to the seed state below.
  }
  return seedProviderState(Date.now());
}

export function useProviderState() {
  const [provider, setProvider] = useState<ProviderState>(readProvider);
  const latest = useRef<ProviderState>(provider);

  useEffect(() => {
    window.localStorage.setItem(PROVIDER_KEY, JSON.stringify(provider));
  }, [provider]);

  const commit = useCallback((next: ProviderState) => {
    latest.current = next;
    setProvider(next);
  }, []);

  const getLatest = useCallback(() => latest.current, []);

  return { provider, commit, getLatest };
}
