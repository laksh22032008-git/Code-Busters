import type { Category, Listing } from '../data/types';
import type {
  ListingAllocation,
  ListingStatus,
  PickupClaim,
  ProviderListingRecord,
  ProviderListingView,
  ProviderState,
} from './types';
import { PROVIDER_BUSINESS_NAME } from '../data/vendors';
import { isActiveClaim } from '../lib/reservation';
import { KG_PER_MEAL } from '../lib/impactConstants';

/** Vendor id used for the provider's own listings. */
export const PROVIDER_VENDOR_ID = 'green-leaf';

const HOUR_MS = 60 * 60 * 1000;
const EXPIRING_WINDOW_MS = HOUR_MS;
const DAY_LABELS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export interface DashboardMetrics {
  activeListings: number;
  portionsAvailable: number;
  portionsClaimed: number;
  pickupsAwaiting: number;
  portionsRescued: number;
  expiringSoon: ProviderListingView[];
}

export interface WeeklyImpactPoint {
  label: string;
  date: string;
  collected: number;
}

export interface ImpactSummary {
  /** Portions on non-cancelled listings. */
  posted: number;
  /** Portions with an active (reserved or ready) or collected claim. */
  claimed: number;
  /** Portions with a confirmed pickup (collected claims). Only these feed the impact figures. */
  collected: number;
  /** Confirmed kg: listing quantityKg prorated by confirmed share, else portions × KG_PER_MEAL. */
  collectedKg: number;
  /** Confirmed kg ÷ KG_PER_MEAL, rounded. */
  mealsEstimate: number;
  weekly: WeeklyImpactPoint[];
}

function sum<T>(items: T[], pick: (item: T) => number): number {
  return items.reduce((total, item) => total + pick(item), 0);
}

export { isActiveClaim };

/** Portions held by reserved or ready claims for one listing. */
export function activeClaimedFor(listingId: string, claims: PickupClaim[]): number {
  return sum(
    claims.filter((claim) => claim.listingId === listingId && isActiveClaim(claim)),
    (claim) => claim.portions,
  );
}

/** Portions still open to claim: total minus active claims minus collected. Never negative. */
export function remainingFor(record: ProviderListingRecord, claims: PickupClaim[]): number {
  const left = record.portionsTotal - activeClaimedFor(record.id, claims) - record.collectedPortions;
  return Math.max(0, left);
}

export function deriveStatus(
  record: ProviderListingRecord,
  claims: PickupClaim[],
  now: number,
): ListingStatus {
  if (record.cancelled) return 'cancelled';
  if (record.collectedPortions >= record.portionsTotal) return 'collected';
  if (Date.parse(record.pickupDeadline) <= now) return 'expired';
  if (remainingFor(record, claims) <= 0) return 'fully-claimed';
  return 'active';
}

function buildView(
  record: ProviderListingRecord,
  claims: PickupClaim[],
  now: number,
): ProviderListingView {
  return {
    record,
    status: deriveStatus(record, claims, now),
    portionsClaimed: activeClaimedFor(record.id, claims),
    portionsRemaining: remainingFor(record, claims),
    portionsCollected: record.collectedPortions,
    claims: claims.filter((claim) => claim.listingId === record.id),
  };
}

export function providerListingViews(state: ProviderState, now: number): ProviderListingView[] {
  return state.listings.map((record) => buildView(record, state.claims, now));
}

export function getDashboardMetrics(state: ProviderState, now: number): DashboardMetrics {
  const views = providerListingViews(state, now);
  const active = views.filter((view) => view.status === 'active');
  const ownIds = new Set(state.listings.map((record) => record.id));
  const expiringSoon = active
    .filter((view) => Date.parse(view.record.pickupDeadline) - now <= EXPIRING_WINDOW_MS)
    .sort((a, b) => Date.parse(a.record.pickupDeadline) - Date.parse(b.record.pickupDeadline));

  return {
    activeListings: active.length,
    portionsAvailable: sum(active, (view) => view.portionsRemaining),
    portionsClaimed: sum(
      views.filter((view) => !view.record.cancelled),
      (view) => view.portionsClaimed,
    ),
    pickupsAwaiting: state.claims.filter(
      (claim) => ownIds.has(claim.listingId) && isActiveClaim(claim),
    ).length,
    portionsRescued: sum(views, (view) => view.portionsCollected),
    expiringSoon,
  };
}

function toListing(view: ProviderListingView): Listing {
  const r = view.record;
  return {
    id: r.id,
    name: r.name,
    vendorId: r.vendorId,
    vendor: r.vendor,
    area: r.area,
    distanceKm: r.distanceKm,
    portionsRemaining: view.portionsRemaining,
    portionsTotal: r.portionsTotal,
    price: r.price,
    originalPrice: r.originalPrice,
    isVeg: r.isVeg,
    category: r.category,
    tags: r.tags,
    pickupStart: r.pickupStart,
    pickupDeadline: r.pickupDeadline,
    addedAt: r.addedAt,
    image: r.image,
    x: r.x,
    y: r.y,
    handling: r.handling,
    allergens: r.allergens,
    feedback: [],
  };
}

/** Seeker-facing listings: drops the provider's own sample rows and merges vendor records. */
export function mergeListings(base: Listing[], state: ProviderState, now: number): Listing[] {
  const removed = new Set(state.removedListingIds ?? []);
  const external = base
    .filter((listing) => listing.vendorId !== PROVIDER_VENDOR_ID && !removed.has(listing.id))
    .map((listing) => {
      const taken = activeClaimedFor(listing.id, state.claims);
      if (taken === 0) return listing;
      return { ...listing, portionsRemaining: Math.max(0, listing.portionsRemaining - taken) };
    });
  const own = providerListingViews(state, now)
    .filter((view) => !view.record.cancelled)
    .map(toListing);
  return [...external, ...own];
}

const MIN = 60 * 1000;
const SAMPLE_VENDOR = PROVIDER_BUSINESS_NAME;
const at = (ms: number): string => new Date(ms).toISOString();

interface SampleSpec {
  id: string;
  name: string;
  image: string;
  category: Category;
  isVeg: boolean;
  portionsTotal: number;
  price: number;
  originalPrice: number;
  deadlineMin: number;
  allocation: ListingAllocation;
  allergens: string[];
  prepared: string;
  distanceKm: number;
  x: number;
  y: number;
}

const SAMPLES: SampleSpec[] = [
  { id: 'gl-1', name: 'Vegetable Pulao Box', image: '/food/photos/pulao.jpg', category: 'Meals', isVeg: true, portionsTotal: 12, price: 60, originalPrice: 180, deadlineMin: 35, allocation: 'open', allergens: ['Nuts', 'Dairy'], prepared: 'Cooked at 4 pm today', distanceKm: 0.4, x: 38, y: 42 },
  { id: 'gl-2', name: 'Rice Thali, Free Meal', image: '/food/photos/rice-thali.jpg', category: 'Meals', isVeg: true, portionsTotal: 8, price: 0, originalPrice: 150, deadlineMin: 70, allocation: 'split', allergens: ['Gluten'], prepared: 'Cooked at 5 pm today', distanceKm: 0.8, x: 62, y: 35 },
  { id: 'gl-3', name: 'Chapati and Curry Set', image: '/food/photos/chapati-curry.jpg', category: 'Meals', isVeg: false, portionsTotal: 10, price: 40, originalPrice: 120, deadlineMin: 180, allocation: 'bulk', allergens: ['Gluten'], prepared: 'Cooked at 6 pm today', distanceKm: 1.1, x: 50, y: 58 },
  { id: 'gl-4', name: 'Paneer Meal Box', image: '/food/photos/paneer-meal.jpg', category: 'Meals', isVeg: true, portionsTotal: 6, price: 70, originalPrice: 210, deadlineMin: 300, allocation: 'open', allergens: ['Dairy'], prepared: 'Cooked at 3 pm today', distanceKm: 0.7, x: 28, y: 60 },
  { id: 'gl-5', name: 'Millet Bowl', image: '/food/photos/millet-bowl.jpg', category: 'Snacks', isVeg: true, portionsTotal: 5, price: 50, originalPrice: 150, deadlineMin: -30, allocation: 'open', allergens: [], prepared: 'Cooked at 2 pm today', distanceKm: 1.4, x: 70, y: 70 },
];

function sampleRecord(spec: SampleSpec, now: number): ProviderListingRecord {
  const deadline = now + spec.deadlineMin * MIN;
  return {
    id: spec.id,
    name: spec.name,
    vendorId: PROVIDER_VENDOR_ID,
    vendor: SAMPLE_VENDOR,
    area: 'Indiranagar',
    distanceKm: spec.distanceKm,
    portionsTotal: spec.portionsTotal,
    price: spec.price,
    originalPrice: spec.originalPrice,
    isVeg: spec.isVeg,
    category: spec.category,
    tags: [],
    pickupStart: at(deadline - 60 * MIN),
    pickupDeadline: at(deadline),
    addedAt: at(now - 2 * 60 * MIN),
    image: spec.image,
    x: spec.x,
    y: spec.y,
    handling: {
      preparedAt: spec.prepared,
      storage: 'Keep covered and chilled until pickup',
      reheating: 'Heat until piping hot before eating',
      providerNote: 'Packed fresh by the kitchen team.',
    },
    allergens: [...spec.allergens],
    allocation: spec.allocation,
    cancelled: false,
    cancelReason: '',
    // Confirmed collections are derived from claims in seedProviderState, not stored here.
    collectedPortions: 0,
    origin: 'sample',
  };
}

/** The five seeded listings for the provider, with deadlines relative to now. */
export function buildSampleListings(now: number): ProviderListingRecord[] {
  return SAMPLES.map((spec) => sampleRecord(spec, now));
}

/** Local calendar date as YYYY-MM-DD. */
function localDateKey(date: Date): string {
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${date.getFullYear()}-${month}-${day}`;
}

/** Portions with a confirmed pickup (collected claim) for one listing. */
export function confirmedPortionsFor(listingId: string, claims: PickupClaim[]): number {
  return sum(
    claims.filter((claim) => claim.listingId === listingId && claim.status === 'collected'),
    (claim) => claim.portions,
  );
}

/** Confirmed kg for one listing: quantityKg prorated by confirmed share when present, else portions × KG_PER_MEAL. */
export function confirmedKgFor(record: ProviderListingRecord, claims: PickupClaim[]): number {
  const portions = confirmedPortionsFor(record.id, claims);
  if (portions <= 0) return 0;
  const quantity = record.quantityKg;
  if (quantity !== undefined && quantity > 0 && record.portionsTotal > 0) {
    return quantity * (portions / record.portionsTotal);
  }
  return portions * KG_PER_MEAL;
}

export function getImpact(state: ProviderState, now: number): ImpactSummary {
  const today = new Date(now);
  const ownIds = new Set(state.listings.map((record) => record.id));
  const live = state.listings.filter((record) => !record.cancelled);
  const countedClaims = state.claims.filter(
    (claim) =>
      ownIds.has(claim.listingId) &&
      (isActiveClaim(claim) || claim.status === 'collected'),
  );
  const confirmedClaims = state.claims.filter(
    (claim) => ownIds.has(claim.listingId) && claim.status === 'collected',
  );
  const collected = sum(confirmedClaims, (claim) => claim.portions);
  const collectedKg = sum(state.listings, (record) => confirmedKgFor(record, state.claims));

  const weekly: WeeklyImpactPoint[] = [];
  for (let offset = 6; offset >= 0; offset -= 1) {
    const day = new Date(today.getFullYear(), today.getMonth(), today.getDate() - offset);
    const key = localDateKey(day);
    const dayCollected = sum(
      confirmedClaims.filter(
        (claim) =>
          claim.collectedAt !== '' &&
          localDateKey(new Date(claim.collectedAt)) === key,
      ),
      (claim) => claim.portions,
    );
    weekly.push({ label: DAY_LABELS[day.getDay()], date: key, collected: dayCollected });
  }

  return {
    posted: sum(live, (record) => record.portionsTotal),
    claimed: sum(countedClaims, (claim) => claim.portions),
    collected,
    collectedKg,
    mealsEstimate: Math.round(collectedKg / KG_PER_MEAL),
    weekly,
  };
}
