export type PhotoResult = { ok: true; dataUrl: string } | { ok: false; error: string };

const MAX_BYTES = 8000000;
const MAX_SIDE = 800;
const ACCEPTED_TYPES: string[] = ['image/jpeg', 'image/png', 'image/webp'];

function loadImage(url: string): Promise<HTMLImageElement | null> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = url;
  });
}

export async function readImageAsDataUrl(file: File): Promise<PhotoResult> {
  if (typeof document === 'undefined') {
    return { ok: false, error: 'Photos can only be read in a browser.' };
  }
  if (file.size > MAX_BYTES) {
    return { ok: false, error: 'That photo is over 8 MB. Choose a smaller image.' };
  }
  if (!ACCEPTED_TYPES.includes(file.type)) {
    return { ok: false, error: 'Use a JPEG, PNG or WebP photo.' };
  }

  const url = URL.createObjectURL(file);
  const img = await loadImage(url);
  if (!img) {
    URL.revokeObjectURL(url);
    return { ok: false, error: 'That file could not be read as an image.' };
  }

  const scale = Math.min(1, MAX_SIDE / Math.max(img.naturalWidth, img.naturalHeight));
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(img.naturalWidth * scale);
  canvas.height = Math.round(img.naturalHeight * scale);
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    URL.revokeObjectURL(url);
    return { ok: false, error: 'This photo could not be processed in this browser.' };
  }

  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
  URL.revokeObjectURL(url);
  return { ok: true, dataUrl };
}
