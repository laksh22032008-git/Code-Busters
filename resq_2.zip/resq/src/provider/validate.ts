const MAX_WINDOW_MS = 24 * 60 * 60 * 1000;
const ISO_PREFIX = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/;
const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

/** Returns a copy of patch without keys whose value is undefined. */
export function stripUndefined<T extends object>(patch: T): Partial<T> {
  return Object.fromEntries(
    Object.entries(patch).filter(([, value]) => value !== undefined),
  ) as Partial<T>;
}

/** Builds an id from a prefix and time, appending a counter if the id is taken. */
export function uniqueId(prefix: string, now: number, taken: Set<string>): string {
  const base = prefix + now.toString(36);
  let id = base;
  let n = 1;
  while (taken.has(id)) {
    id = `${base}-${n}`;
    n += 1;
  }
  return id;
}

/** Makes a pickup code like DEMO-7K2Q that is not in the taken set. */
export function makeCode(taken: Set<string>): string {
  for (;;) {
    let body = '';
    for (let i = 0; i < 4; i += 1) {
      body += CODE_CHARS.charAt(Math.floor(Math.random() * CODE_CHARS.length));
    }
    const code = `DEMO-${body}`;
    if (!taken.has(code)) return code;
  }
}

/** Returns an error sentence, or null when the name is valid. */
export function checkName(name: string): string | null {
  const length = name.trim().length;
  if (length < 2 || length > 60) return 'Name must be between 2 and 60 characters.';
  return null;
}

/** Returns an error sentence, or null when the portion count is valid. */
export function checkPortions(portions: number): string | null {
  if (!Number.isInteger(portions) || portions < 1 || portions > 200) {
    return 'Portions must be a whole number from 1 to 200.';
  }
  return null;
}

/** Returns an error sentence, or null. A price of 0 with isFree is accepted. */
export function checkPrices(isFree: boolean, price: number, originalPrice: number): string | null {
  if (!Number.isFinite(originalPrice) || originalPrice < 0) {
    return 'Original price must be zero or more.';
  }
  if (isFree) return null;
  if (!Number.isFinite(price) || price < 1) return 'Price must be at least 1.';
  if (originalPrice <= price) return 'Original price must be higher than the discounted price.';
  return null;
}

/** Returns an error sentence, or null when the pickup window is valid at time now. */
export function checkTimes(start: string, deadline: string, now: number): string | null {
  if (!ISO_PREFIX.test(start) || !ISO_PREFIX.test(deadline)) {
    return 'Pickup times must be ISO date and time values.';
  }
  const startMs = Date.parse(start);
  const deadlineMs = Date.parse(deadline);
  if (Number.isNaN(startMs) || Number.isNaN(deadlineMs)) {
    return 'Pickup times must be valid dates.';
  }
  if (startMs >= deadlineMs) return 'The pickup must start before its deadline.';
  if (deadlineMs <= now) return 'The pickup deadline must be in the future.';
  if (deadlineMs - now > MAX_WINDOW_MS) return 'The pickup deadline must be within 24 hours.';
  return null;
}

/** Normalises a validated ISO-like string to a full ISO timestamp. */
export function toIso(value: string): string {
  return new Date(Date.parse(value)).toISOString();
}
