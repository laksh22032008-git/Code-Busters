import type { Category } from '../data/types';
import type { ListingAllocation, PostListingInput, ProviderListingRecord } from './types';
import { checkName, checkPortions, checkPrices, checkTimes } from './validate';

export const PHOTO_OPTIONS: { label: string; path: string }[] = [
  { label: 'Vegetable pulao', path: '/food/photos/pulao.jpg' },
  { label: 'Rice thali', path: '/food/photos/rice-thali.jpg' },
  { label: 'Chapati and curry', path: '/food/photos/chapati-curry.jpg' },
  { label: 'Paneer meal box', path: '/food/photos/paneer-meal.jpg' },
  { label: 'Millet bowl', path: '/food/photos/millet-bowl.jpg' },
  { label: 'Biryani', path: '/food/photos/biryani.jpg' },
  { label: 'Vegetable biryani', path: '/food/photos/veg-biryani.jpg' },
  { label: 'Chicken wrap', path: '/food/photos/chicken-wrap.jpg' },
  { label: 'Idli and dosa', path: '/food/photos/idli-dosa.jpg' },
  { label: 'Sandwich', path: '/food/photos/sandwich.jpg' },
  { label: 'Croissant', path: '/food/photos/croissant.jpg' },
  { label: 'Bakery selection', path: '/food/photos/bakery.jpg' },
];

export const CATEGORY_OPTIONS: Category[] = ['Meals', 'Bakery', 'Snacks'];

export const QUICK_FOOD_PRESETS: { label: string; name: string; category: Category; isVeg: boolean; image: string }[] = [
  { label: 'Steamed Rice & Dal', name: 'Steamed Rice & Dal', category: 'Meals', isVeg: true, image: '/food/photos/rice-thali.jpg' },
  { label: 'Rotis & Paneer Sabzi', name: 'Rotis & Paneer Sabzi', category: 'Meals', isVeg: true, image: '/food/photos/paneer-meal.jpg' },
  { label: 'Biryani Trays', name: 'Biryani Trays', category: 'Meals', isVeg: false, image: '/food/photos/biryani.jpg' },
  { label: 'Packed Meal Boxes', name: 'Packed Meal Boxes', category: 'Meals', isVeg: true, image: '/food/photos/sandwich.jpg' },
];

export const STORAGE_OPTIONS = ['Hot-held >60°C', 'Room Temp', 'Chilled'] as const;

export const ALLERGEN_OPTIONS = ['Dairy', 'Nuts', 'Gluten', 'None'] as const;

export const ALLOCATION_OPTIONS: { value: ListingAllocation; label: string }[] = [
  { value: 'open', label: 'Open to everyone' },
  { value: 'bulk', label: 'Bulk rescue' },
  { value: 'split', label: 'Split allocation' },
];

export type QuickPostField = 'name' | 'portions' | 'price' | 'originalPrice' | 'start' | 'deadline';
export type QuickPostErrors = Partial<Record<QuickPostField, string>>;

/** Display order of fields, used to focus the first invalid one. */
export const FIELD_ORDER: QuickPostField[] = ['name', 'portions', 'price', 'originalPrice', 'start', 'deadline'];
export const FIELD_IDS: Record<QuickPostField, string> = {
  name: 'qp-name',
  portions: 'qp-portions',
  price: 'qp-price',
  originalPrice: 'qp-original-price',
  start: 'qp-start',
  deadline: 'qp-deadline',
};

export interface QuickPostForm {
  name: string;
  category: Category;
  isVeg: boolean;
  portions: number;
  quantityKg: number;
  image: string;
  isFree: boolean;
  price: string;
  originalPrice: string;
  allocation: ListingAllocation;
  area: string;
  date: string;
  start: string;
  deadline: string;
  preparedAt: string;
  storage: string;
  reheating: string;
  providerNote: string;
  allergens: string;
}

const MIN = 60 * 1000;
const ROUND_MS = 5 * MIN;
const pad = (value: number): string => String(value).padStart(2, '0');

export function dateValue(ms: number): string {
  const d = new Date(ms);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function timeValue(ms: number): string {
  const d = new Date(ms);
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

/** Quick-post pickup window: starts 5 minutes from now and ends after `hours`. */
export function quickDeadline(now: number, hours: 1 | 2 | 3): { date: string; start: string; deadline: string } {
  return {
    date: dateValue(now),
    start: timeValue(now + 5 * MIN),
    deadline: timeValue(now + hours * 60 * MIN),
  };
}

/** Combines a local date (YYYY-MM-DD) and time (HH:mm) into an ISO string, or '' if invalid. */
export function toIsoPair(date: string, time: string): string {
  const parsed = new Date(`${date}T${time}`);
  return Number.isNaN(parsed.getTime()) ? '' : parsed.toISOString();
}

/** Formats an ISO-like local date and time as a clock label, or '--' if invalid. */
export function formatClock(date: string, time: string): string {
  const iso = toIsoPair(date, time);
  return iso ? new Date(iso).toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit' }) : '--';
}

export function parseAllergens(text: string): string[] {
  return text
    .split(',')
    .map((item) => item.trim())
    .filter((item) => item.length > 0);
}

export function defaultForm(now: number, area: string): QuickPostForm {
  const todayEnd = new Date(now);
  todayEnd.setHours(23, 55, 0, 0);
  const cap = todayEnd.getTime();
  const roundUp = (ms: number): number => Math.min(Math.ceil(ms / ROUND_MS) * ROUND_MS, cap);
  const start = roundUp(now + 30 * MIN);
  const deadline = roundUp(now + 120 * MIN);
  return {
    name: '',
    category: 'Meals',
    isVeg: true,
    portions: 12,
    quantityKg: 5,
    image: PHOTO_OPTIONS[0].path,
    isFree: true,
    price: '',
    originalPrice: '',
    allocation: 'open',
    area,
    date: dateValue(now),
    start: timeValue(start),
    deadline: timeValue(deadline),
    preparedAt: '',
    storage: 'Hot-held >60°C',
    reheating: '',
    providerNote: '',
    allergens: '',
  };
}

/** Copies the reusable parts of a previous listing; pickup times and portions are kept from current. */
export function formFromRecord(record: ProviderListingRecord, current: QuickPostForm): QuickPostForm {
  return {
    ...current,
    name: record.name,
    category: record.category,
    isVeg: record.isVeg,
    image: record.image,
    isFree: record.price === 0,
    price: record.price > 0 ? String(record.price) : '',
    originalPrice: record.originalPrice > 0 ? String(record.originalPrice) : '',
    allocation: record.allocation,
    area: record.area,
    preparedAt: record.handling.preparedAt,
    storage: record.handling.storage,
    reheating: record.handling.reheating,
    providerNote: record.handling.providerNote,
    allergens: record.allergens.join(', '),
  };
}

/** Most recent listing per unique name, newest first. */
export function recentUniqueListings(records: ProviderListingRecord[]): ProviderListingRecord[] {
  const sorted = [...records].sort((a, b) => Date.parse(b.addedAt) - Date.parse(a.addedAt));
  const seen = new Set<string>();
  const unique: ProviderListingRecord[] = [];
  for (const record of sorted) {
    const key = record.name.trim().toLowerCase();
    if (!seen.has(key)) {
      seen.add(key);
      unique.push(record);
    }
  }
  return unique;
}

export function validateForm(form: QuickPostForm, now: number): QuickPostErrors {
  const errors: QuickPostErrors = {};
  const nameError = checkName(form.name);
  if (nameError) errors.name = nameError;

  const portionError = checkPortions(form.portions);
  if (portionError) errors.portions = portionError;

  if (!form.isFree) {
    if (form.price.trim() === '') errors.price = 'Enter the discounted price.';
    if (form.originalPrice.trim() === '') errors.originalPrice = 'Enter the original price.';
  }
  const priceError = checkPrices(
    form.isFree,
    form.isFree ? 0 : Number(form.price),
    form.isFree ? 0 : Number(form.originalPrice),
  );
  if (priceError && !errors.price && !errors.originalPrice) {
    if (priceError.startsWith('Original')) errors.originalPrice = priceError;
    else errors.price = priceError;
  }

  const startIso = toIsoPair(form.date, form.start);
  const deadlineIso = toIsoPair(form.date, form.deadline);
  if (!startIso) {
    errors.start = 'Enter a valid pickup start time.';
  } else if (!deadlineIso) {
    errors.deadline = 'Enter a valid pickup deadline.';
  } else {
    const timeError = checkTimes(startIso, deadlineIso, now);
    if (timeError) errors.deadline = timeError;
  }
  return errors;
}

export function buildInput(form: QuickPostForm): PostListingInput {
  return {
    name: form.name.trim(),
    category: form.category,
    isVeg: form.isVeg,
    portions: form.portions,
    quantityKg: form.quantityKg,
    isFree: form.isFree,
    price: form.isFree ? 0 : Number(form.price),
    originalPrice: form.isFree ? 0 : Number(form.originalPrice),
    allocation: form.allocation,
    pickupStart: toIsoPair(form.date, form.start),
    pickupDeadline: toIsoPair(form.date, form.deadline),
    area: form.area,
    handling: {
      preparedAt: form.preparedAt.trim(),
      storage: form.storage.trim(),
      reheating: form.reheating.trim(),
      providerNote: form.providerNote.trim(),
    },
    allergens: parseAllergens(form.allergens),
    image: form.image,
  };
}
