import type { Listing } from '../data/types';
import { PROVIDER_BUSINESS_NAME, findVendor } from '../data/vendors';
import { vendorTrustStatus } from '../lib/trust';
import {
  PROVIDER_VENDOR_ID,
  activeClaimedFor,
  buildSampleListings,
  confirmedPortionsFor,
  deriveStatus,
  remainingFor,
} from './derive';
import { MAX_PORTIONS_PER_CLAIM, isActiveClaim } from '../lib/reservation';
import { claimNotification, type AppNotification } from '../lib/notifications';
import {
  checkName,
  checkPortions,
  checkPrices,
  checkTimes,
  makeCode,
  stripUndefined,
  toIso,
  uniqueId,
} from './validate';
import { DEMO_SEEKER_ID, REPORT_REASONS } from './types';
import type {
  ListingReport,
  PickupClaim,
  PostListingInput,
  ProviderListingRecord,
  ProviderProfile,
  ProviderState,
  ReservationView,
  Result,
  VendorLocation,
} from './types';

export {
  deriveStatus,
  getDashboardMetrics,
  getImpact,
  mergeListings,
  providerListingViews,
} from './derive';
export type { DashboardMetrics, ImpactSummary, WeeklyImpactPoint } from './derive';

const MIN = 60 * 1000;

/** Wrong codes allowed in a row before code entry is paused for a claim. */
const MAX_PICKUP_ATTEMPTS = 5;
/** How long code entry stays paused after too many wrong codes. */
const PICKUP_LOCK_MS = 5 * MIN;

/** Old demo vendor names mapped to their current display names. */
const VENDOR_NAME_RENAMES = new Map<string, string>([
  ['Green Leaf Kitchen', 'Copper Carrot Catering'],
  ['Daily Bowl', 'Moonlit Ladle Corporate Meals'],
  ['Urban Tiffin', 'The Hungry Comet Events'],
  ['Harvest Table', 'Willow Plate Weddings'],
  ['Fresh Fork Cafe', 'Fig & Fern Catering'],
  ['Annapurna Meals', 'Ember Spoon Wedding Kitchen'],
  ['Saffron Lane', 'Saffron Orbit Events'],
  ['Mantra Millets', 'Mellow Millet Corporate'],
]);

type ListingPatch = Partial<
  Pick<
    ProviderListingRecord,
    | 'name'
    | 'portionsTotal'
    | 'price'
    | 'originalPrice'
    | 'pickupStart'
    | 'pickupDeadline'
    | 'handling'
    | 'allergens'
    | 'allocation'
    | 'category'
    | 'isVeg'
    | 'area'
    | 'image'
  >
>;

const iso = (ms: number): string => new Date(ms).toISOString();

function fail(error: string): { ok: false; error: string } {
  return { ok: false, error };
}

function done(state: ProviderState): Result {
  return { ok: true, state };
}

function withValue<T>(state: ProviderState, value: T): Result<T> {
  return { ok: true, state, value };
}

/** Appends one generated notification to the state. Callers pass the already-updated state so it is one update. */
function notify(
  state: ProviderState,
  kind: AppNotification['kind'],
  listingName: string,
  portions: number,
  now: number,
): ProviderState {
  const existing = state.notifications ?? [];
  const id = uniqueId('ntf-', now, new Set(existing.map((item) => item.id)));
  return {
    ...state,
    notifications: [...existing, claimNotification(kind, listingName, portions, iso(now), id)],
  };
}

function expiredClaim(state: ProviderState, claim: PickupClaim, now: number): boolean {
  const record = state.listings.find((item) => item.id === claim.listingId);
  return record !== undefined && Date.parse(record.pickupDeadline) <= now;
}

export function seedProviderState(now: number): ProviderState {
  const claims: PickupClaim[] = [
    { id: 'clm-seed-1', listingId: 'gl-2', seekerId: 'seed-collector', portions: 2, code: 'DEMO-7K2Q', collectorName: 'Asha R.', claimedAt: iso(now - 20 * MIN), status: 'reserved', collectedAt: '' },
    { id: 'clm-seed-2', listingId: 'gl-1', seekerId: 'seed-collector', portions: 1, code: 'DEMO-3HPX', collectorName: 'Vikram S.', claimedAt: iso(now - 40 * MIN), status: 'ready', collectedAt: '' },
    { id: 'clm-seed-3', listingId: 'gl-4', seekerId: 'seed-collector', portions: 6, code: 'DEMO-9MTB', collectorName: 'Meera K.', claimedAt: iso(now - 180 * MIN), status: 'collected', collectedAt: iso(now - 120 * MIN) },
  ];
  return {
    version: 1,
    profile: {
      businessName: PROVIDER_BUSINESS_NAME,
      businessType: 'Restaurant',
      description: 'A family-run kitchen in Indiranagar that shares its extra meals before they go to waste.',
      area: 'Indiranagar',
      hours: '11:00 to 22:00 daily',
      contactPlaceholder: 'Contact details are added after sign-up',
      preferences: ['Meals'],
      location: {
        addressLine: 'Demo address, 100 Feet Road, Indiranagar',
        landmark: 'Near the main metro station',
        latitude: 12.9784,
        longitude: 77.6408,
        capturedVia: 'manual',
      },
    },
    // collectedPortions on each sample listing is the sum of its seeded collected claims, never a free-standing number.
    listings: buildSampleListings(now).map((record) => ({
      ...record,
      collectedPortions: confirmedPortionsFor(record.id, claims),
    })),
    claims,
  };
}

/** Renames stored old demo vendor names; any other (user-edited) name is kept. Returns a new object. */
export function migrateVendorNames(state: ProviderState): ProviderState {
  const rename = (name: string): string => VENDOR_NAME_RENAMES.get(name) ?? name;
  return {
    ...state,
    profile: { ...state.profile, businessName: rename(state.profile.businessName) },
    listings: state.listings.map((record) => ({ ...record, vendor: rename(record.vendor) })),
  };
}

export function postListing(
  state: ProviderState,
  input: PostListingInput,
  now: number,
): Result<ProviderListingRecord> {
  const name = input.name.trim();
  const nameError = checkName(name);
  if (nameError) return fail(nameError);
  const portionError = checkPortions(input.portions);
  if (portionError) return fail(portionError);
  const price = input.isFree ? 0 : input.price;
  const priceError = checkPrices(input.isFree, price, input.originalPrice);
  if (priceError) return fail(priceError);
  const timeError = checkTimes(input.pickupStart, input.pickupDeadline, now);
  if (timeError) return fail(timeError);

  const taken = new Set(state.listings.map((record) => record.id));
  const record: ProviderListingRecord = {
    id: uniqueId('vnd-', now, taken),
    name,
    vendorId: PROVIDER_VENDOR_ID,
    vendor: state.profile.businessName,
    area: input.area.trim() || state.profile.area,
    distanceKm: 0.5,
    portionsTotal: input.portions,
    price,
    originalPrice: input.originalPrice,
    isVeg: input.isVeg,
    category: input.category,
    tags: [],
    pickupStart: toIso(input.pickupStart),
    pickupDeadline: toIso(input.pickupDeadline),
    addedAt: iso(now),
    image: input.image,
    x: 50,
    y: 50,
    handling: input.handling,
    allergens: [...input.allergens],
    allocation: input.allocation,
    ...(input.quantityKg !== undefined ? { quantityKg: input.quantityKg } : {}),
    cancelled: false,
    cancelReason: '',
    collectedPortions: 0,
    origin: 'vendor',
  };
  return withValue({ ...state, listings: [...state.listings, record] }, record);
}

export function updateListing(
  state: ProviderState,
  id: string,
  patch: ListingPatch,
  now: number,
): Result {
  const current = state.listings.find((record) => record.id === id);
  if (!current) return fail('That listing could not be found.');
  if (current.cancelled) return fail('A cancelled listing cannot be edited.');
  if (Date.parse(current.pickupDeadline) <= now) {
    return fail('This listing has passed its pickup deadline and cannot be edited.');
  }

  const changes = stripUndefined(patch);
  const next: ProviderListingRecord = { ...current, ...changes };
  if (changes.name !== undefined) {
    next.name = changes.name.trim();
    const nameError = checkName(next.name);
    if (nameError) return fail(nameError);
  }
  if (changes.area !== undefined) next.area = changes.area.trim();
  if (changes.portionsTotal !== undefined) {
    const portionError = checkPortions(next.portionsTotal);
    if (portionError) return fail(portionError);
    const committed = activeClaimedFor(id, state.claims) + current.collectedPortions;
    if (next.portionsTotal < committed) {
      return fail(`Portions cannot go below the ${committed} already claimed or collected.`);
    }
  }
  if (changes.price !== undefined || changes.originalPrice !== undefined) {
    const priceError = checkPrices(next.price === 0, next.price, next.originalPrice);
    if (priceError) return fail(priceError);
  }
  if (changes.pickupStart !== undefined || changes.pickupDeadline !== undefined) {
    const timeError = checkTimes(next.pickupStart, next.pickupDeadline, now);
    if (timeError) return fail(timeError);
    next.pickupStart = toIso(next.pickupStart);
    next.pickupDeadline = toIso(next.pickupDeadline);
  }
  return done({
    ...state,
    listings: state.listings.map((record) => (record.id === id ? next : record)),
  });
}

export function cancelListing(
  state: ProviderState,
  id: string,
  reason: string,
  now: number,
): Result {
  const current = state.listings.find((record) => record.id === id);
  if (!current) return fail('That listing could not be found.');
  if (current.cancelled) return fail('This listing is already cancelled.');
  if (deriveStatus(current, state.claims, now) === 'collected') {
    return fail('A fully collected listing cannot be cancelled.');
  }
  const text = reason.trim() || 'Cancelled by provider';
  return done({
    ...state,
    listings: state.listings.map((record) =>
      record.id === id ? { ...record, cancelled: true, cancelReason: text } : record,
    ),
    claims: state.claims.map((claim) =>
      claim.listingId === id && isActiveClaim(claim)
        ? { ...claim, status: 'cancelled' as const }
        : claim,
    ),
  });
}

export function markUnavailable(state: ProviderState, id: string, now: number): Result {
  return cancelListing(state, id, 'Marked unavailable by provider', now);
}

/** Records a seeker report on a listing. Takes `base` so sample listings can be reported too, like claimListing. */
export function reportListing(
  state: ProviderState,
  base: Listing[],
  listingId: string,
  reason: string,
  now: number,
): Result<ListingReport> {
  const chosen = REPORT_REASONS.find((item) => item === reason);
  if (!chosen) return fail('Choose a valid reason for the report.');
  const record = state.listings.find((item) => item.id === listingId);
  const external = record ? undefined : base.find((item) => item.id === listingId);
  if (!record && (!external || external.vendorId === PROVIDER_VENDOR_ID)) {
    return fail('That listing could not be found.');
  }
  const vendorId = record ? record.vendorId : external?.vendorId;
  if (vendorId === undefined) return fail('That listing could not be found.');
  const reports = state.reports ?? [];
  const report: ListingReport = {
    id: uniqueId('rpt-', now, new Set(reports.map((item) => item.id))),
    listingId,
    vendorId,
    reason: chosen,
    createdAt: iso(now),
  };
  return withValue({ ...state, reports: [...reports, report] }, report);
}

export function claimListing(
  state: ProviderState,
  base: Listing[],
  listingId: string,
  portions: number,
  collectorName: string,
  now: number,
): Result<PickupClaim> {
  if (!Number.isInteger(portions) || portions < 1 || portions > MAX_PORTIONS_PER_CLAIM) {
    return fail(`You can claim between 1 and ${MAX_PORTIONS_PER_CLAIM} portions.`);
  }
  const name = collectorName.trim();
  if (!name) return fail('Enter a name for this pickup.');

  const record = state.listings.find((item) => item.id === listingId);
  const external = record ? undefined : base.find((item) => item.id === listingId);
  if (!record && (!external || external.vendorId === PROVIDER_VENDOR_ID)) {
    return fail('That listing could not be found.');
  }
  if (record?.cancelled) return fail('This listing has been cancelled.');
  const pickupDeadline = record ? record.pickupDeadline : external?.pickupDeadline;
  if (pickupDeadline === undefined) return fail('That listing could not be found.');
  if (Date.parse(pickupDeadline) <= now) {
    return fail('The pickup window for this listing has closed.');
  }

  const vendorId = record ? record.vendorId : external?.vendorId;
  if (vendorId === undefined) return fail('That listing could not be found.');
  const openReports = (state.reports ?? []).filter((report) => report.vendorId === vendorId).length;
  if (vendorTrustStatus(findVendor(vendorId) ?? {}, openReports) === 'suspended') {
    return fail('This provider is suspended from ResQFood while under review.');
  }

  const alreadyClaimed = state.claims.some(
    (claim) =>
      claim.listingId === listingId && claim.seekerId === DEMO_SEEKER_ID && isActiveClaim(claim),
  );
  if (alreadyClaimed) {
    return fail('You already have an active claim on this listing. Cancel it before claiming again.');
  }

  const remaining = record
    ? remainingFor(record, state.claims)
    : Math.max(0, (external?.portionsRemaining ?? 0) - activeClaimedFor(listingId, state.claims));
  if (remaining <= 0) return fail('This listing is fully claimed.');
  if (portions > remaining) {
    return fail(`Only ${remaining} ${remaining === 1 ? 'portion is' : 'portions are'} left.`);
  }

  const claim: PickupClaim = {
    id: uniqueId('clm-', now, new Set(state.claims.map((item) => item.id))),
    listingId,
    seekerId: DEMO_SEEKER_ID,
    portions,
    code: makeCode(new Set(state.claims.map((item) => item.code))),
    collectorName: name,
    claimedAt: iso(now),
    status: 'reserved',
    collectedAt: '',
  };
  const listingName = record?.name ?? external?.name ?? 'this listing';
  return withValue(
    notify({ ...state, claims: [...state.claims, claim] }, 'reservation', listingName, portions, now),
    claim,
  );
}


/** Cancels the demo seeker's own reserved or ready claim. Portions return because remainingFor counts only active claims. */
export function cancelClaim(
  state: ProviderState,
  claimId: string,
  base: Listing[],
  now: number,
): Result {
  const claim = state.claims.find((item) => item.id === claimId);
  if (!claim) return fail('That reservation could not be found.');
  if (claim.seekerId !== DEMO_SEEKER_ID) return fail('You can only cancel your own reservations.');
  if (claim.status !== 'reserved' && claim.status !== 'ready') {
    return fail('This reservation can no longer be cancelled.');
  }
  const record = state.listings.find((item) => item.id === claim.listingId);
  const pickupDeadline = record?.pickupDeadline ?? base.find((item) => item.id === claim.listingId)?.pickupDeadline;
  if (pickupDeadline === undefined) return fail('That reservation could not be found.');
  if (Date.parse(pickupDeadline) <= now) {
    return fail('The pickup window has closed, so this reservation cannot be cancelled.');
  }
  if (record?.cancelled) return fail('This listing has been cancelled.');
  const listingName =
    record?.name ?? base.find((item) => item.id === claim.listingId)?.name ?? 'this listing';
  return done(
    notify(
      {
        ...state,
        claims: state.claims.map((item) =>
          item.id === claimId ? { ...item, status: 'cancelled' as const } : item,
        ),
      },
      'cancellation',
      listingName,
      claim.portions,
      now,
    ),
  );
}

/** Deletes an expired listing. Provider records are removed with their claims; sample rows are hidden via removedListingIds. */
export function deleteListing(
  state: ProviderState,
  id: string,
  base: Listing[],
  now: number,
): Result {
  const record = state.listings.find((item) => item.id === id);
  if (record) {
    // Expired listings may still hold reserved/ready claims that can no longer be collected, so they are deletable.
    if (deriveStatus(record, state.claims, now) !== 'expired') {
      return fail('Only expired listings can be deleted. Cancel active listings instead.');
    }
    return done({
      ...state,
      listings: state.listings.filter((item) => item.id !== id),
      claims: state.claims.filter((claim) => claim.listingId !== id),
    });
  }
  const listing = base.find((item) => item.id === id);
  if (!listing) return fail('That listing could not be found.');
  if (Date.parse(listing.pickupDeadline) > now) {
    return fail('Only expired listings can be deleted. Cancel active listings instead.');
  }
  const removed = state.removedListingIds ?? [];
  return done({
    ...state,
    removedListingIds: removed.includes(id) ? [...removed] : [...removed, id],
  });
}

/** Hides one finished reservation from the demo seeker's list. The claim stays so provider totals keep it. */
export function removeReservation(
  state: ProviderState,
  claimId: string,
  base: Listing[],
  now: number,
): Result {
  const claim = state.claims.find((item) => item.id === claimId);
  if (!claim) return fail('That reservation could not be found.');
  if (claim.seekerId !== DEMO_SEEKER_ID) return fail('You can only remove your own reservations.');
  const record = state.listings.find((item) => item.id === claim.listingId);
  const pickupDeadline = record?.pickupDeadline ?? base.find((item) => item.id === claim.listingId)?.pickupDeadline;
  const closed = pickupDeadline !== undefined && Date.parse(pickupDeadline) <= now;
  if (isActiveClaim(claim) && !closed) return fail('Cancel the reservation first.');
  return done({
    ...state,
    claims: state.claims.map((item) =>
      item.id === claimId ? { ...item, hiddenFromSeeker: true } : item,
    ),
  });
}

function reservationStatusFor(claim: PickupClaim, pickupDeadline: string, now: number): ReservationView['reservationStatus'] {
  if (claim.status === 'cancelled') return 'cancelled';
  if (claim.status === 'collected') return 'collected';
  if (claim.status === 'expired') return 'expired';
  if (isActiveClaim(claim) && Date.parse(pickupDeadline) <= now) return 'expired';
  return 'reserved';
}

/** Reservation rows for one seeker, newest claim first. Claims whose listing cannot be found are skipped. */
export function reservationsFor(
  state: ProviderState,
  seekerId: string,
  base: Listing[],
  now: number,
): ReservationView[] {
  const views: ReservationView[] = [];
  const removed = new Set(state.removedListingIds ?? []);
  for (const claim of state.claims) {
    if (claim.seekerId !== seekerId || claim.hiddenFromSeeker === true) continue;
    if (removed.has(claim.listingId)) continue;
    const listing =
      state.listings.find((item) => item.id === claim.listingId) ??
      base.find((item) => item.id === claim.listingId);
    if (!listing) continue;
    views.push({
      claim,
      listingName: listing.name,
      vendorName: listing.vendor,
      imageSrc: listing.image,
      pickupDeadline: listing.pickupDeadline,
      reservationStatus: reservationStatusFor(claim, listing.pickupDeadline, now),
    });
  }
  return views.sort((a, b) => Date.parse(b.claim.claimedAt) - Date.parse(a.claim.claimedAt));
}

export function markClaimReady(state: ProviderState, claimId: string, now: number): Result {
  const claim = state.claims.find((item) => item.id === claimId);
  if (!claim) return fail('That pickup could not be found.');
  if (claim.status !== 'reserved') return fail('Only a reserved pickup can be marked ready.');
  if (expiredClaim(state, claim, now)) return fail('This claim has expired.');
  return done({
    ...state,
    claims: state.claims.map((item) =>
      item.id === claimId ? { ...item, status: 'ready' as const } : item,
    ),
  });
}

export function confirmPickup(
  state: ProviderState,
  claimId: string,
  code: string,
  now: number,
  base: Listing[] = [],
): Result {
  const claim = state.claims.find((item) => item.id === claimId);
  if (!claim) return fail('That pickup could not be found.');
  if (claim.status === 'collected') return fail('This pickup is already collected.');
  if (claim.status === 'cancelled') return fail('This claim was cancelled.');
  if (claim.status === 'expired' || expiredClaim(state, claim, now)) {
    return fail('This claim has expired.');
  }
  if (claim.pickupLockedUntil !== undefined && Date.parse(claim.pickupLockedUntil) > now) {
    const minutes = Math.ceil((Date.parse(claim.pickupLockedUntil) - now) / MIN);
    return fail(`Too many incorrect codes. Try again in ${minutes} minutes.`);
  }
  if (code.trim().toUpperCase() !== claim.code.toUpperCase()) {
    // Save the wrong-code count even though the action fails. Lock after the last allowed attempt.
    const failures = (claim.failedPickupAttempts ?? 0) + 1;
    const locking = failures >= MAX_PICKUP_ATTEMPTS;
    return {
      ok: false,
      error: 'That pickup code does not match.',
      state: {
        ...state,
        claims: state.claims.map((item) =>
          item.id === claimId
            ? {
                ...item,
                failedPickupAttempts: locking ? 0 : failures,
                pickupLockedUntil: locking ? iso(now + PICKUP_LOCK_MS) : item.pickupLockedUntil,
              }
            : item,
        ),
      },
    };
  }
  const next: ProviderState = {
    ...state,
    claims: state.claims.map((item) =>
      item.id === claimId
        ? {
            ...item,
            status: 'collected' as const,
            collectedAt: iso(now),
            failedPickupAttempts: 0,
            pickupLockedUntil: undefined,
          }
        : item,
    ),
    listings: state.listings.map((record) =>
      record.id === claim.listingId
        ? { ...record, collectedPortions: record.collectedPortions + claim.portions }
        : record,
    ),
  };
  const listingName =
    state.listings.find((item) => item.id === claim.listingId)?.name ??
    base.find((item) => item.id === claim.listingId)?.name ??
    'this listing';
  return done(notify(next, 'pickup', listingName, claim.portions, now));
}

/**
 * Adds one expiry notice for each reserved or ready claim whose listing pickup deadline has passed.
 * Collected and cancelled claims get none, and a claim that already has its notice is not repeated.
 * Returns the same state object when nothing is new.
 */
export function expiryNotifications(state: ProviderState, now: number, base: Listing[] = []): ProviderState {
  const existing = new Set((state.notifications ?? []).map((item) => item.id));
  const fresh: AppNotification[] = [];
  for (const claim of state.claims) {
    if (claim.status !== 'reserved' && claim.status !== 'ready') continue;
    const id = `expiry-${claim.id}`;
    if (existing.has(id)) continue;
    const listing =
      state.listings.find((item) => item.id === claim.listingId) ??
      base.find((item) => item.id === claim.listingId);
    if (!listing || Date.parse(listing.pickupDeadline) > now) continue;
    fresh.push(claimNotification('expiry', listing.name, claim.portions, iso(now), id));
  }
  if (fresh.length === 0) return state;
  return { ...state, notifications: [...(state.notifications ?? []), ...fresh] };
}

/** Pickup stages in order. Used by the tracker and by advancePickupStage. */
export const PICKUP_STAGES = ['Posted', 'Claimed', 'Collected', 'Delivered'] as const;

/** Name given to claims created by the demo Simulate button. */
const SIMULATED_COLLECTOR = 'Demo seeker';

export interface PickupTrail {
  /** Index into PICKUP_STAGES of the furthest stage reached (0 to 3). */
  reached: number;
  /** One timestamp per stage, or '' where the data has none. Never fabricated. */
  times: string[];
}

function earliestOf(stamps: string[]): string {
  const valid = stamps.filter((stamp) => stamp !== '' && !Number.isNaN(Date.parse(stamp)));
  valid.sort((a, b) => Date.parse(a) - Date.parse(b));
  return valid[0] ?? '';
}

/** Derives the pickup stage from existing fields: addedAt, claim claimedAt/collectedAt, and deliveredAt. */
export function pickupTrailFor(record: ProviderListingRecord | undefined, claims: PickupClaim[]): PickupTrail {
  const live = claims.filter((claim) => claim.status !== 'cancelled');
  const collected = live.filter((claim) => claim.status === 'collected');
  const posted = record?.addedAt ?? '';
  const claimed = earliestOf(live.map((claim) => claim.claimedAt));
  const collectedAt = earliestOf(collected.map((claim) => claim.collectedAt));
  const delivered = record?.deliveredAt ?? '';

  let reached = 0;
  if (delivered !== '') reached = 3;
  else if (collected.length > 0) reached = 2;
  else if (live.length > 0) reached = 1;

  return { reached, times: [posted, claimed, collectedAt, delivered] };
}

/** Marks a collected pickup as delivered. Only reachable through advancePickupStage (the demo Simulate path). */
export function markDelivered(state: ProviderState, listingId: string, now: number): Result {
  const record = state.listings.find((item) => item.id === listingId);
  if (!record) return fail('Only provider-tracked listings can be marked delivered.');
  if (record.cancelled) return fail('This listing has been cancelled.');
  const trail = pickupTrailFor(record, state.claims);
  if (trail.reached >= 3) return fail('This pickup is already delivered.');
  if (trail.reached < 2) return fail('Confirm the collection before marking delivered.');
  return done({
    ...state,
    listings: state.listings.map((item) =>
      item.id === listingId ? { ...item, deliveredAt: iso(now) } : item,
    ),
  });
}

/**
 * Demo only: advances one listing by exactly one stage using existing actions.
 * Posted -> Claimed (claimListing), Claimed -> Collected (confirmPickup with the claim's own code),
 * Collected -> Delivered (markDelivered).
 */
export function advancePickupStage(
  state: ProviderState,
  base: Listing[],
  listingId: string,
  now: number,
): Result {
  const record = state.listings.find((item) => item.id === listingId);
  const trail = pickupTrailFor(record, state.claims);
  if (trail.reached >= 3) return fail('This pickup is already delivered.');
  if (trail.reached === 0) {
    const result = claimListing(state, base, listingId, 1, SIMULATED_COLLECTOR, now);
    return result.ok ? done(result.state) : result;
  }
  if (trail.reached === 1) {
    const open = state.claims.find(
      (claim) => claim.listingId === listingId && (claim.status === 'reserved' || claim.status === 'ready'),
    );
    if (!open) return fail('There is no open reservation to collect.');
    return confirmPickup(state, open.id, open.code, now, base);
  }
  return markDelivered(state, listingId, now);
}

const BENGALURU_LAT = { min: 12.7, max: 13.3 };
const BENGALURU_LNG = { min: 77.3, max: 77.9 };

/** Returns the first validation message for a vendor location, or null when it is acceptable. */
function checkLocation(location: VendorLocation): string | null {
  const address = location.addressLine.length;
  if (address < 5) return 'Enter the restaurant address, at least 5 characters.';
  if (address > 160) return 'The restaurant address must be 160 characters or fewer.';
  const { latitude, longitude } = location;
  if (latitude !== null && (!Number.isFinite(latitude) || latitude < -90 || latitude > 90)) {
    return 'Coordinates are out of range.';
  }
  if (longitude !== null && (!Number.isFinite(longitude) || longitude < -180 || longitude > 180)) {
    return 'Coordinates are out of range.';
  }
  if (latitude !== null && longitude !== null) {
    const inside =
      latitude >= BENGALURU_LAT.min &&
      latitude <= BENGALURU_LAT.max &&
      longitude >= BENGALURU_LNG.min &&
      longitude <= BENGALURU_LNG.max;
    if (!inside) return 'These coordinates are outside Bengaluru. Check the pin or the address.';
  }
  return null;
}

export function updateProfile(state: ProviderState, patch: Partial<ProviderProfile>): Result {
  const merged = { ...state.profile, ...stripUndefined(patch) };
  const profile: ProviderProfile = {
    ...merged,
    businessName: merged.businessName.trim(),
    businessType: merged.businessType.trim(),
    description: merged.description.trim(),
    area: merged.area.trim(),
    hours: merged.hours.trim(),
    contactPlaceholder: merged.contactPlaceholder.trim(),
    preferences: [...merged.preferences],
  };
  const nameLength = profile.businessName.length;
  if (nameLength < 2 || nameLength > 60) return fail('Business name must be between 2 and 60 characters.');
  if (merged.location) {
    const location: VendorLocation = {
      ...merged.location,
      addressLine: merged.location.addressLine.trim(),
      landmark: merged.location.landmark.trim(),
    };
    const locationError = checkLocation(location);
    if (locationError) return fail(locationError);
    profile.location = location;
  }
  return done({ ...state, profile });
}
