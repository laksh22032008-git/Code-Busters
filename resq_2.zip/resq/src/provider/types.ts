import type { Category, Handling } from '../data/types';
import type { AppNotification } from '../lib/notifications';

export type ListingAllocation = 'open' | 'bulk' | 'split';
export type ClaimStatus = 'reserved' | 'ready' | 'collected' | 'expired' | 'cancelled';
export type ListingStatus = 'active' | 'fully-claimed' | 'expired' | 'collected' | 'cancelled';

/** Identifier of the demo seeker whose reservations the Reservations page shows. */
export const DEMO_SEEKER_ID = 'demo-seeker';

export interface ProviderListingRecord {
  id: string;
  name: string;
  vendorId: string;
  vendor: string;
  area: string;
  distanceKm: number;
  portionsTotal: number;
  price: number;
  originalPrice: number;
  isVeg: boolean;
  category: Category;
  tags: string[];
  pickupStart: string;
  pickupDeadline: string;
  addedAt: string;
  image: string;
  x: number;
  y: number;
  handling: Handling;
  allergens: string[];
  allocation: ListingAllocation;
  /** Optional so records saved before the quantity field still load. */
  quantityKg?: number;
  cancelled: boolean;
  cancelReason: string;
  collectedPortions: number;
  /** Set once when the pickup is marked delivered. Optional so older saved records still load. */
  deliveredAt?: string;
  origin: 'sample' | 'vendor';
}

export interface PickupClaim {
  id: string;
  listingId: string;
  seekerId: string;
  portions: number;
  code: string;
  collectorName: string;
  claimedAt: string;
  status: ClaimStatus;
  collectedAt: string;
  /** Set when the seeker removes a finished reservation from their list. Totals still count the claim. */
  hiddenFromSeeker?: boolean;
  /** Consecutive wrong pickup codes since the last success or lock. Optional so older saved claims load. */
  failedPickupAttempts?: number;
  /** ISO time until which code entry is refused for this claim. Optional so older saved claims load. */
  pickupLockedUntil?: string;
}

/** Reasons a seeker can give when reporting a listing. */
export const REPORT_REASONS = [
  'Food looks or smells wrong',
  'Listing details are inaccurate',
  'Pickup did not happen',
  'Other',
] as const;
export type ReportReason = (typeof REPORT_REASONS)[number];

export interface ListingReport {
  id: string;
  listingId: string;
  vendorId: string;
  reason: string;
  createdAt: string;
}

export interface ReservationView {
  claim: PickupClaim;
  listingName: string;
  vendorName: string;
  imageSrc: string;
  pickupDeadline: string;
  reservationStatus: 'reserved' | 'collected' | 'cancelled' | 'expired';
}

export type VendorLocation = {
  addressLine: string;
  landmark: string;
  latitude: number | null;
  longitude: number | null;
  capturedVia: 'manual' | 'device' | '';
};

/** Empty location used by the form before the vendor enters anything. Not stored unless edited. */
export const EMPTY_VENDOR_LOCATION: VendorLocation = {
  addressLine: '',
  landmark: '',
  latitude: null,
  longitude: null,
  capturedVia: '',
};

export interface ProviderProfile {
  businessName: string;
  businessType: string;
  description: string;
  area: string;
  hours: string;
  contactPlaceholder: string;
  preferences: Category[];
  /** Optional so profiles saved before location capture still load. */
  location?: VendorLocation;
}

export interface ProviderState {
  version: 1;
  profile: ProviderProfile;
  listings: ProviderListingRecord[];
  claims: PickupClaim[];
  /** Sample listing ids the provider deleted. Optional so older saved data still loads. */
  removedListingIds?: string[];
  /** Listing reports from seekers. Optional so older saved data still loads. */
  reports?: ListingReport[];
  /** Notifications generated from reservation, cancellation, pickup and expiry events, oldest first. */
  notifications?: AppNotification[];
}

export interface ProviderListingView {
  record: ProviderListingRecord;
  status: ListingStatus;
  portionsClaimed: number;
  portionsRemaining: number;
  portionsCollected: number;
  claims: PickupClaim[];
}

export interface PostListingInput {
  name: string;
  category: Category;
  isVeg: boolean;
  portions: number;
  isFree: boolean;
  price: number;
  originalPrice: number;
  allocation: ListingAllocation;
  pickupStart: string;
  pickupDeadline: string;
  area: string;
  handling: Handling;
  allergens: string[];
  image: string;
  /** Optional so inputs without a quantity still type-check. */
  quantityKg?: number;
}

export type Result<T = ProviderState> =
  | { ok: true; state: ProviderState; value?: T }
  /** `state` is set only when a failed action still needs to save a change (e.g. a wrong-code count). */
  | { ok: false; error: string; state?: ProviderState };
