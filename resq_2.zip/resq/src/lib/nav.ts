import type { Role } from '../data/types';

export type IconName =
  | 'discover'
  | 'map'
  | 'reservations'
  | 'saved'
  | 'profile'
  | 'provider'
  | 'admin'
  | 'bell'
  | 'close';

export interface NavItem {
  to: string;
  label: string;
  icon: IconName;
  end?: boolean;
}

const PROFILE_ITEM: NavItem = { to: '/profile', label: 'Profile', icon: 'profile' };

const SEEKER_NAV: NavItem[] = [
  { to: '/discover', label: 'Discover', icon: 'discover' },
  { to: '/map', label: 'Map', icon: 'map' },
  { to: '/reservations', label: 'Reservations', icon: 'reservations' },
  { to: '/saved', label: 'Saved', icon: 'saved' },
  PROFILE_ITEM,
];

const PROVIDER_NAV: NavItem[] = [
  { to: '/provider', label: 'Overview', icon: 'provider', end: true },
  { to: '/provider/listings', label: 'My Listings', icon: 'saved' },
  { to: '/provider/pickups', label: 'Pickups', icon: 'reservations' },
  { to: '/provider/impact', label: 'Impact', icon: 'map' },
  { to: '/provider/profile', label: 'Business', icon: 'profile' },
];

const ADMIN_NAV: NavItem[] = [
  { to: '/admin', label: 'Admin', icon: 'admin' },
  PROFILE_ITEM,
];

export const ROLE_HOME: Record<Role, string> = {
  seeker: '/discover',
  provider: '/provider',
  admin: '/admin',
};

export const ROLE_LABEL: Record<Role, string> = {
  seeker: 'Food Seeker',
  provider: 'Food Provider',
  admin: 'Platform Admin',
};

export function navItemsFor(role: Role): NavItem[] {
  switch (role) {
    case 'seeker':
      return SEEKER_NAV;
    case 'provider':
      return PROVIDER_NAV;
    case 'admin':
      return ADMIN_NAV;
  }
}
