const MINUTE_MS = 60_000;

export function greetingFor(hour: number): string {
  if (hour < 12) return 'Good morning';
  if (hour < 17) return 'Good afternoon';
  return 'Good evening';
}

export function formatClock(iso: string): string {
  return new Date(iso).toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit' });
}

export function minutesUntil(iso: string, now: number): number {
  return Math.round((Date.parse(iso) - now) / MINUTE_MS);
}

export function formatTimeLeft(iso: string, now: number): string {
  const mins = minutesUntil(iso, now);
  if (mins <= 0) return 'Pickup window closed';
  if (mins < 60) return `${mins} min left`;
  const hours = Math.floor(mins / 60);
  const rest = mins % 60;
  return rest === 0 ? `${hours} h left` : `${hours} h ${rest} min left`;
}

export function formatDistance(km: number): string {
  return `${km.toFixed(1)} km`;
}
