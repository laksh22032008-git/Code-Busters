export type ListingStatus = 'available' | 'fully-reserved' | 'expired' | 'cancelled';

export interface ListingStatusInput {
  cancelled: boolean;
  deadlineMs: number;
  remaining: number;
  now: number;
}

/** One status for a listing. Precedence: cancelled, then expired, then fully-reserved, else available. */
export function listingStatus(input: ListingStatusInput): ListingStatus {
  if (input.cancelled) return 'cancelled';
  if (input.now >= input.deadlineMs) return 'expired';
  if (input.remaining <= 0) return 'fully-reserved';
  return 'available';
}
