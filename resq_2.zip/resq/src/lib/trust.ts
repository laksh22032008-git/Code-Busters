import type { TrustStatus } from '../data/types';

/** Open reports at which a vendor is moved to 'under-review' automatically. */
export const REVIEW_REPORT_THRESHOLD = 3;

/**
 * Trust status for a vendor. Only the provider's explicit status and the count of open
 * listing reports affect the result. Ratings or review scores must never affect this result.
 */
export function vendorTrustStatus(
  vendor: { trustStatus?: TrustStatus },
  openReportCount: number,
): TrustStatus {
  if (vendor.trustStatus === 'suspended') return 'suspended';
  if (openReportCount >= REVIEW_REPORT_THRESHOLD) return 'under-review';
  return 'trusted';
}
