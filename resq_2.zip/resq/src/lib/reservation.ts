import type { PickupClaim } from '../provider/types';

/** Most portions one claim may hold. Shared by the store and the listing modal. */
export const MAX_PORTIONS_PER_CLAIM = 20;

/** A claim holds portions only while it is reserved or ready for pickup. */
export function isActiveClaim(claim: PickupClaim): boolean {
  return claim.status === 'reserved' || claim.status === 'ready';
}
