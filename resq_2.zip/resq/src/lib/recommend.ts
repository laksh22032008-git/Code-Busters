import type { Listing } from '../data/types';
import { listingStatus } from './listingStatus';

/**
 * Rule-based, deterministic ranking for the "Recommended" sort.
 * This is a fixed weighted formula, not machine learning. Weights total 100.
 */
export interface Recommendation {
  score: number;
  reasons: string[];
}

const WEIGHT_PROXIMITY = 35;
const WEIGHT_URGENCY = 25;
const WEIGHT_QUANTITY = 20;
const WEIGHT_PRICE = 10;
const WEIGHT_FEASIBILITY = 10;

const PROXIMITY_RANGE_KM = 8;
const QUANTITY_CAP = 10;
const FEASIBLE_MIN_MINUTES = 20;

function urgencyScore(minutesLeft: number): number {
  if (minutesLeft < 30) return 10;
  if (minutesLeft <= 90) return WEIGHT_URGENCY;
  if (minutesLeft <= 180) return 15;
  return 5;
}

/** Scores one listing. Listings that are not 'available' score 0 so they sort last. */
export function recommendListing(listing: Listing, nowMs: number): Recommendation {
  const deadlineMs = Date.parse(listing.pickupDeadline);
  const status = listingStatus({
    cancelled: false,
    deadlineMs,
    remaining: listing.portionsRemaining,
    now: nowMs,
  });
  if (status !== 'available') {
    return { score: 0, reasons: ['Not available'] };
  }

  const minutesLeft = (deadlineMs - nowMs) / 60_000;
  const reasons: string[] = [];

  const proximity = Math.round(
    Math.max(0, 1 - listing.distanceKm / PROXIMITY_RANGE_KM) * WEIGHT_PROXIMITY,
  );
  reasons.push(`${listing.distanceKm.toFixed(1)} km away`);

  const urgency = urgencyScore(minutesLeft);
  reasons.push(`Pickup closes in ${Math.floor(minutesLeft)} min`);

  const quantity = Math.round(
    (Math.min(listing.portionsRemaining, QUANTITY_CAP) / QUANTITY_CAP) * WEIGHT_QUANTITY,
  );
  reasons.push(
    listing.portionsRemaining === 1
      ? '1 portion left'
      : `${listing.portionsRemaining} portions left`,
  );

  let price = 0;
  if (listing.price === 0) {
    price = WEIGHT_PRICE;
    reasons.push('Free');
  } else if (listing.originalPrice > 0) {
    const ratio = Math.max(0, 1 - listing.price / listing.originalPrice);
    price = Math.round(ratio * WEIGHT_PRICE);
    const percentBelow = Math.round(ratio * 100);
    if (percentBelow > 0) {
      reasons.push(`Price ${percentBelow}% below original`);
    }
  }

  const feasible = minutesLeft >= FEASIBLE_MIN_MINUTES && listing.portionsRemaining > 0;
  const feasibility = feasible ? WEIGHT_FEASIBILITY : 0;
  if (feasible) {
    reasons.push('Pickup window still open');
  }

  return {
    score: proximity + urgency + quantity + price + feasibility,
    reasons,
  };
}
