import type { Listing } from '../data/types';
import { receivers } from '../data/receivers';
import type { Receiver } from '../data/receivers';
import { KG_PER_MEAL } from './impactConstants';

export interface MatchBreakdown {
  score: number;
  distanceScore: number;
  capacityScore: number;
  timingScore: number;
  distanceKm: number;
  fitsKg: number;
  closesLabel: string;
  summary: string;
}

/** Score constants: distance 40 + capacity fit 35 + timing 25 = 100. */
const MAX_DISTANCE_KM = 10;
const DISTANCE_WEIGHT = 40;
const CAPACITY_WEIGHT = 35;
const TIMING_WEIGHT = 25;
const DAY_MINUTES = 1440;
/** Closing times before this hour are treated as after midnight (+24h). */
const EARLY_HOUR_CUTOFF = 6;

function parseClock(clock: string): { hours: number; minutes: number } {
  const [hours, minutes] = clock.split(':').map(Number);
  return { hours, minutes };
}

function formatClosesLabel(clock: string): string {
  const { hours, minutes } = parseClock(clock);
  const suffix = hours >= 12 ? 'PM' : 'AM';
  return `${hours % 12 || 12}:${String(minutes).padStart(2, '0')} ${suffix}`;
}

export function computeMatch(listing: Listing, receiver: Receiver): MatchBreakdown {
  const donatedKg = Math.round(listing.portionsRemaining * KG_PER_MEAL * 10) / 10;

  const distanceScore = Math.round(
    Math.max(0, 1 - receiver.distanceKm / MAX_DISTANCE_KM) * DISTANCE_WEIGHT,
  );

  let capacityScore = 0;
  if (donatedKg > 0) {
    const ratio =
      Math.min(donatedKg, receiver.neededKg) / Math.max(donatedKg, receiver.neededKg);
    capacityScore = Math.round(ratio * CAPACITY_WEIGHT);
  }

  // Minutes since the pickup start's local midnight.
  const start = new Date(listing.pickupStart);
  const midnight = new Date(start);
  midnight.setHours(0, 0, 0, 0);
  const sinceMidnight = (iso: string) =>
    Math.round((new Date(iso).getTime() - midnight.getTime()) / 60000);
  const startMin = sinceMidnight(listing.pickupStart);
  const deadlineMin = sinceMidnight(listing.pickupDeadline);

  const { hours, minutes } = parseClock(receiver.closesAt);
  const closesMin = hours * 60 + minutes + (hours < EARLY_HOUR_CUTOFF ? DAY_MINUTES : 0);

  let timingScore = 0;
  if (closesMin >= deadlineMin) timingScore = TIMING_WEIGHT;
  else if (closesMin >= startMin) timingScore = Math.round(TIMING_WEIGHT / 2);

  const closesLabel = formatClosesLabel(receiver.closesAt);

  return {
    score: distanceScore + capacityScore + timingScore,
    distanceScore,
    capacityScore,
    timingScore,
    distanceKm: receiver.distanceKm,
    fitsKg: donatedKg,
    closesLabel,
    summary: `${receiver.distanceKm.toFixed(1)} km away • Fits ${donatedKg} kg capacity • Open until ${closesLabel}`,
  };
}

export function rankReceivers(
  listing: Listing,
  list: Receiver[] = receivers,
): Array<Receiver & { match: MatchBreakdown }> {
  return list
    .map((receiver) => ({ ...receiver, match: computeMatch(listing, receiver) }))
    .sort((a, b) => b.match.score - a.match.score);
}
