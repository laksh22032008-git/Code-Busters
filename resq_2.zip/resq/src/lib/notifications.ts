/** One notification built from a real app event. Messages are generated, never hardcoded. */
export interface AppNotification {
  id: string;
  message: string;
  /** ISO time the event happened. */
  at: string;
  kind: 'reservation' | 'cancellation' | 'pickup' | 'expiry';
}

function messageFor(kind: AppNotification['kind'], listingName: string, portions: number): string {
  switch (kind) {
    case 'reservation':
      return `Reservation confirmed: ${portions} portion(s) of ${listingName}. Show code at pickup.`;
    case 'cancellation':
      return `Reservation cancelled: ${portions} portion(s) of ${listingName} returned to the listing.`;
    case 'pickup':
      return `Pickup confirmed: ${portions} portion(s) of ${listingName} collected.`;
    case 'expiry':
      return `Pickup window closed for ${listingName}. Unclaimed portions were not collected.`;
  }
}

export function claimNotification(
  kind: AppNotification['kind'],
  listingName: string,
  portions: number,
  at: string,
  id: string,
): AppNotification {
  return { id, message: messageFor(kind, listingName, portions), at, kind };
}

/** Short relative time such as "just now" or "5 min ago". Future or unreadable times show as "just now". */
export function relativeTime(at: string, now: number): string {
  const then = Date.parse(at);
  if (Number.isNaN(then)) return 'just now';
  const minutes = Math.floor(Math.max(0, now - then) / 60_000);
  if (minutes < 1) return 'just now';
  if (minutes < 60) return `${minutes} min ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} h ago`;
  return `${Math.floor(hours / 24)} d ago`;
}
