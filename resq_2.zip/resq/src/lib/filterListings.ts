import type { FilterCategory, Listing, SortKey } from '../data/types';
import { isOpenForClaim } from './availability';
import { recommendListing } from './recommend';

export interface FilterState {
  category: FilterCategory;
  query: string;
  availableOnly: boolean;
  sort: SortKey;
}

export function matchesCategory(listing: Listing, category: FilterCategory): boolean {
  switch (category) {
    case 'free':
      return listing.price === 0;
    case 'veg':
      return listing.isVeg;
    case 'nonveg':
      return !listing.isVeg;
    case 'bakery':
      return listing.category === 'Bakery';
    case 'meals':
      return listing.category === 'Meals';
    case 'all':
    case 'available':
      return true;
  }
}

export function matchesQuery(listing: Listing, rawQuery: string): boolean {
  const query = rawQuery.trim().toLowerCase();
  if (query === '') return true;
  return (
    listing.name.toLowerCase().includes(query) ||
    listing.vendor.toLowerCase().includes(query)
  );
}

function sortListings(listings: Listing[], sort: SortKey, nowMs: number = Date.now()): Listing[] {
  if (sort === 'urgency') {
    return listings.sort((a, b) => Date.parse(a.pickupDeadline) - Date.parse(b.pickupDeadline));
  }
  if (sort === 'recommended') {
    return listings.sort((a, b) => {
      const scoreDiff =
        recommendListing(b, nowMs).score - recommendListing(a, nowMs).score;
      return scoreDiff !== 0 ? scoreDiff : a.distanceKm - b.distanceKm;
    });
  }
  return listings.sort((a, b) => a.distanceKm - b.distanceKm);
}

/** Pure filter: category, search text and availability combine; then sort. */
export function filterListings(listings: Listing[], filters: FilterState, now: number): Listing[] {
  const onlyAvailable = filters.availableOnly || filters.category === 'available';
  const matched = listings.filter(
    (listing) =>
      matchesCategory(listing, filters.category) &&
      matchesQuery(listing, filters.query) &&
      (!onlyAvailable || isOpenForClaim(listing, now)),
  );
  return sortListings(matched, filters.sort, now);
}
