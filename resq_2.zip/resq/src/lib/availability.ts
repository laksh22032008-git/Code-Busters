import type { Listing } from '../data/types';

export type Availability = 'available' | 'few' | 'sold';

const FEW_LEFT_THRESHOLD = 3;
const URGENT_WINDOW_MIN = 60;

export const AVAILABILITY_LABEL: Record<Availability, string> = {
  available: 'Available',
  few: 'Few left',
  sold: 'Sold out',
};

/** A listing can be claimed when portions remain and the pickup deadline is still ahead. */
export function isOpenForClaim(listing: Listing, now: number): boolean {
  return listing.portionsRemaining > 0 && Date.parse(listing.pickupDeadline) > now;
}

export function getAvailability(listing: Listing, now: number): Availability {
  if (!isOpenForClaim(listing, now)) return 'sold';
  if (listing.portionsRemaining <= FEW_LEFT_THRESHOLD) return 'few';
  return 'available';
}

/** Urgent: open for claim and either the deadline is near or few portions are left. */
export function isUrgent(listing: Listing, now: number): boolean {
  if (!isOpenForClaim(listing, now)) return false;
  const minsLeft = (Date.parse(listing.pickupDeadline) - now) / 60_000;
  return minsLeft <= URGENT_WINDOW_MIN || listing.portionsRemaining <= FEW_LEFT_THRESHOLD;
}
