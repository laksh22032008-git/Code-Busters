/** Planning constants for impact estimates. Shared by the store, the match score and the impact page. */

/** Edible food per meal, in kg (400 g). */
export const KG_PER_MEAL = 0.4;

/** kg CO₂e avoided per kg of food waste diverted. */
export const CO2E_KG_PER_KG_DIVERTED = 2.5;

/** Assumptions shown beside every impact figure. Only confirmed collections count toward rescued food. */
export const IMPACT_ASSUMPTIONS: readonly string[] = [
  '1 meal = 400 g edible food (planning assumption)',
  '1 kg food waste diverted = 2.5 kg CO₂e avoided, based on landfill methane equivalents (planning assumption, not verified emissions data)',
  'Only portions with a confirmed pickup (collected) count toward rescued-food impact. Listed and claimed portions are shown separately.',
];
