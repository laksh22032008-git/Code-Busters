import { useNavigate } from 'react-router-dom';
import type { Role } from '../data/types';
import { useAppState } from '../context/AppStateContext';
import { ROLE_HOME, ROLE_LABEL } from '../lib/nav';

const ROLES: Role[] = ['seeker', 'provider', 'admin'];

export function RoleSwitcher() {
  const { role, setRole, showToast } = useAppState();
  const navigate = useNavigate();

  function choose(next: Role) {
    setRole(next);
    navigate(ROLE_HOME[next]);
    showToast(`Switched to ${ROLE_LABEL[next]} (demo)`);
  }

  return (
    <div className="role-switcher" role="group" aria-label="Switch role (demo)">
      {ROLES.map((option) => (
        <button
          key={option}
          type="button"
          className="role-option"
          aria-pressed={option === role}
          onClick={() => choose(option)}
        >
          {ROLE_LABEL[option]}
        </button>
      ))}
    </div>
  );
}
