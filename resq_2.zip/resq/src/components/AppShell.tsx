import { Outlet } from 'react-router-dom';
import { useAppState } from '../context/AppStateContext';
import { BottomNav } from './BottomNav';
import { ListingModal } from './ListingModal';
import { MobileHeader } from './MobileHeader';
import { Sidebar } from './Sidebar';
import { ToastHost } from './ToastHost';

export function AppShell() {
  const { selectedListingId } = useAppState();
  return (
    <div className="app-shell">
      <a className="skip-link" href="#main-content">
        Skip to content
      </a>
      <Sidebar />
      <div className="app-main">
        <MobileHeader />
        <main id="main-content" className="app-content" tabIndex={-1}>
          <Outlet />
        </main>
        <footer className="app-footer">
          <p className="app-footer-disclaimer">
            ResQFood connects surplus food donors with nearby receivers and does not inspect or certify food safety. Donors and receivers must follow displayed handling and time-window guidelines.
          </p>
        </footer>
      </div>
      <BottomNav />
      <ToastHost />
      {selectedListingId ? <ListingModal listingId={selectedListingId} /> : null}
    </div>
  );
}
