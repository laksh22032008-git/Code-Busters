import type { CSSProperties } from 'react';
import type { Listing } from '../data/types';
import { useAppState } from '../context/AppStateContext';
import { FoodCard } from './FoodCard';

interface FoodGridProps {
  listings: Listing[];
}

export function FoodGrid({ listings }: FoodGridProps) {
  const { setCategory, setQuery, setAvailableOnly } = useAppState();

  if (listings.length === 0) {
    return (
      <div className="empty-state">
        <p>No listings match the current search or filters.</p>
        <button
          type="button"
          className="primary-button"
          onClick={() => {
            setCategory('all');
            setQuery('');
            setAvailableOnly(false);
          }}
        >
          Nothing matches — try clearing filters
        </button>
      </div>
    );
  }

  return (
    <ul className="food-grid">
      {listings.map((listing, index) => (
        <li key={listing.id} style={{ '--i': index } as CSSProperties}>
          <FoodCard listing={listing} />
        </li>
      ))}
    </ul>
  );
}
