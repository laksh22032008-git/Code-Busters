import type { FilterCategory } from '../data/types';
import { useAppState } from '../context/AppStateContext';
import { FilterChip } from './FilterChip';

const CATEGORY_CHIPS: { value: FilterCategory; label: string }[] = [
  { value: 'all', label: 'All food' },
  { value: 'free', label: 'Free' },
  { value: 'veg', label: 'Vegetarian' },
  { value: 'nonveg', label: 'Non-vegetarian' },
  { value: 'bakery', label: 'Bakery' },
  { value: 'meals', label: 'Meals' },
];

export function FilterBar() {
  const { category, setCategory, availableOnly, setAvailableOnly, sort, setSort } = useAppState();
  return (
    <div className="filter-bar">
      <div className="chip-row" role="group" aria-label="Food type">
        {CATEGORY_CHIPS.map((chip) => (
          <FilterChip
            key={chip.value}
            label={chip.label}
            active={category === chip.value}
            onClick={() => setCategory(chip.value)}
          />
        ))}
        <FilterChip
          label="Available now"
          active={availableOnly}
          onClick={() => setAvailableOnly(!availableOnly)}
        />
      </div>
      <label className="sort-control">
        <span>Sort by</span>
        <select
          value={sort}
          onChange={(event) =>
            setSort(
              event.target.value === 'urgency' || event.target.value === 'recommended'
                ? event.target.value
                : 'distance',
            )
          }
        >
          <option value="recommended">Recommended</option>
          <option value="distance">Nearest</option>
          <option value="urgency">Most urgent</option>
        </select>
      </label>
    </div>
  );
}
