import { useEffect, useRef, useState } from 'react';
import { useAppState } from '../context/AppStateContext';
import { relativeTime } from '../lib/notifications';
import { Icon } from './Icon';

export function NotificationPanel() {
  const { notifications, now, notificationsOpen, setNotificationsOpen, showToast } = useAppState();
  const [readIds, setReadIds] = useState<Set<string>>(() => new Set());
  const bellRef = useRef<HTMLButtonElement>(null);
  const unread = notifications.filter((item) => !readIds.has(item.id)).length;

  useEffect(() => {
    if (!notificationsOpen) return;
    function onKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        setNotificationsOpen(false);
        bellRef.current?.focus();
      }
    }
    document.addEventListener('keydown', onKeyDown);
    return () => document.removeEventListener('keydown', onKeyDown);
  }, [notificationsOpen, setNotificationsOpen]);

  function markAllRead() {
    setReadIds(new Set(notifications.map((item) => item.id)));
    showToast('All notifications marked as read (demo)');
  }

  return (
    <div className="notify">
      <button
        ref={bellRef}
        type="button"
        className="icon-button"
        aria-label={unread > 0 ? `Notifications, ${unread} unread` : 'Notifications'}
        aria-expanded={notificationsOpen}
        aria-controls="notification-panel"
        onClick={() => setNotificationsOpen(!notificationsOpen)}
      >
        <Icon name="bell" />
        {unread > 0 ? <span className="badge">{unread}</span> : null}
      </button>
      {notificationsOpen ? (
        <div id="notification-panel" className="notify-panel" role="region" aria-label="Notifications">
          <div className="notify-head">
            <h2>Notifications</h2>
            <button type="button" className="text-button" onClick={markAllRead}>
              Mark all as read
            </button>
          </div>
          {notifications.length === 0 ? (
            <p>No notifications yet. Reservation, cancellation, pickup and expiry updates appear here.</p>
          ) : (
            <ul className="notify-list">
              {notifications.map((item) => (
                <li key={item.id} className={readIds.has(item.id) ? 'is-read' : 'is-unread'}>
                  <p>{item.message}</p>
                  <small>{relativeTime(item.at, now)}</small>
                </li>
              ))}
            </ul>
          )}
          <button type="button" className="text-button" onClick={() => setNotificationsOpen(false)}>
            Close
          </button>
        </div>
      ) : null}
    </div>
  );
}
