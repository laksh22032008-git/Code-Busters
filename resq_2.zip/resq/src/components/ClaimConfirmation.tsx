import { Link } from 'react-router-dom';
import type { Listing } from '../data/types';
import { useAppState } from '../context/AppStateContext';
import { formatClock } from '../lib/time';

interface ClaimConfirmationProps {
  listing: Listing;
  code: string;
  portions: number;
}

export function ClaimConfirmation({ listing, code, portions }: ClaimConfirmationProps) {
  const { closeListing } = useAppState();
  const portionLabel = portions === 1 ? '1 portion' : `${portions} portions`;

  return (
    <section className="claim-confirm" aria-live="polite" aria-labelledby="claim-title">
      <h3 id="claim-title">Reservation confirmed</h3>
      <p>
        {portionLabel} of {listing.name} reserved.
      </p>
      <p className="claim-code">{code}</p>
      <p>
        Show this code at {listing.vendor} ({listing.area}) between {formatClock(listing.pickupStart)} and{' '}
        {formatClock(listing.pickupDeadline)}.
      </p>
      <p className="demo-note">Reservation saved on this device for the demo.</p>
      <Link to="/reservations" className="primary-button" onClick={closeListing}>
        View my reservations
      </Link>
    </section>
  );
}
