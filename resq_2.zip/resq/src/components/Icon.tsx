import type { IconName } from '../lib/nav';

const PATHS: Record<IconName, string[]> = {
  discover: ['M11 4a7 7 0 1 0 0 14a7 7 0 1 0 0-14', 'M20 20l-4.2-4.2'],
  map: ['M12 21s-6-5.2-6-10a6 6 0 1 1 12 0c0 4.8-6 10-6 10z', 'M12 13a2 2 0 1 0 0-4a2 2 0 1 0 0 4'],
  reservations: ['M4 6h16v14H4z', 'M4 10h16', 'M8 4v4', 'M16 4v4'],
  saved: ['M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z'],
  profile: ['M12 12a4 4 0 1 0 0-8a4 4 0 1 0 0 8', 'M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6'],
  provider: ['M3 9l2-5h14l2 5', 'M4 9v12h16V9', 'M9 21v-6h6v6'],
  admin: ['M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z'],
  bell: ['M6 8a6 6 0 1 1 12 0c0 6 2 7 2 7H4s2-1 2-7', 'M10 19a2 2 0 0 0 4 0'],
  close: ['M6 6l12 12', 'M18 6L6 18'],
};

interface IconProps {
  name: IconName;
}

export function Icon({ name }: IconProps) {
  return (
    <svg
      className="icon"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
    >
      {PATHS[name].map((d) => (
        <path key={d} d={d} />
      ))}
    </svg>
  );
}
