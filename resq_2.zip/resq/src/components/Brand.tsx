import { Link } from 'react-router-dom';

export function Brand() {
  return (
    <Link to="/discover" className="brand" aria-label="ResQFood home">
      <svg className="brand-mark" viewBox="0 0 32 32" aria-hidden="true" focusable="false">
        <path d="M6 26C6 14 14 6 27 5c0 13-8 21-20 21z" fill="currentColor" />
        <path d="M6 26L17 15" stroke="#FBF7F0" strokeWidth={2} strokeLinecap="round" fill="none" />
      </svg>
      <span className="brand-word">ResQFood</span>
    </Link>
  );
}
