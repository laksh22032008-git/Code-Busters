import { useState, type FormEvent } from 'react';
import { useAppState } from '../../context/AppStateContext';
import type { ProviderListingRecord } from '../../provider/types';

interface ListingEditFormProps {
  record: ProviderListingRecord;
  onDone: () => void;
}

function clockValue(iso: string): string {
  const date = new Date(iso);
  const hh = String(date.getHours()).padStart(2, '0');
  const mm = String(date.getMinutes()).padStart(2, '0');
  return `${hh}:${mm}`;
}

// Keeps the record's date and replaces its local time with the chosen HH:mm.
function combineDeadline(iso: string, time: string): string | null {
  const match = /^(\d{1,2}):(\d{2})$/.exec(time);
  if (!match) return null;
  const hours = Number(match[1]);
  const minutes = Number(match[2]);
  if (hours > 23 || minutes > 59) return null;
  const date = new Date(iso);
  date.setHours(hours, minutes, 0, 0);
  return date.toISOString();
}

export function ListingEditForm({ record, onDone }: ListingEditFormProps) {
  const { updateListing } = useAppState();
  const [portions, setPortions] = useState(String(record.portionsTotal));
  const [price, setPrice] = useState(String(record.price));
  const [deadline, setDeadline] = useState(clockValue(record.pickupDeadline));
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (event: FormEvent<HTMLFormElement>): void => {
    event.preventDefault();
    const portionCount = Number(portions);
    const priceValue = Number(price);
    if (portions.trim() === '' || price.trim() === '' || !Number.isFinite(portionCount) || !Number.isFinite(priceValue)) {
      setError('Enter portions and price as numbers.');
      return;
    }
    const deadlineIso = combineDeadline(record.pickupDeadline, deadline);
    if (deadlineIso === null) {
      setError('Enter a pickup time, for example 18:30.');
      return;
    }
    const result = updateListing(record.id, {
      portionsTotal: portionCount,
      price: priceValue,
      pickupDeadline: deadlineIso,
    });
    if (result.ok) {
      onDone();
      return;
    }
    setError(result.error);
  };

  return (
    <form className="ops-form" onSubmit={handleSubmit}>
      <label className="ops-field">
        <span>Portions posted</span>
        <input
          className="ops-input"
          type="number"
          min={1}
          step={1}
          inputMode="numeric"
          value={portions}
          onChange={(event) => setPortions(event.target.value)}
        />
      </label>
      <label className="ops-field">
        <span>Price in rupees (0 for free)</span>
        <input
          className="ops-input"
          type="number"
          min={0}
          step={1}
          inputMode="numeric"
          value={price}
          onChange={(event) => setPrice(event.target.value)}
        />
      </label>
      <label className="ops-field">
        <span>Pick up by</span>
        <input
          className="ops-input"
          type="time"
          value={deadline}
          onChange={(event) => setDeadline(event.target.value)}
        />
      </label>
      {error && (
        <p className="ops-error" role="alert">
          {error}
        </p>
      )}
      <div className="ops-actions">
        <button type="submit" className="ops-button-solid">
          Save changes
        </button>
        <button type="button" className="ops-button" onClick={onDone}>
          Discard
        </button>
      </div>
    </form>
  );
}
