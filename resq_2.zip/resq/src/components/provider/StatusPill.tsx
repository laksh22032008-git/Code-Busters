export type PillTone = 'primary' | 'urgency' | 'neutral';

interface StatusPillProps {
  label: string;
  tone: PillTone;
}

export function StatusPill({ label, tone }: StatusPillProps) {
  return <span className={`ops-pill ops-pill-${tone}`}>{label}</span>;
}
