import { useEffect, useId, useLayoutEffect, type MouseEvent } from 'react';
import { QuickPostForm } from './QuickPostForm';

interface QuickPostModalProps {
  onClose: () => void;
}

export function QuickPostModal({ onClose }: QuickPostModalProps) {
  const titleId = useId();

  // Runs before the form focuses its first field, so the trigger is captured correctly.
  useLayoutEffect(() => {
    const trigger = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    return () => {
      trigger?.focus();
    };
  }, []);

  useEffect(() => {
    const handleKey = (event: KeyboardEvent): void => {
      if (event.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', handleKey);
    return () => document.removeEventListener('keydown', handleKey);
  }, [onClose]);

  const handleBackdrop = (event: MouseEvent<HTMLDivElement>): void => {
    if (event.target === event.currentTarget) onClose();
  };

  return (
    <div className="modal-backdrop quick-post-backdrop" onMouseDown={handleBackdrop}>
      <div className="modal quick-post-modal" role="dialog" aria-modal="true" aria-labelledby={titleId}>
        <header className="quick-post-header">
          <div>
            <h2 className="quick-post-title" id={titleId}>
              Post surplus food
            </h2>
            <p className="quick-post-intro">Share a meal before it goes to waste. Fields marked optional can be left blank.</p>
          </div>
          <button type="button" className="secondary-button quick-post-close" onClick={onClose}>
            Close
          </button>
        </header>
        <QuickPostForm onDone={onClose} />
      </div>
    </div>
  );
}
