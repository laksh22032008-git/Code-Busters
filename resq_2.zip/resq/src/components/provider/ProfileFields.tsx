import type { Category } from '../../data/types';
import { AREAS } from '../../context/AppStateContext';
import {
  EMPTY_VENDOR_LOCATION,
  type ProviderProfile,
  type VendorLocation,
} from '../../provider/types';
import { LocationFields } from './LocationFields';

const BUSINESS_TYPES = ['Restaurant', 'Cafe', 'Bakery', 'Caterer', 'Home kitchen', 'Other'];
const CATEGORY_OPTIONS: Category[] = ['Meals', 'Bakery', 'Snacks'];
const DESCRIPTION_MAX = 240;

interface ProfileFieldsProps {
  draft: ProviderProfile;
  savedContactPlaceholder: string;
  nameError: string | null;
  onChange: (patch: Partial<ProviderProfile>) => void;
  onLocationChange: (patch: Partial<VendorLocation>) => void;
  onNameBlur: () => void;
}

export function ProfileFields({
  draft,
  savedContactPlaceholder,
  nameError,
  onChange,
  onLocationChange,
  onNameBlur,
}: ProfileFieldsProps) {
  function togglePreference(category: Category) {
    const selected = draft.preferences.includes(category);
    onChange({
      preferences: selected
        ? draft.preferences.filter((item) => item !== category)
        : [...draft.preferences, category],
    });
  }

  return (
    <div className="profile-fields">
      <div className="profile-field">
        <label className="profile-label" htmlFor="profile-name">
          Business name <span className="profile-required">(required)</span>
        </label>
        <input
          id="profile-name"
          className="profile-input"
          type="text"
          value={draft.businessName}
          onChange={(event) => onChange({ businessName: event.target.value })}
          onBlur={onNameBlur}
          required
          aria-invalid={nameError ? true : undefined}
          aria-describedby={nameError ? 'profile-name-error' : undefined}
        />
        {nameError && (
          <p id="profile-name-error" className="profile-helper profile-helper--error">
            {nameError}
          </p>
        )}
      </div>

      <div className="profile-field">
        <label className="profile-label" htmlFor="profile-type">
          Business type
        </label>
        <select
          id="profile-type"
          className="profile-input"
          value={draft.businessType}
          onChange={(event) => onChange({ businessType: event.target.value })}
        >
          {BUSINESS_TYPES.map((type) => (
            <option key={type} value={type}>
              {type}
            </option>
          ))}
        </select>
      </div>

      <div className="profile-field">
        <label className="profile-label" htmlFor="profile-description">
          Description <span className="profile-required">(optional)</span>
        </label>
        <textarea
          id="profile-description"
          className="profile-input profile-textarea"
          rows={3}
          maxLength={DESCRIPTION_MAX}
          value={draft.description}
          onChange={(event) => onChange({ description: event.target.value })}
        />
        <p className="profile-helper">
          {draft.description.length}/{DESCRIPTION_MAX} characters
        </p>
      </div>

      <div className="profile-field">
        <label className="profile-label" htmlFor="profile-area">
          Approximate area
        </label>
        <select
          id="profile-area"
          className="profile-input"
          value={draft.area}
          onChange={(event) => onChange({ area: event.target.value })}
        >
          {AREAS.map((area) => (
            <option key={area} value={area}>
              {area}
            </option>
          ))}
        </select>
      </div>

      <div className="profile-field">
        <label className="profile-label" htmlFor="profile-hours">
          Operating hours
        </label>
        <input
          id="profile-hours"
          className="profile-input"
          type="text"
          value={draft.hours}
          placeholder="11:00 to 22:00 daily"
          onChange={(event) => onChange({ hours: event.target.value })}
        />
      </div>

      <div className="profile-field">
        <label className="profile-label" htmlFor="profile-contact">
          Contact
        </label>
        <input
          id="profile-contact"
          className="profile-input"
          type="text"
          value={draft.contactPlaceholder}
          placeholder={savedContactPlaceholder}
          aria-describedby="profile-contact-help"
          onChange={(event) => onChange({ contactPlaceholder: event.target.value })}
        />
        <p id="profile-contact-help" className="profile-helper">
          Contact details are added after sign-up. This demo does not store personal contact
          information.
        </p>
      </div>

      <fieldset className="profile-field profile-fieldset">
        <legend className="profile-label">Food preferences</legend>
        <div className="profile-chips">
          {CATEGORY_OPTIONS.map((category) => (
            <button
              key={category}
              type="button"
              className="profile-chip"
              aria-pressed={draft.preferences.includes(category)}
              onClick={() => togglePreference(category)}
            >
              {category}
            </button>
          ))}
        </div>
      </fieldset>

      <LocationFields
        location={draft.location ?? EMPTY_VENDOR_LOCATION}
        onChange={onLocationChange}
      />
    </div>
  );
}
