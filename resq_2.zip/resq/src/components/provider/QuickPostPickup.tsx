import { AREAS } from '../../context/AppStateContext';
import { FIELD_IDS, type QuickPostErrors, type QuickPostForm } from '../../provider/quickPost';
import { Field } from './QuickPostFields';
import type { UpdateFormField } from './QuickPostHandling';

interface QuickPostPickupProps {
  form: QuickPostForm;
  errors: QuickPostErrors;
  update: UpdateFormField;
  now: number;
}

export function QuickPostPickup({ form, errors, update, now }: QuickPostPickupProps) {
  const todayLabel = new Date(now).toLocaleDateString('en-IN', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
  });
  return (
    <fieldset className="quick-post-section">
      <legend>Pickup</legend>
      <p className="quick-post-date">Today, {todayLabel}</p>
      <div className="quick-post-row">
        <Field id={FIELD_IDS.start} label="Pickup starts" error={errors.start}>
          <input
            id={FIELD_IDS.start}
            className="quick-post-input"
            type="time"
            value={form.start}
            aria-invalid={errors.start !== undefined}
            onChange={(event) => update('start', event.target.value)}
          />
        </Field>
        <Field id={FIELD_IDS.deadline} label="Pickup by" error={errors.deadline}>
          <input
            id={FIELD_IDS.deadline}
            className="quick-post-input"
            type="time"
            value={form.deadline}
            aria-invalid={errors.deadline !== undefined}
            onChange={(event) => update('deadline', event.target.value)}
          />
        </Field>
      </div>
      <Field id="qp-area" label="Area">
        <select
          id="qp-area"
          className="quick-post-input"
          value={form.area}
          onChange={(event) => update('area', event.target.value)}
        >
          {AREAS.map((area) => (
            <option key={area} value={area}>
              {area}
            </option>
          ))}
        </select>
      </Field>
    </fieldset>
  );
}
