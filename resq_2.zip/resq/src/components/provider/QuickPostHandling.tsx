import type { QuickPostForm } from '../../provider/quickPost';
import { Field } from './QuickPostFields';

export type UpdateFormField = <K extends keyof QuickPostForm>(key: K, value: QuickPostForm[K]) => void;

interface QuickPostHandlingProps {
  form: QuickPostForm;
  update: UpdateFormField;
}

export function QuickPostHandling({ form, update }: QuickPostHandlingProps) {
  return (
    <fieldset className="quick-post-section">
      <legend>Food handling</legend>
      <Field id="qp-prepared" label="Preparation" optional>
        <textarea
          id="qp-prepared"
          className="quick-post-input quick-post-textarea"
          placeholder="e.g. Cooked fresh at 4 pm with no added preservatives."
          value={form.preparedAt}
          onChange={(event) => update('preparedAt', event.target.value)}
        />
      </Field>
      <Field id="qp-storage" label="Storage" optional>
        <textarea
          id="qp-storage"
          className="quick-post-input quick-post-textarea"
          placeholder="e.g. Keep covered and refrigerate below 5 C."
          value={form.storage}
          onChange={(event) => update('storage', event.target.value)}
        />
      </Field>
      <Field id="qp-reheating" label="Reheating" optional>
        <textarea
          id="qp-reheating"
          className="quick-post-input quick-post-textarea"
          placeholder="e.g. Heat until steaming hot before eating."
          value={form.reheating}
          onChange={(event) => update('reheating', event.target.value)}
        />
      </Field>
      <Field id="qp-allergens" label="Allergens" optional>
        <input
          id="qp-allergens"
          className="quick-post-input"
          type="text"
          placeholder="e.g. Nuts, Dairy, Gluten"
          value={form.allergens}
          onChange={(event) => update('allergens', event.target.value)}
        />
      </Field>
      <Field id="qp-note" label="Additional notes" optional>
        <textarea
          id="qp-note"
          className="quick-post-input quick-post-textarea"
          value={form.providerNote}
          onChange={(event) => update('providerNote', event.target.value)}
        />
      </Field>
    </fieldset>
  );
}
