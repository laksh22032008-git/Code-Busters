import type { ReactNode } from 'react';

interface FieldProps {
  id: string;
  label: string;
  optional?: boolean;
  error?: string;
  children: ReactNode;
}

export function Field({ id, label, optional = false, error, children }: FieldProps) {
  return (
    <div className="quick-post-field">
      <label className="quick-post-label" htmlFor={id}>
        {label}
        {optional && <span className="quick-post-optional"> (optional)</span>}
      </label>
      {children}
      {error && (
        <p className="quick-post-error" id={`${id}-error`} role="alert">
          {error}
        </p>
      )}
    </div>
  );
}

interface SegmentedOption<T extends string> {
  value: T;
  label: string;
}

interface SegmentedProps<T extends string> {
  label: string;
  options: SegmentedOption<T>[];
  value: T;
  onChange: (value: T) => void;
}

export function Segmented<T extends string>({ label, options, value, onChange }: SegmentedProps<T>) {
  return (
    <div className="quick-post-segmented" role="group" aria-label={label}>
      {options.map((option) => (
        <button
          key={option.value}
          type="button"
          className="quick-post-segment"
          aria-pressed={option.value === value}
          onClick={() => onChange(option.value)}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
}

interface StepperProps {
  id: string;
  label: string;
  value: number;
  min: number;
  max: number;
  onChange: (value: number) => void;
}

export function Stepper({ id, label, value, min, max, onChange }: StepperProps) {
  const clamp = (next: number): number => Math.min(max, Math.max(min, next));
  return (
    <div className="quick-post-stepper">
      <button
        type="button"
        className="quick-post-step"
        aria-label={`Decrease ${label}`}
        onClick={() => onChange(clamp(value - 1))}
      >
        -
      </button>
      <input
        id={id}
        className="quick-post-input quick-post-number"
        type="number"
        inputMode="numeric"
        min={min}
        max={max}
        value={value}
        onChange={(event) => onChange(Number(event.target.value))}
      />
      <button
        type="button"
        className="quick-post-step"
        aria-label={`Increase ${label}`}
        onClick={() => onChange(clamp(value + 1))}
      >
        +
      </button>
    </div>
  );
}
