import type { Category } from '../../data/types';

interface QuickPostPreviewProps {
  name: string;
  vendor: string;
  area: string;
  category: Category;
  isVeg: boolean;
  portions: number;
  isFree: boolean;
  price: string;
  originalPrice: string;
  image: string;
  pickupBy: string;
}

export function QuickPostPreview({
  name,
  vendor,
  area,
  category,
  isVeg,
  portions,
  isFree,
  price,
  originalPrice,
  image,
  pickupBy,
}: QuickPostPreviewProps) {
  const priceLabel = isFree ? 'Free' : `Rs ${price.trim() || '--'}`;
  const showWas = !isFree && originalPrice.trim() !== '';
  return (
    <aside className="post-preview" aria-label="Listing preview">
      <p className="post-preview-kicker">Live preview</p>
      <div className="post-preview-card">
        <img className="post-preview-image" src={image} alt="" />
        <div className="post-preview-body">
          <p className="post-preview-vendor">{vendor}</p>
          <h3 className="post-preview-name">{name.trim() || 'Your food name'}</h3>
          <p className="post-preview-meta">
            {area} / {isVeg ? 'Vegetarian' : 'Non-vegetarian'} / {category}
          </p>
          <p className="post-preview-line">
            <span>{portions} portions</span>
            <span className="post-preview-price">{priceLabel}</span>
          </p>
          {showWas && <p className="post-preview-was">Was Rs {originalPrice.trim()}</p>}
          <p className="post-preview-pickup">Pickup by {pickupBy}</p>
        </div>
      </div>
    </aside>
  );
}
