import { useState } from 'react';
import type { VendorLocation } from '../../provider/types';

type GeoStatus = 'idle' | 'pending' | 'error';

interface LocationFieldsProps {
  location: VendorLocation;
  onChange: (patch: Partial<VendorLocation>) => void;
}

const ADDRESS_MAX = 160;
const PIN_DECIMALS = 5;
const DEVICE_DECIMALS = 6;

function parseCoordinate(raw: string): number | null {
  return raw.trim() === '' ? null : Number(raw);
}

function pinText(location: VendorLocation): string {
  if (location.latitude === null || location.longitude === null) return 'No pin set yet';
  return `Pin: ${location.latitude.toFixed(PIN_DECIMALS)}, ${location.longitude.toFixed(PIN_DECIMALS)}`;
}

function geolocationMessage(error: GeolocationPositionError): string {
  if (error.code === error.PERMISSION_DENIED) {
    return 'Location permission was denied. You can type the address instead.';
  }
  return 'Your location could not be determined.';
}

export function LocationFields({ location, onChange }: LocationFieldsProps) {
  const [geoStatus, setGeoStatus] = useState<GeoStatus>('idle');
  const [geoError, setGeoError] = useState('');
  const hasAnyPin = location.latitude !== null || location.longitude !== null;

  function useCurrentLocation() {
    if (typeof navigator === 'undefined' || !navigator.geolocation) {
      setGeoStatus('error');
      setGeoError('Location is not available in this browser. Enter coordinates instead.');
      return;
    }
    setGeoStatus('pending');
    setGeoError('');
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setGeoStatus('idle');
        onChange({
          latitude: Number(position.coords.latitude.toFixed(DEVICE_DECIMALS)),
          longitude: Number(position.coords.longitude.toFixed(DEVICE_DECIMALS)),
          capturedVia: 'device',
        });
      },
      (error) => {
        setGeoStatus('error');
        setGeoError(geolocationMessage(error));
      },
    );
  }

  function clearPin() {
    onChange({ latitude: null, longitude: null, capturedVia: '' });
  }

  return (
    <fieldset className="profile-field profile-fieldset location-block">
      <legend className="profile-label">Restaurant location</legend>

      <div className="profile-field">
        <label className="profile-label" htmlFor="location-address">
          Address <span className="profile-required">(required)</span>
        </label>
        <input
          id="location-address"
          className="profile-input"
          type="text"
          maxLength={ADDRESS_MAX}
          value={location.addressLine}
          placeholder="Building, street, area"
          onChange={(event) => onChange({ addressLine: event.target.value })}
        />
      </div>

      <div className="profile-field">
        <label className="profile-label" htmlFor="location-landmark">
          Landmark (optional)
        </label>
        <input
          id="location-landmark"
          className="profile-input"
          type="text"
          value={location.landmark}
          onChange={(event) => onChange({ landmark: event.target.value })}
        />
      </div>

      <div className="location-actions">
        <button
          type="button"
          className="profile-btn profile-btn--secondary"
          onClick={useCurrentLocation}
          disabled={geoStatus === 'pending'}
        >
          Use my current location
        </button>
        {geoStatus === 'pending' && (
          <p className="profile-helper" role="status">
            Getting your location...
          </p>
        )}
      </div>
      {geoStatus === 'error' && (
        <p className="profile-helper profile-helper--error" role="alert">
          {geoError}
        </p>
      )}

      <div className="profile-field">
        <label className="profile-label" htmlFor="location-latitude">
          Latitude
        </label>
        <input
          id="location-latitude"
          className="profile-input"
          type="number"
          step="any"
          value={location.latitude ?? ''}
          onChange={(event) =>
            onChange({ latitude: parseCoordinate(event.target.value), capturedVia: 'manual' })
          }
        />
      </div>

      <div className="profile-field">
        <label className="profile-label" htmlFor="location-longitude">
          Longitude
        </label>
        <input
          id="location-longitude"
          className="profile-input"
          type="number"
          step="any"
          value={location.longitude ?? ''}
          onChange={(event) =>
            onChange({ longitude: parseCoordinate(event.target.value), capturedVia: 'manual' })
          }
        />
      </div>

      <div className="location-pin">
        <span>{pinText(location)}</span>
        {hasAnyPin && (
          <button type="button" onClick={clearPin}>
            Clear pin
          </button>
        )}
      </div>
    </fieldset>
  );
}
