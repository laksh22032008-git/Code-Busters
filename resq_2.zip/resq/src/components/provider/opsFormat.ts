import type { ClaimStatus, ListingStatus } from '../../provider/types';
import type { PillTone } from './StatusPill';

export const LISTING_STATUS_LABEL: Record<ListingStatus, string> = {
  active: 'Active',
  'fully-claimed': 'Fully claimed',
  expired: 'Expired',
  collected: 'Collected',
  cancelled: 'Cancelled',
};

export const LISTING_STATUS_TONE: Record<ListingStatus, PillTone> = {
  active: 'primary',
  'fully-claimed': 'urgency',
  expired: 'urgency',
  collected: 'neutral',
  cancelled: 'neutral',
};

export const CLAIM_STATUS_LABEL: Record<ClaimStatus, string> = {
  reserved: 'Reserved',
  ready: 'Ready for pickup',
  collected: 'Collected',
  expired: 'Expired',
  cancelled: 'Cancelled',
};

export const CLAIM_STATUS_TONE: Record<ClaimStatus, PillTone> = {
  reserved: 'neutral',
  ready: 'primary',
  collected: 'neutral',
  expired: 'urgency',
  cancelled: 'neutral',
};

export function formatClock(iso: string): string {
  return new Date(iso).toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit' });
}

export function formatPortions(count: number): string {
  return `${count} ${count === 1 ? 'portion' : 'portions'}`;
}
