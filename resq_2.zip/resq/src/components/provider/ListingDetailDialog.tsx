import { useEffect, useId, useLayoutEffect, useRef, useState, type MouseEvent } from 'react';
import { useAppState } from '../../context/AppStateContext';
import type { ProviderListingView } from '../../provider/types';
import '../../styles/modal.css';
import '../../styles/provider-ops.css';
import { ListingEditForm } from './ListingEditForm';
import {
  CLAIM_STATUS_LABEL,
  CLAIM_STATUS_TONE,
  LISTING_STATUS_LABEL,
  LISTING_STATUS_TONE,
  formatClock,
  formatPortions,
} from './opsFormat';
import { StatusPill } from './StatusPill';

const CANCEL_REASONS = ['Food spoiled', 'Closed early', 'Sold elsewhere', 'Other'];

interface ListingDetailDialogProps {
  view: ProviderListingView;
  onClose: () => void;
}

export function ListingDetailDialog({ view, onClose }: ListingDetailDialogProps) {
  const { cancelListing, markUnavailable, deleteListing } = useAppState();
  const titleId = useId();
  const { record, status } = view;
  const [editing, setEditing] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [confirmingDelete, setConfirmingDelete] = useState(false);
  const deletingRef = useRef(false);
  const [reason, setReason] = useState('Food spoiled');
  const [error, setError] = useState<string | null>(null);
  const locked = status === 'cancelled' || status === 'collected' || status === 'expired';

  // Runs before the dialog content mounts, so the opening row button is captured for focus return.
  useLayoutEffect(() => {
    const trigger = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    return () => {
      trigger?.focus();
    };
  }, []);

  useEffect(() => {
    const handleKey = (event: KeyboardEvent): void => {
      if (event.key === 'Escape') onClose();
    };
    document.addEventListener('keydown', handleKey);
    return () => document.removeEventListener('keydown', handleKey);
  }, [onClose]);

  const handleBackdrop = (event: MouseEvent<HTMLDivElement>): void => {
    if (event.target === event.currentTarget) onClose();
  };

  const handleUnavailable = (): void => {
    const result = markUnavailable(record.id);
    setError(result.ok ? null : result.error);
  };

  const handleCancel = (): void => {
    const result = cancelListing(record.id, reason);
    setError(result.ok ? null : result.error);
    if (result.ok) setConfirming(false);
  };

  const handleDelete = (): void => {
    if (deletingRef.current) return;
    deletingRef.current = true;
    const result = deleteListing(record.id);
    if (result.ok) {
      onClose();
      return;
    }
    deletingRef.current = false;
    setError(result.error);
  };

  const priceText = record.price === 0 ? 'Free' : `₹${record.price} (was ₹${record.originalPrice})`;

  return (
    <div className="modal-backdrop" onMouseDown={handleBackdrop}>
      <div className="modal ops-dialog" role="dialog" aria-modal="true" aria-labelledby={titleId}>
        <header className="modal-header">
          <div className="ops-dialog-heading">
            <h2 className="ops-dialog-title" id={titleId}>
              {record.name}
            </h2>
            <StatusPill label={LISTING_STATUS_LABEL[status]} tone={LISTING_STATUS_TONE[status]} />
          </div>
          <button type="button" className="ops-button" onClick={onClose}>
            Close
          </button>
        </header>

        <div className="modal-body">
          <dl className="facts">
            <div className="fact-row">
              <dt>Type</dt>
              <dd>{record.price === 0 ? 'Free' : 'Discounted'}</dd>
            </div>
            <div className="fact-row">
              <dt>Price</dt>
              <dd>{priceText}</dd>
            </div>
            <div className="fact-row">
              <dt>Portions posted</dt>
              <dd>{record.portionsTotal}</dd>
            </div>
            <div className="fact-row">
              <dt>Remaining</dt>
              <dd>{view.portionsRemaining}</dd>
            </div>
            <div className="fact-row">
              <dt>Claimed</dt>
              <dd>{view.portionsClaimed}</dd>
            </div>
            <div className="fact-row">
              <dt>Collected</dt>
              <dd>{view.portionsCollected}</dd>
            </div>
            <div className="fact-row">
              <dt>Pickup window</dt>
              <dd>
                {formatClock(record.pickupStart)} to {formatClock(record.pickupDeadline)}
              </dd>
            </div>
            <div className="fact-row">
              <dt>Area</dt>
              <dd>{record.area}</dd>
            </div>
            {status === 'cancelled' && (
              <div className="fact-row">
                <dt>Cancel reason</dt>
                <dd>{record.cancelReason}</dd>
              </div>
            )}
          </dl>

          <section className="detail-block">
            <h3>Pickups for this listing</h3>
            {view.claims.length === 0 ? (
              <p className="ops-empty">No one has claimed this listing yet.</p>
            ) : (
              <ul className="ops-claims">
                {view.claims.map((claim) => (
                  <li key={claim.id} className="ops-claim">
                    <span className="pickup-code">{claim.code}</span>
                    <span className="ops-claim-meta">
                      {formatPortions(claim.portions)}, {claim.collectorName}, claimed {formatClock(claim.claimedAt)}
                    </span>
                    <StatusPill label={CLAIM_STATUS_LABEL[claim.status]} tone={CLAIM_STATUS_TONE[claim.status]} />
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className="detail-block">
            <h3>Edit listing</h3>
            {editing ? (
              <ListingEditForm record={record} onDone={() => setEditing(false)} />
            ) : (
              <div className="ops-actions">
                <button type="button" className="ops-button" disabled={locked} onClick={() => setEditing(true)}>
                  Edit listing
                </button>
              </div>
            )}
          </section>

          <section className="detail-block">
            <h3>Listing actions</h3>
            <div className="ops-actions">
              <button type="button" className="ops-button" disabled={locked} onClick={handleUnavailable}>
                Mark unavailable
              </button>
              {!confirming && (
                <button type="button" className="ops-button" disabled={locked} onClick={() => setConfirming(true)}>
                  Cancel listing
                </button>
              )}
            </div>
            {confirming && (
              <div className="ops-confirm">
                <label className="ops-field">
                  <span>Reason for cancelling</span>
                  <select className="ops-input" value={reason} onChange={(event) => setReason(event.target.value)}>
                    {CANCEL_REASONS.map((item) => (
                      <option key={item} value={item}>
                        {item}
                      </option>
                    ))}
                  </select>
                </label>
                <div className="ops-actions">
                  <button type="button" className="ops-button-solid" onClick={handleCancel}>
                    Confirm cancel
                  </button>
                  <button type="button" className="ops-button" onClick={() => setConfirming(false)}>
                    Keep listing
                  </button>
                </div>
              </div>
            )}
            {status === 'expired' && !confirmingDelete && (
              <div className="ops-actions">
                <button type="button" className="ops-button" onClick={() => setConfirmingDelete(true)}>
                  Delete listing
                </button>
              </div>
            )}
            {status === 'expired' && confirmingDelete && (
              <div className="ops-confirm">
                <p>Delete this expired listing? It will be removed from your list and from Discover and the map.</p>
                <div className="ops-actions">
                  <button type="button" className="ops-button-solid" onClick={handleDelete}>
                    Yes, delete
                  </button>
                  <button type="button" className="ops-button" onClick={() => setConfirmingDelete(false)}>
                    Keep it
                  </button>
                </div>
              </div>
            )}
          </section>

          {error && (
            <p className="ops-error" role="alert">
              {error}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
