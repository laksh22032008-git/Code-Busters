import type { ReactNode } from 'react';
import '../../styles/provider.css';
import { PROVIDER_BUSINESS_NAME } from '../../data/vendors';

interface ProviderPageHeaderProps {
  title: string;
  subtitle?: string;
  action?: ReactNode;
}

export function ProviderPageHeader({ title, subtitle, action }: ProviderPageHeaderProps) {
  return (
    <header className="provider-page-header">
      <div>
        <p className="provider-kicker">{PROVIDER_BUSINESS_NAME}</p>
        <h1 className="provider-title">{title}</h1>
        {subtitle && <p className="provider-subtitle">{subtitle}</p>}
      </div>
      {action}
    </header>
  );
}
