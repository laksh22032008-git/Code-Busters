import { useState, type FormEvent } from 'react';
import { useAppState } from '../../context/AppStateContext';

interface PickupVerifyPanelProps {
  claimId: string;
  onDone: () => void;
  onCancel: () => void;
}

export function PickupVerifyPanel({ claimId, onDone, onCancel }: PickupVerifyPanelProps) {
  const { confirmPickup } = useAppState();
  const [code, setCode] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (event: FormEvent<HTMLFormElement>): void => {
    event.preventDefault();
    const result = confirmPickup(claimId, code);
    if (result.ok) {
      onDone();
      return;
    }
    setError(result.error);
  };

  return (
    <form className="ops-verify" onSubmit={handleSubmit}>
      <p className="ops-verify-note">
        Demo verification: enter the code shown to the collector. QR scanning is not available in this demo.
      </p>
      <div className="ops-verify-row">
        <input
          className="ops-input pickup-code-input"
          type="text"
          aria-label="Pickup code"
          placeholder="Enter the pickup code"
          autoComplete="off"
          autoCapitalize="characters"
          autoFocus
          value={code}
          onChange={(event) => setCode(event.target.value)}
        />
        <button type="submit" className="ops-button-solid">
          Confirm
        </button>
        <button type="button" className="ops-button" onClick={onCancel}>
          Cancel
        </button>
      </div>
      {error && (
        <p className="ops-error" role="alert">
          {error}
        </p>
      )}
      {error?.startsWith('Too many incorrect codes') ? (
        <p className="ops-verify-note">
          Code entry is paused for this claim until the time above has passed. Then enter the code again.
        </p>
      ) : null}
    </form>
  );
}
