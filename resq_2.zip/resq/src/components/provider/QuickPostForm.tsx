import { useEffect, useState, type FormEvent } from 'react';
import { useAppState } from '../../context/AppStateContext';
import {
  ALLERGEN_OPTIONS,
  FIELD_ORDER,
  QUICK_FOOD_PRESETS,
  STORAGE_OPTIONS,
  buildInput,
  defaultForm,
  formatClock,
  quickDeadline,
  timeValue,
  validateForm,
  type QuickPostForm as FormState,
} from '../../provider/quickPost';
import { Field, Stepper } from './QuickPostFields';

interface QuickPostFormProps {
  onDone: () => void;
}

type StepNumber = 1 | 2 | 3;
type PickupHours = 1 | 2 | 3;
type Preset = (typeof QUICK_FOOD_PRESETS)[number];
type Allergen = (typeof ALLERGEN_OPTIONS)[number];

const PICKUP_CHOICES: PickupHours[] = [1, 2, 3];
const KG_MIN = 0.5;
const KG_MAX = 200;
const SERVINGS_MIN = 1;
const SERVINGS_MAX = 200;

export function QuickPostForm({ onDone }: QuickPostFormProps) {
  const { provider, now, postListing } = useAppState();
  const [form, setForm] = useState<FormState>(() => ({
    ...defaultForm(now, provider.profile.area),
    ...quickDeadline(now, 2),
    isFree: true,
    price: '',
    originalPrice: '',
  }));
  const [step, setStep] = useState<StepNumber>(1);
  const [pickupHours, setPickupHours] = useState<PickupHours>(2);
  const [formError, setFormError] = useState('');
  const [mountedAt] = useState(() => Date.now());
  const [elapsed, setElapsed] = useState(0);
  const [posted, setPosted] = useState(false);

  // Listing Time badge: whole seconds since mount; frozen once the listing is posted.
  useEffect(() => {
    if (posted) return undefined;
    const id = window.setInterval(() => {
      setElapsed(Math.floor((Date.now() - mountedAt) / 1000));
    }, 1000);
    return () => window.clearInterval(id);
  }, [posted, mountedAt]);

  const patch = (changes: Partial<FormState>): void => {
    setForm((prev) => ({ ...prev, ...changes }));
  };

  const choosePreset = (preset: Preset): void => {
    patch({ name: preset.name, category: preset.category, isVeg: preset.isVeg, image: preset.image });
  };

  const choosePickup = (hours: PickupHours): void => {
    setPickupHours(hours);
    patch(quickDeadline(now, hours));
  };

  const selectedAllergens = form.allergens
    .split(',')
    .map((item) => item.trim())
    .filter((item) => item.length > 0);

  const toggleAllergen = (option: Allergen): void => {
    if (option === 'None') {
      patch({ allergens: '' });
      return;
    }
    const next = selectedAllergens.includes(option)
      ? selectedAllergens.filter((item) => item !== option)
      : [...selectedAllergens, option];
    patch({ allergens: ALLERGEN_OPTIONS.filter((item) => next.includes(item)).join(', ') });
  };

  const changeKg = (raw: string): void => {
    const next = Number(raw);
    if (Number.isNaN(next)) return;
    patch({ quantityKg: Math.min(KG_MAX, Math.max(KG_MIN, next)) });
  };

  const kgValid = form.quantityKg >= KG_MIN && form.quantityKg <= KG_MAX;
  const servingsValid = form.portions >= SERVINGS_MIN && form.portions <= SERVINGS_MAX;
  const stepValid = step === 1 ? form.name.trim() !== '' : step === 2 ? kgValid && servingsValid : true;

  const goBack = (): void => {
    setFormError('');
    setStep(step === 3 ? 2 : 1);
  };

  const goNext = (): void => {
    if (!stepValid) return;
    setFormError('');
    setStep(step === 1 ? 2 : 3);
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>): void => {
    event.preventDefault();
    if (step !== 3) return;
    setFormError('');
    const found = validateForm(form, now);
    const firstError = FIELD_ORDER.map((key) => found[key]).find((message): message is string => message !== undefined);
    if (firstError !== undefined) {
      setFormError(firstError);
      return;
    }
    const result = postListing(buildInput({ ...form, preparedAt: `Prepared ${timeValue(now)}` }));
    if (result.ok) {
      setElapsed(Math.floor((Date.now() - mountedAt) / 1000));
      setPosted(true);
      onDone();
      return;
    }
    setFormError(result.error);
  };

  return (
    <form className="quick-post-form" onSubmit={handleSubmit} noValidate>
      <div className="quick-post-progress" aria-hidden="true">
        {([1, 2, 3] as const).map((segment) => (
          <span
            key={segment}
            className={`quick-post-progress-seg${segment < step ? ' is-done' : segment === step ? ' is-current' : ''}`}
          />
        ))}
      </div>
      <p className="listing-timer-badge quick-post-timer" role="status">{`Listing Time: ${elapsed}s`}</p>

      <div className="quick-post-body">
        <div className="quick-post-fields">
          <p className="quick-post-label" aria-live="polite">{`Step ${step} of 3`}</p>

          {step === 1 && (
            <fieldset className="quick-post-section">
              <legend>What food?</legend>
              <div className="quick-post-segmented" role="group" aria-label="Food type">
                {QUICK_FOOD_PRESETS.map((preset) => (
                  <button
                    key={preset.name}
                    type="button"
                    className="quick-post-segment"
                    aria-pressed={form.name === preset.name}
                    onClick={() => choosePreset(preset)}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </fieldset>
          )}

          {step === 2 && (
            <fieldset className="quick-post-section">
              <legend>How much?</legend>
              <Field id="qp-quantity" label="Quantity (kg)">
                <input
                  id="qp-quantity"
                  className="quick-post-input"
                  type="number"
                  inputMode="decimal"
                  min={KG_MIN}
                  max={KG_MAX}
                  step={0.5}
                  value={form.quantityKg}
                  onChange={(event) => changeKg(event.target.value)}
                />
              </Field>
              <Field id="qp-servings" label="Servings">
                <Stepper
                  id="qp-servings"
                  label="servings"
                  value={form.portions}
                  min={SERVINGS_MIN}
                  max={SERVINGS_MAX}
                  onChange={(value) => patch({ portions: value })}
                />
              </Field>
            </fieldset>
          )}

          {step === 3 && (
            <fieldset className="quick-post-section">
              <legend>Pickup by</legend>
              <div className="quick-post-segmented" role="group" aria-label="Pickup window">
                {PICKUP_CHOICES.map((hours) => (
                  <button
                    key={hours}
                    type="button"
                    className="quick-post-segment"
                    aria-pressed={pickupHours === hours}
                    onClick={() => choosePickup(hours)}
                  >
                    {`+${hours} ${hours === 1 ? 'Hour' : 'Hours'}`}
                  </button>
                ))}
              </div>
              <p className="quick-post-label">{`Pickup by ${formatClock(form.date, form.deadline)}`}</p>

              <span className="quick-post-label">Storage</span>
              <div className="quick-post-segmented" role="radiogroup" aria-label="Storage">
                {STORAGE_OPTIONS.map((option) => (
                  <button
                    key={option}
                    type="button"
                    role="radio"
                    className="quick-post-segment"
                    aria-checked={form.storage === option}
                    onClick={() => patch({ storage: option })}
                  >
                    {option}
                  </button>
                ))}
              </div>

              <span className="quick-post-label">Allergens</span>
              <div className="quick-post-segmented" role="group" aria-label="Allergens">
                {ALLERGEN_OPTIONS.map((option) => {
                  const pressed = option === 'None' ? selectedAllergens.length === 0 : selectedAllergens.includes(option);
                  return (
                    <button
                      key={option}
                      type="button"
                      className="quick-post-segment"
                      aria-pressed={pressed}
                      onClick={() => toggleAllergen(option)}
                    >
                      {option}
                    </button>
                  );
                })}
              </div>
            </fieldset>
          )}
        </div>
      </div>

      <div className="quick-post-footer">
        {formError && (
          <p className="quick-post-error quick-post-footer-error" role="alert">
            {formError}
          </p>
        )}
        <button type="button" className="secondary-button quick-post-cancel" onClick={onDone}>
          Cancel
        </button>
        <button type="button" className="secondary-button" disabled={step === 1} onClick={goBack}>
          Back
        </button>
        {step < 3 && (
          <button type="button" className="primary-button" disabled={!stepValid} onClick={goNext}>
            Next
          </button>
        )}
        {step === 3 && (
          <button type="submit" className="primary-button quick-post-submit">
            Post listing
          </button>
        )}
      </div>
      <p className="platform-disclaimer">
        This platform connects food donors with nearby receivers and does not inspect or certify food safety. Donors and
        receivers must follow displayed handling and time-window guidelines.
      </p>
    </form>
  );
}
