import type { Listing } from '../data/types';

const AREA_LABELS: { name: string; x: number; y: number }[] = [
  { name: 'Indiranagar', x: 4, y: 14 },
  { name: 'Koramangala', x: 62, y: 92 },
  { name: 'HSR Layout', x: 74, y: 56 },
  { name: 'Jayanagar', x: 8, y: 92 },
  { name: 'Whitefield', x: 80, y: 10 },
  { name: 'Malleshwaram', x: 4, y: 64 },
];

interface MapViewProps {
  listings: Listing[];
  selectedId: string | null;
  onSelect: (id: string) => void;
}

export function MapView({ listings, selectedId, onSelect }: MapViewProps) {
  return (
    <div className="map-canvas" role="region" aria-label="Simulated map of food near you">
      <svg className="map-base" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true" focusable="false">
        <rect x={0} y={0} width={100} height={100} className="map-land" />
        <path className="map-water" d="M0 62 Q25 55 45 66 T100 58 L100 72 Q70 80 45 74 T0 78 Z" />
        <rect x={60} y={6} width={26} height={20} rx={2} className="map-park" />
        <g className="map-street">
          <path d="M0 30 L100 40" />
          <path d="M0 14 L100 20" />
          <path d="M30 0 L38 100" />
          <path d="M70 0 L62 100" />
          <path d="M0 88 L100 84" />
        </g>
      </svg>
      {AREA_LABELS.map((area) => (
        <span key={area.name} className="map-label" style={{ left: `${area.x}%`, top: `${area.y}%` }}>
          {area.name}
        </span>
      ))}
      <div className="map-you" style={{ left: '50%', top: '50%' }}>
        <span className="map-you-dot" aria-hidden="true" />
        <span className="map-you-label">You are here</span>
      </div>
      {listings.map((listing) => {
        const isSelected = listing.id === selectedId;
        const classes = ['map-marker', listing.isVeg ? 'is-veg' : 'is-nonveg', isSelected ? 'is-selected' : '']
          .filter(Boolean)
          .join(' ');
        return (
          <button
            key={listing.id}
            type="button"
            className={classes}
            style={{ left: `${listing.x}%`, top: `${listing.y}%` }}
            aria-label={`${listing.name}, ${listing.distanceKm.toFixed(1)} km`}
            aria-pressed={isSelected}
            onClick={() => onSelect(listing.id)}
          />
        );
      })}
    </div>
  );
}
