interface FilterChipProps {
  label: string;
  active: boolean;
  onClick: () => void;
}

export function FilterChip({ label, active, onClick }: FilterChipProps) {
  return (
    <button
      type="button"
      className={active ? 'filter-chip is-active' : 'filter-chip'}
      aria-pressed={active}
      onClick={onClick}
    >
      {label}
    </button>
  );
}
