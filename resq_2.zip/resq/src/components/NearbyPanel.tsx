import type { Listing } from '../data/types';


interface NearbyPanelProps {
  listings: Listing[];
  selectedId: string | null;
  onSelect: (id: string) => void;
}

export function NearbyPanel({ listings, selectedId, onSelect }: NearbyPanelProps) {
  return (
    <section className="nearby-panel" aria-labelledby="nearby-title">
      <h2 id="nearby-title" className="nearby-title">
        Nearby pickups ({listings.length})
      </h2>
      {listings.length === 0 ? <p className="nearby-empty">No pickups match these filters.</p> : null}
      <ul className="nearby-list">
        {listings.map((listing) => (
          <li key={listing.id}>
            <button
              type="button"
              className={listing.id === selectedId ? 'nearby-item is-selected' : 'nearby-item'}
              aria-pressed={listing.id === selectedId}
              onClick={() => onSelect(listing.id)}
            >
              <span className="nearby-name">{listing.name}</span>
              <span className="nearby-meta">
                {listing.distanceKm.toFixed(1)} km · {listing.area}
              </span>
            </button>
          </li>
        ))}
      </ul>
    </section>
  );
}
