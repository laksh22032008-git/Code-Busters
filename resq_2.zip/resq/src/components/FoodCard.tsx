import type { Listing } from '../data/types';
import { useAppState } from '../context/AppStateContext';
import { AVAILABILITY_LABEL, getAvailability, isOpenForClaim, isUrgent } from '../lib/availability';
import { recommendListing } from '../lib/recommend';
import { formatClock, formatDistance, formatTimeLeft } from '../lib/time';
import { Icon } from './Icon';

interface FoodCardProps {
  listing: Listing;
}

/**
 * Live countdown to the pickup deadline, computed from the current time.
 * Returns "Xh Ym", "Ym" when under an hour, or "Expired" once the deadline has passed.
 */
export function formatExpiresIn(deadlineIso: string, nowMs: number): string {
  const diffMs = new Date(deadlineIso).getTime() - nowMs;
  if (diffMs <= 0) return 'Expired';
  const totalMin = Math.floor(diffMs / 60000);
  if (totalMin < 60) return `${totalMin}m`;
  return `${Math.floor(totalMin / 60)}h ${totalMin % 60}m`;
}

export function FoodCard({ listing }: FoodCardProps) {
  const { now, saved, toggleSaved, openListing, sort } = useAppState();
  const availability = getAvailability(listing, now);
  const isSaved = saved.has(listing.id);
  const isDiscounted = listing.originalPrice > listing.price;
  const topReasons = sort === 'recommended' ? recommendListing(listing, now).reasons.slice(0, 2) : [];
  const urgent = isUrgent(listing, now);
  const soldOut = listing.portionsRemaining === 0 || !isOpenForClaim(listing, now);
  const stateKey = soldOut ? 'soldout' : urgent ? 'urgent' : 'available';
  const stateLabel = soldOut ? 'Sold out' : urgent ? 'Urgent' : 'Available';
  const stateModifier = soldOut ? ' hl-pill--neutral' : urgent ? ' hl-pill--alert' : '';
  const rootClass = ['food-card', availability === 'sold' && 'is-sold', urgent && 'is-urgent']
    .filter(Boolean)
    .join(' ');

  return (
    <article className={rootClass}>
      <div className="food-card-body" onClick={() => openListing(listing.id)}>
        <div className="food-card-media">
          <img src={listing.image} alt="" loading="lazy" width={800} height={600} />
          <span className={`hl-pill${stateModifier} food-card-state is-${stateKey}`}>{stateLabel}</span>
          <span
            className={listing.isVeg ? 'diet-mark is-veg' : 'diet-mark is-nonveg'}
            role="img"
            aria-label={listing.isVeg ? 'Vegetarian' : 'Non-vegetarian'}
          />
          <span className={`status-pill status-${availability}`}>
            {AVAILABILITY_LABEL[availability]}
          </span>
        </div>
        <div className="food-card-info">
          <p className="food-card-vendor">
            {listing.vendor} · {listing.area}
          </p>
          <h3 className="food-card-name">{listing.name}</h3>
          <p className="food-card-meta">
            {formatDistance(listing.distanceKm)} · {listing.portionsRemaining} of{' '}
            {listing.portionsTotal} portions left
          </p>
          <p className="food-card-pickup food-card-countdown">
            Pickup by {formatClock(listing.pickupDeadline)} · {formatTimeLeft(listing.pickupDeadline, now)}
          </p>
          {topReasons.length > 0 ? (
            <p className="recommend-reasons">{topReasons.join(' · ')}</p>
          ) : null}
          <div className="safety-row">
            <span className="safety-item">
              <span className="safety-label">Prepared</span> {listing.handling.preparedAt}
            </span>
            <span className="safety-item">
              <span className="safety-label">Expires in</span>{' '}
              {formatExpiresIn(listing.pickupDeadline, Date.now())}
            </span>
            <span className="safety-item">
              <span className="safety-label">Storage</span> {listing.handling.storage}
            </span>
            <span className="safety-item">
              <span className="safety-label">Allergens</span>{' '}
              {listing.allergens.length === 0
                ? 'None listed'
                : listing.allergens.map((item) => (
                    <span
                      key={item}
                      className={
                        /dairy|milk|lactose|cheese|butter|cream|ghee|paneer|nut|peanut|almond|cashew|walnut|pistachio/i.test(item)
                          ? 'hl-pill hl-pill--neutral allergen-chip food-card-tag is-accent'
                          : 'hl-pill hl-pill--neutral allergen-chip food-card-tag'
                      }
                    >
                      {item}
                    </span>
                  ))}
            </span>
          </div>
          <p className="card-safety-note">Synthetic demo listing. Not certified for food safety.</p>
          <p className="food-card-price">
            {listing.price === 0 ? (
              <span className="price-free">Free</span>
            ) : (
              <span className="price-now">₹{listing.price}</span>
            )}
            {isDiscounted ? <s className="price-was">₹{listing.originalPrice}</s> : null}
          </p>
        </div>
      </div>
      <div className="food-card-actions">
        <button
          type="button"
          className="save-button"
          aria-pressed={isSaved}
          aria-label={isSaved ? `Remove ${listing.name} from saved` : `Save ${listing.name}`}
          onClick={() => toggleSaved(listing.id)}
        >
          <Icon name="saved" />
        </button>
        <button
          type="button"
          className="claim-button"
          aria-label={`Open details for ${listing.name} from ${listing.vendor}`}
          onClick={() => openListing(listing.id)}
        >
          View &amp; claim
        </button>
      </div>
    </article>
  );
}
