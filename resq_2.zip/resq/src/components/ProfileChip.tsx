import { Link } from 'react-router-dom';
import { useAppState } from '../context/AppStateContext';
import { ROLE_LABEL } from '../lib/nav';

export function ProfileChip() {
  const { role } = useAppState();
  return (
    <Link to="/profile" className="profile-chip">
      <span className="avatar" aria-hidden="true">
        GU
      </span>
      <span className="profile-text">
        <strong>Guest user</strong>
        <small>{ROLE_LABEL[role]}</small>
      </span>
    </Link>
  );
}
