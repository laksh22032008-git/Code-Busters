import { useAppState } from '../context/AppStateContext';
import { greetingFor } from '../lib/time';

export function HeroGreeting() {
  useAppState();
  const greeting = greetingFor(new Date().getHours());
  return (
    <section className="hero" aria-labelledby="hero-title">
      <p className="hero-kicker">Wedding & corporate caterers rescuing surplus for community kitchens and night shelters in Koramangala & Indiranagar, Bengaluru</p>
      <p className="hero-live">
        <span className="hero-live-dot" aria-hidden="true" />
        LIVE IN KORAMANGALA & INDIRANAGAR
      </p>
      <h1 id="hero-title" className="hero-title">
        <mark className="hero-highlight">{greeting}</mark>.
      </h1>
      <p className="hero-text">
        Post a surplus tray in under a minute. Nearby community kitchens and night shelters get a match score and a pickup window.
      </p>
    </section>
  );
}
