import { PlaceholderPage } from './PlaceholderPage';

export function AdminIntro() {
  return (
    <PlaceholderPage
      title="Platform admin"
      description="Verification, moderation and food-safety oversight tools for the ResQFood team will live here."
      demoLabel="Preview review queue"
      demoFeature="the admin review queue"
    >
      <ul className="intro-list">
        <li>Review vendor verification documents</li>
        <li>Moderate listings and community feedback</li>
        <li>Monitor pickup and waste-reduction metrics</li>
      </ul>
    </PlaceholderPage>
  );
}
