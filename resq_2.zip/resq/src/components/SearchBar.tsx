import { useAppState } from '../context/AppStateContext';
import { Icon } from './Icon';

export function SearchBar() {
  const { query, setQuery } = useAppState();
  return (
    <div className="search-bar" role="search">
      <label className="visually-hidden" htmlFor="food-search">
        Search food or restaurant
      </label>
      <input
        id="food-search"
        type="text"
        className="search-input"
        placeholder="Search food or restaurant"
        value={query}
        autoComplete="off"
        onChange={(event) => setQuery(event.target.value)}
      />
      {query ? (
        <button
          type="button"
          className="search-clear"
          aria-label="Clear search"
          onClick={() => setQuery('')}
        >
          <Icon name="close" />
        </button>
      ) : null}
    </div>
  );
}
