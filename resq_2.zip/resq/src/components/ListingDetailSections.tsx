import { useState } from 'react';
import type { Listing, TrustStatus } from '../data/types';
import { findVendor } from '../data/vendors';
import { useAppState } from '../context/AppStateContext';
import { formatClock } from '../lib/time';
import { vendorTrustStatus } from '../lib/trust';
import { REPORT_REASONS } from '../provider/types';
import { PickupTracker } from './PickupTracker';
import { ReceiverMatches } from './ReceiverMatches';

const TRUST_LABELS: Record<TrustStatus, string> = {
  trusted: 'Trusted provider',
  'under-review': 'Under review',
  suspended: 'Suspended',
};

export const FOOD_NOTICE =
  'Food handling information is provided by the vendor. This platform connects food donors with nearby receivers and does not inspect or certify food safety. Donors and receivers must follow displayed handling and time-window guidelines.';

interface ListingSummaryProps {
  listing: Listing;
}

/** Right-column summary: name, area, price and compact pickup facts. */
export function ListingSummary({ listing }: ListingSummaryProps) {
  const isDiscounted = listing.originalPrice > listing.price;

  return (
    <div className="listing-summary">
      <h2 id="listing-modal-title" className="listing-title">
        {listing.name}
      </h2>
      <p className="listing-meta">
        {listing.area}, {listing.distanceKm.toFixed(1)} km away
      </p>
      <p className="listing-meta">
        <span
          className={listing.isVeg ? 'veg-mark veg-mark-veg' : 'veg-mark veg-mark-nonveg'}
          aria-hidden="true"
        />
        {listing.isVeg ? 'Vegetarian' : 'Non-vegetarian'} · {listing.category}
      </p>
      <p className="price-row">
        <span className="price-now">{listing.price === 0 ? 'Free' : `₹${listing.price}`}</span>
        {isDiscounted ? <s className="price-was">₹{listing.originalPrice}</s> : null}
      </p>
      <dl className="facts">
        <div className="fact-row">
          <dt>Portions left</dt>
          <dd>
            {listing.portionsRemaining} of {listing.portionsTotal}
          </dd>
        </div>
        <div className="fact-row">
          <dt>Pickup window</dt>
          <dd>
            {formatClock(listing.pickupStart)} to {formatClock(listing.pickupDeadline)}
          </dd>
        </div>
        <div className="fact-row">
          <dt>Pick up by</dt>
          <dd>{formatClock(listing.pickupDeadline)}</dd>
        </div>
      </dl>
      <ul className="tag-list">
        {listing.tags.map((tag) => (
          <li key={tag}>{tag}</li>
        ))}
      </ul>
    </div>
  );
}

interface ListingDetailSectionsProps {
  listing: Listing;
}

/** Full-width sections shown below the two columns. */
export function ListingDetailSections({ listing }: ListingDetailSectionsProps) {
  const vendor = findVendor(listing.vendorId);
  const { provider, reportListing } = useAppState();
  const [reportOpen, setReportOpen] = useState(false);
  const [reason, setReason] = useState<string>(REPORT_REASONS[0]);
  const openReports = (provider.reports ?? []).filter((report) => report.vendorId === listing.vendorId).length;
  const trust = vendorTrustStatus(vendor ?? {}, openReports);

  const handleSendReport = (): void => {
    const result = reportListing(listing.id, reason);
    if (result.ok) setReportOpen(false);
  };

  return (
    <div className="detail-sections">
      <PickupTracker listingId={listing.id} />

      <section className="detail-block" aria-labelledby="detail-handling">
        <h3 id="detail-handling">Food handling</h3>
        <dl className="handling-rows">
          <div className="handling-row">
            <dt>Prepared</dt>
            <dd>{listing.handling.preparedAt}</dd>
          </div>
          <div className="handling-row">
            <dt>Storage</dt>
            <dd>{listing.handling.storage}</dd>
          </div>
          <div className="handling-row">
            <dt>Reheating</dt>
            <dd>{listing.handling.reheating}</dd>
          </div>
          <div className="handling-row">
            <dt>Provider note</dt>
            <dd>{listing.handling.providerNote}</dd>
          </div>
        </dl>
      </section>

      <section className="detail-block" aria-labelledby="detail-allergens">
        <h3 id="detail-allergens">Allergens</h3>
        {listing.allergens.length === 0 ? <p>Not listed by the vendor</p> : null}
        <ul className="tag-list">
          {listing.allergens.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      </section>

      {vendor ? (
        <section className="detail-block" aria-labelledby="detail-vendor">
          <h3 id="detail-vendor">About the vendor</h3>
          <p>
            <strong>{vendor.name}</strong> · rating {vendor.rating.toFixed(1)} · {vendor.yearsOperating}{' '}
            years operating
          </p>
          <p>{vendor.description}</p>
          <p className="licence-note">{vendor.licenceNote}</p>
        </section>
      ) : null}

      <section className="detail-block" aria-labelledby="detail-trust">
        <h3 id="detail-trust">Provider trust</h3>
        <p>{TRUST_LABELS[trust]}</p>
        {reportOpen ? (
          <div>
            <label>
              Reason
              <select value={reason} onChange={(event) => setReason(event.target.value)}>
                {REPORT_REASONS.map((item) => (
                  <option key={item} value={item}>
                    {item}
                  </option>
                ))}
              </select>
            </label>{' '}
            <button type="button" className="secondary-button" onClick={handleSendReport}>
              Send report
            </button>
          </div>
        ) : (
          <button type="button" className="secondary-button" onClick={() => setReportOpen(true)}>
            Report listing
          </button>
        )}
      </section>

      <section className="detail-block" aria-labelledby="detail-feedback">
        <h3 id="detail-feedback">Community feedback</h3>
        {listing.feedback.length === 0 ? <p>No feedback yet.</p> : null}
        <ul className="feedback-list">
          {listing.feedback.map((item) => (
            <li key={`${item.name}-${item.when}`}>
              <p>
                <strong>{item.name}</strong> · {item.rating}/5 · <small>{item.when}</small>
              </p>
              <p>{item.comment}</p>
            </li>
          ))}
        </ul>
      </section>

      <ReceiverMatches listing={listing} />

      <p className="notice">{FOOD_NOTICE}</p>
    </div>
  );
}
