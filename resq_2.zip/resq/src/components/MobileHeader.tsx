import { NavLink } from 'react-router-dom';
import { useAppState } from '../context/AppStateContext';
import { navItemsFor } from '../lib/nav';
import { Brand } from './Brand';
import { LocationSelector } from './LocationSelector';
import { NotificationPanel } from './NotificationPanel';

export function MobileHeader() {
  const { role } = useAppState();
  return (
    <header className="app-header">
      <div className="app-header-row">
        <Brand />
        <div className="app-header-actions">
          <LocationSelector />
          <NotificationPanel />
        </div>
      </div>
      <nav className="header-tabs" aria-label="Sections">
        {navItemsFor(role).map((item) => (
          <NavLink key={item.to} to={item.to} className="header-tab">
            {item.label}
          </NavLink>
        ))}
      </nav>
    </header>
  );
}
