import type { Listing } from '../data/types';
import { useAppState } from '../context/AppStateContext';
import { formatClock, formatDistance, formatTimeLeft } from '../lib/time';

interface MarkerPreviewProps {
  listing: Listing;
  onViewDetails: (id: string) => void;
}

export function MarkerPreview({ listing, onViewDetails }: MarkerPreviewProps) {
  const { now } = useAppState();
  return (
    <article className="marker-preview" aria-live="polite">
      <p className="food-card-vendor">
        {listing.vendor} · {listing.area}
      </p>
      <h3 className="marker-preview-name">{listing.name}</h3>
      <dl className="marker-preview-meta">
        <div>
          <dt>Distance</dt>
          <dd>{formatDistance(listing.distanceKm)}</dd>
        </div>
        <div>
          <dt>Portions</dt>
          <dd>{listing.portionsRemaining} left</dd>
        </div>
        <div>
          <dt>Pickup by</dt>
          <dd>
            {formatClock(listing.pickupDeadline)} ({formatTimeLeft(listing.pickupDeadline, now)})
          </dd>
        </div>
      </dl>
      <button type="button" className="primary-button" onClick={() => onViewDetails(listing.id)}>
        View details
      </button>
    </article>
  );
}
