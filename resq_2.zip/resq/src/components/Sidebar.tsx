import { NavLink } from 'react-router-dom';
import { useAppState } from '../context/AppStateContext';
import { navItemsFor } from '../lib/nav';
import { Brand } from './Brand';
import { Icon } from './Icon';
import { ProfileChip } from './ProfileChip';
import { RoleSwitcher } from './RoleSwitcher';

export function Sidebar() {
  const { role } = useAppState();
  return (
    <aside className="sidebar" aria-label="Primary">
      <Brand />
      <nav className="sidebar-nav" aria-label="Main navigation">
        {navItemsFor(role).map((item) => (
          <NavLink key={item.to} to={item.to} end={item.end} className="sidebar-link">
            <Icon name={item.icon} />
            <span>{item.label}</span>
          </NavLink>
        ))}
      </nav>
      <div className="sidebar-footer">
        <RoleSwitcher />
        <ProfileChip />
      </div>
    </aside>
  );
}
