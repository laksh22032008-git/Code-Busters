import { useEffect, useRef, useState } from 'react';
import { AREAS, useAppState } from '../context/AppStateContext';

export function LocationSelector() {
  const { location, setLocation, showToast } = useAppState();
  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    function onPointerDown(event: MouseEvent) {
      if (rootRef.current && !rootRef.current.contains(event.target as Node)) {
        setOpen(false);
      }
    }
    function onKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape') setOpen(false);
    }
    document.addEventListener('mousedown', onPointerDown);
    document.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('mousedown', onPointerDown);
      document.removeEventListener('keydown', onKeyDown);
    };
  }, [open]);

  function choose(area: string) {
    setLocation(area);
    setOpen(false);
    showToast(`Showing food near ${area}`);
  }

  return (
    <div className="location" ref={rootRef}>
      <button
        type="button"
        className="location-button"
        aria-haspopup="true"
        aria-expanded={open}
        onClick={() => setOpen((value) => !value)}
      >
        <span className="location-label">Near</span>
        <span className="location-value">{location}</span>
      </button>
      {open ? (
        <div className="location-popover">
          <p className="location-title">Choose your area</p>
          <ul>
            {AREAS.map((area) => (
              <li key={area}>
                <button
                  type="button"
                  className="location-option"
                  aria-current={area === location ? 'true' : undefined}
                  onClick={() => choose(area)}
                >
                  {area}
                </button>
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </div>
  );
}
