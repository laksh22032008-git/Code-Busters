import { useState } from 'react';
import { useAppState } from '../context/AppStateContext';
import { PICKUP_STAGES, pickupTrailFor } from '../provider/store';
import type { ProviderListingRecord } from '../provider/types';
import '../styles/provider-ops.css';
import '../styles/pickup-tracker.css';

const CHECKLIST_ITEMS = [
  'Food checked: hot-held above 60°C or chilled as labelled',
  'Visual check: no spoilage, odour or pests',
  'Hard consumption cutoff noted: eat or discard by the listed deadline',
] as const;

/** Shows the stored time in en-IN format, or "--" when the data has no timestamp. */
function formatStageTime(stamp: string): string {
  if (stamp === '') return '--';
  const date = new Date(stamp);
  if (Number.isNaN(date.getTime())) return '--';
  return date.toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit' }).toUpperCase();
}

interface PickupTrackerProps {
  listingId: string;
}

/** Four-stage pickup stepper with a handover checklist at Collected and a demo-only Simulate button. */
export function PickupTracker({ listingId }: PickupTrackerProps) {
  const { provider, advancePickupStage } = useAppState();
  const [checked, setChecked] = useState<boolean[]>(() => CHECKLIST_ITEMS.map(() => false));

  const record: ProviderListingRecord | undefined = provider.listings.find((item) => item.id === listingId);
  const claims = provider.claims.filter((claim) => claim.listingId === listingId);
  const trail = pickupTrailFor(record, claims);
  const isDemo = record?.origin === 'sample';
  const allChecked = checked.every(Boolean);

  const advance = (): void => {
    const result = advancePickupStage(listingId);
    if (result.ok) setChecked(CHECKLIST_ITEMS.map(() => false));
  };

  const toggle = (index: number): void => {
    setChecked((prev) => prev.map((value, i) => (i === index ? !value : value)));
  };

  return (
    <section className="detail-block" aria-labelledby="detail-pickup">
      <h3 id="detail-pickup">Pickup progress</h3>
      <ol className="pickup-tracker" aria-label="Pickup progress">
        {PICKUP_STAGES.map((label, index) => {
          const state =
            trail.reached >= 3 || index < trail.reached
              ? 'is-done'
              : index === trail.reached
                ? 'is-current'
                : 'is-pending';
          return (
            <li key={label} className={`pickup-stage ${state}`} aria-current={state === 'is-current' ? 'step' : undefined}>
              <span className="pickup-stage-node" aria-hidden="true">
                {state === 'is-done' && (
                  <svg className="pickup-stage-check" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" focusable="false">
                    <path d="M20 6 9 17l-5-5" />
                  </svg>
                )}
              </span>
              <span className="pickup-stage-name">{label}</span>
              <span className="pickup-stage-time">{formatStageTime(trail.times[index] ?? '')}</span>
            </li>
          );
        })}
      </ol>

      {trail.reached === 2 && (
        <fieldset className="handover-checklist">
          <legend>Digital Handover Checklist</legend>
          {CHECKLIST_ITEMS.map((text, index) => (
            <label key={text} className="handover-check">
              <input type="checkbox" checked={checked[index] === true} onChange={() => toggle(index)} />
              <span>{text}</span>
            </label>
          ))}
          <button
            type="button"
            className="ops-button-solid"
            disabled={!allChecked}
            onClick={advance}
          >
            Mark delivered
          </button>
        </fieldset>
      )}

      {isDemo && (
        <button
          type="button"
          className="ops-button pickup-tracker-action"
          disabled={trail.reached >= 3}
          onClick={advance}
        >
          Simulate Next Stage
        </button>
      )}
    </section>
  );
}
