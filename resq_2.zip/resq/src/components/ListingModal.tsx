import { useEffect, useRef, useState } from 'react';
import { useAppState } from '../context/AppStateContext';
import { listingStatus, type ListingStatus } from '../lib/listingStatus';
import { MAX_PORTIONS_PER_CLAIM } from '../lib/reservation';
import { ClaimConfirmation } from './ClaimConfirmation';
import { ListingDetailSections, ListingSummary } from './ListingDetailSections';
import { Icon } from './Icon';

const rupees = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 });

const STATUS_TEXT: Record<ListingStatus, string> = {
  available: 'Available',
  'fully-reserved': 'Fully claimed',
  expired: 'This pickup window has closed',
  cancelled: 'This listing has been cancelled',
};

interface ListingModalProps {
  listingId: string;
}

export function ListingModal({ listingId }: ListingModalProps) {
  const { listings, now, saved, toggleSaved, closeListing, claimListing } = useAppState();
  const dialogRef = useRef<HTMLDivElement>(null);
  const submittingRef = useRef(false);
  const [quantity, setQuantity] = useState(1);
  const [submitting, setSubmitting] = useState(false);
  const [confirmed, setConfirmed] = useState(false);
  const [claimCode, setClaimCode] = useState('');
  const [claimedPortions, setClaimedPortions] = useState(1);
  const [claimError, setClaimError] = useState<string | null>(null);
  const listing = listings.find((item) => item.id === listingId);

  useEffect(() => {
    const trigger = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    dialogRef.current?.focus();
    function onKeyDown(event: KeyboardEvent) {
      if (event.key === 'Escape') closeListing();
    }
    document.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('keydown', onKeyDown);
      document.body.style.overflow = previousOverflow;
      trigger?.focus();
    };
  }, [closeListing]);

  if (!listing) return null;

  // mergeListings drops cancelled provider listings, so a listing reaching the modal is never cancelled.
  const status = listingStatus({
    cancelled: false,
    deadlineMs: Date.parse(listing.pickupDeadline),
    remaining: listing.portionsRemaining,
    now,
  });
  const isSaved = saved.has(listing.id);
  const maxPortions = Math.max(0, Math.min(listing.portionsRemaining, MAX_PORTIONS_PER_CLAIM));
  const portions = Math.max(1, Math.min(quantity, maxPortions));
  const total = listing.price === 0 ? 'Free' : rupees.format(listing.price * portions);

  function changeQuantity(next: number) {
    setQuantity(Math.max(1, Math.min(next, maxPortions)));
  }

  function claim() {
    if (submittingRef.current || status !== 'available') return;
    submittingRef.current = true;
    setSubmitting(true);
    const result = claimListing(listingId, portions);
    submittingRef.current = false;
    setSubmitting(false);
    if (result.ok) {
      setClaimCode(result.value?.code ?? '');
      setClaimedPortions(portions);
      setClaimError(null);
      setConfirmed(true);
    } else {
      setClaimError(result.error);
    }
  }

  return (
    <div className="modal-backdrop" onClick={closeListing}>
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="listing-modal-title"
        tabIndex={-1}
        className="modal"
        onClick={(event) => event.stopPropagation()}
      >
        <header className="modal-header">
          <p className="modal-vendor">{listing.vendor}</p>
          <button type="button" className="icon-button" aria-label="Close details" onClick={closeListing}>
            <Icon name="close" />
          </button>
        </header>

        <div className="modal-body">
          {confirmed ? (
            <ClaimConfirmation listing={listing} code={claimCode} portions={claimedPortions} />
          ) : (
            <>
              <div className="modal-columns">
                <div className="modal-media">
                  <img className="modal-image" src={listing.image} alt={`Illustration of ${listing.name}`} />
                  {listing.portionsRemaining <= 3 ? (
                    <span className="modal-pill">Only {listing.portionsRemaining} left</span>
                  ) : null}
                </div>
                <div className="modal-info">
                  <ListingSummary listing={listing} />
                  <div className="claim-picker">
                    <div className="claim-stepper">
                      <button
                        type="button"
                        aria-label="Fewer portions"
                        onClick={() => changeQuantity(portions - 1)}
                        disabled={portions <= 1}
                      >
                        −
                      </button>
                      <span className="claim-stepper-value" aria-live="polite">
                        {portions}
                      </span>
                      <button
                        type="button"
                        aria-label="More portions"
                        onClick={() => changeQuantity(portions + 1)}
                        disabled={portions >= maxPortions}
                      >
                        +
                      </button>
                    </div>
                    {maxPortions > 0 ? <p className="claim-helper">Choose 1 to {maxPortions} portions</p> : null}
                    <p className="claim-total">
                      <span>Total</span>
                      <strong>{total}</strong>
                    </p>
                    <p className="claim-status">{STATUS_TEXT[status]}</p>
                    {claimError ? (
                      <p role="alert" className="claim-error">
                        {claimError}
                      </p>
                    ) : null}
                  </div>
                  <button
                    type="button"
                    className="save-button save-button-wide"
                    aria-pressed={isSaved}
                    onClick={() => toggleSaved(listing.id)}
                  >
                    <Icon name="saved" />
                    <span>{isSaved ? 'Saved' : 'Save for later'}</span>
                  </button>
                </div>
              </div>
              <ListingDetailSections listing={listing} />
            </>
          )}
        </div>

        {confirmed ? null : (
          <footer className="modal-footer">
            <button
              type="button"
              className="primary-button modal-claim"
              onClick={claim}
              disabled={status !== 'available' || submitting}
            >
              {submitting ? 'Claiming…' : 'Claim food'}
            </button>
          </footer>
        )}
      </div>
    </div>
  );
}
