import '../styles/business-model.css';

export function BusinessModelSection() {
  return (
    <section className="business-section" aria-labelledby="business-model-heading">
      <h2 id="business-model-heading" className="business-heading">Business Model &amp; Partner Value</h2>
      <p className="business-intro">How ResQFood stays free for community kitchens while partners fund the rescue network.</p>
      <div className="business-grid">
        <article className="business-card">
          <h3>Why caterers use it weekly</h3>
          <ul>
            <li>Zero-cost listing for caterers</li>
            <li>15-second recurring menu templates</li>
            <li>Lower commercial waste-hauling fees</li>
            <li>Automated monthly Zero-Waste &amp; ESG Impact Reports to win corporate tech-park contracts</li>
          </ul>
        </article>
        <article className="business-card">
          <h3>Who pays</h3>
          <ul>
            <li><strong className="business-tier hl-pill hl-pill--mono">NGOs &amp; night shelters: ₹0 (free)</strong></li>
            <li><strong className="business-tier hl-pill hl-pill--mono">Corporate CSR &amp; ESG sponsors</strong> fund hyperlocal rescue zones in exchange for verified, auditable meal-rescue and Scope 3 emissions dashboards</li>
            <li><strong className="business-tier hl-pill hl-pill--mono">Enterprise caterers &amp; tech-park cafeterias</strong> pay a B2B SaaS subscription for overproduction waste analytics</li>
          </ul>
        </article>
        <article className="business-card">
          <h3>Last-mile reliability</h3>
          <ul>
            <li>Hybrid pickup: NGO volunteers and vans first</li>
            <li>Batches over 15 kg still unclaimed after 20 minutes trigger an automated hyperlocal 3PL delivery fallback (Porter or Borzo API)</li>
            <li>The fallback is funded by the CSR sponsor pool</li>
            <li className="business-planned">Planned integration. Not live in this demo.</li>
          </ul>
        </article>
      </div>
      <p className="business-note">Projections and percentages are planning assumptions for this demo, not guarantees. Nothing here is a tax, legal or certification claim.</p>
    </section>
  );
}
