import { PlaceholderPage } from './PlaceholderPage';

export function ProviderIntro() {
  return (
    <PlaceholderPage
      title="Provider dashboard"
      description="Restaurants and food businesses will list surplus food, set pickup windows and confirm handovers here."
      demoLabel="Preview listing flow"
      demoFeature="the provider listing flow"
    >
      <ul className="intro-list">
        <li>Create surplus listings with portions and pickup windows</li>
        <li>Describe preparation, storage and reheating for seekers</li>
        <li>Track handovers and feedback</li>
      </ul>
    </PlaceholderPage>
  );
}
