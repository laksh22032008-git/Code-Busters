import type { ReactNode } from 'react';
import { useAppState } from '../context/AppStateContext';

interface PlaceholderPageProps {
  title: string;
  description: string;
  demoLabel: string;
  demoFeature: string;
  children?: ReactNode;
}

export function PlaceholderPage({ title, description, demoLabel, demoFeature, children }: PlaceholderPageProps) {
  const { showToast } = useAppState();
  return (
    <section className="placeholder-page">
      <h1 className="page-title">{title}</h1>
      <p className="page-description">{description}</p>
      <p className="later-note">This feature is coming in a later release.</p>
      {children}
      <button
        type="button"
        className="primary-button"
        onClick={() => showToast(`Demo only: ${demoFeature} arrives in a later release`)}
      >
        {demoLabel}
      </button>
    </section>
  );
}
