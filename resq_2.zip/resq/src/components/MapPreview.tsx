import { Link } from 'react-router-dom';
import { useAppState } from '../context/AppStateContext';
import { MapView } from './MapView';

export function MapPreview() {
  const { listings } = useAppState();
  return (
    <section className="map-preview" aria-labelledby="map-preview-title">
      <div className="map-preview-head">
        <h2 id="map-preview-title">Explore on the map</h2>
        <Link to="/map" className="text-link">
          Open full map
        </Link>
      </div>
      <Link to="/map" className="map-preview-frame" aria-label="Open the full map">
        <MapView listings={listings.slice(0, 6)} selectedId={null} onSelect={() => undefined} />
      </Link>
    </section>
  );
}
