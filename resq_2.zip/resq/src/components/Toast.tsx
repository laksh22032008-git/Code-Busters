import type { ToastItem } from '../data/types';
import { Icon } from './Icon';

interface ToastProps {
  toast: ToastItem;
  onDismiss: (id: number) => void;
}

export function Toast({ toast, onDismiss }: ToastProps) {
  return (
    <div className="toast" role="status">
      <p className="toast-text">{toast.message}</p>
      <button
        type="button"
        className="toast-close"
        aria-label="Dismiss notification"
        onClick={() => onDismiss(toast.id)}
      >
        <Icon name="close" />
      </button>
    </div>
  );
}
