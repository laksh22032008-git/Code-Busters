import { NavLink } from 'react-router-dom';
import { useAppState } from '../context/AppStateContext';
import { navItemsFor } from '../lib/nav';
import { Icon } from './Icon';

export function BottomNav() {
  const { role } = useAppState();
  return (
    <nav className="bottom-nav" aria-label="Main navigation">
      {navItemsFor(role).map((item) => (
        <NavLink key={item.to} to={item.to} end={item.end} className="bottom-link">
          <Icon name={item.icon} />
          <span>{item.label}</span>
        </NavLink>
      ))}
    </nav>
  );
}
