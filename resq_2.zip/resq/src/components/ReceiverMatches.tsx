import type { Listing } from '../data/types';
import { rankReceivers } from '../lib/matchScore';

interface ReceiverMatchesProps {
  listing: Listing;
}

// The match score is computed in src/lib/matchScore.ts; this component only renders it.
export function ReceiverMatches({ listing }: ReceiverMatchesProps) {
  const ranked = rankReceivers(listing);

  return (
    <section className="detail-block" aria-labelledby="detail-matches">
      <h3 id="detail-matches">Ranked receivers</h3>
      <ul className="feedback-list">
        {ranked.map((receiver) => (
          <li key={receiver.id}>
            <p>
              <strong>{receiver.name}</strong>{' '}
              <span className="match-badge hl-pill hl-pill--mono">{receiver.match.score}% Match</span>
            </p>
            <p className="match-summary">{receiver.match.summary}</p>
          </li>
        ))}
      </ul>
      <p className="match-note">Score = distance 40 + capacity fit 35 + timing 25</p>
    </section>
  );
}
