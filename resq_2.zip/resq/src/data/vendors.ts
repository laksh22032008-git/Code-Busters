import type { Vendor } from './types';

/** Display name of the provider's own business (vendorId 'green-leaf'). */
export const PROVIDER_BUSINESS_NAME = 'Copper Carrot Catering';

export const vendors: Vendor[] = [
  {
    id: 'green-leaf',
    name: 'Copper Carrot Catering',
    description: 'Wedding and corporate caterer in Indiranagar. Plant-forward meals cooked in daily batches.',
    rating: 4.6,
    yearsOperating: 6,
    licenceNote: 'Synthetic demo profile. No licence or certification is claimed.',
  },
  {
    id: 'daily-bowl',
    name: 'Moonlit Ladle Corporate Meals',
    description: 'Corporate lunch caterer in Koramangala. Bowls and meal boxes built around protein and whole grains.',
    rating: 4.4,
    yearsOperating: 4,
    licenceNote: 'Synthetic demo profile. No licence or certification is claimed.',
  },
  {
    id: 'urban-tiffin',
    name: 'The Hungry Comet Events',
    description: 'Event caterer in Koramangala. Biryani and tiffins from a central commissary kitchen.',
    rating: 4.3,
    yearsOperating: 5,
    licenceNote: 'Synthetic demo profile. No licence or certification is claimed.',
  },
  {
    id: 'harvest-table',
    name: 'Willow Plate Weddings',
    description: 'Wedding caterer in Indiranagar. Seasonal thalis and bakery bags.',
    rating: 4.7,
    yearsOperating: 9,
    licenceNote: 'Synthetic demo profile. No licence or certification is claimed.',
  },
  {
    id: 'fresh-fork',
    name: 'Fig & Fern Catering',
    description: 'Corporate event caterer in Koramangala. Sandwiches, muffins and croissants baked each morning.',
    rating: 4.2,
    yearsOperating: 3,
    licenceNote: 'Synthetic demo profile. No licence or certification is claimed.',
  },
  {
    id: 'annapurna',
    name: 'Ember Spoon Wedding Kitchen',
    description: 'Wedding kitchen in Indiranagar. Rotis, dal and curry in generous family portions.',
    rating: 4.8,
    yearsOperating: 12,
    licenceNote: 'Synthetic demo profile. No licence or certification is claimed.',
  },
  {
    id: 'saffron-lane',
    name: 'Saffron Orbit Events',
    description: 'Event caterer in Koramangala. Rice dishes with a light spice profile, cooked fresh for dinner service.',
    rating: 4.5,
    yearsOperating: 7,
    licenceNote: 'Synthetic demo profile. No licence or certification is claimed.',
  },
  {
    id: 'mantra-millets',
    name: 'Mellow Millet Corporate',
    description: 'Corporate caterer in Indiranagar. Millet bowls and breakfast bites with a low-waste kitchen policy.',
    rating: 4.5,
    yearsOperating: 2,
    licenceNote: 'Synthetic demo profile. No licence or certification is claimed.',
  },
];

export function findVendor(id: string): Vendor | undefined {
  return vendors.find((vendor) => vendor.id === id);
}
