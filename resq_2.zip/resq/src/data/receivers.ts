export interface Receiver {
  id: string;
  name: string;
  area: string;
  distanceKm: number;
  neededKg: number;
  /** 24h clock "HH:mm". A time before 06:00 means after midnight. */
  closesAt: string;
}

export const receivers: Receiver[] = [
  { id: 'rc-4', name: 'Zone 4 Community Kitchen', area: 'Koramangala', distanceKm: 1.4, neededKg: 35, closesAt: '00:30' },
  { id: 'rc-2', name: 'Zone 2 Night Shelter', area: 'Indiranagar', distanceKm: 0.9, neededKg: 20, closesAt: '23:00' },
  { id: 'rc-7', name: 'Zone 7 Community Kitchen', area: 'Koramangala', distanceKm: 2.6, neededKg: 50, closesAt: '01:00' },
  { id: 'rc-5', name: 'Zone 5 Night Shelter', area: 'Indiranagar', distanceKm: 3.2, neededKg: 12, closesAt: '22:00' },
];
