export type Category = 'Meals' | 'Bakery' | 'Snacks';
export type FilterCategory = 'all' | 'free' | 'veg' | 'nonveg' | 'bakery' | 'meals' | 'available';
export type SortKey = 'distance' | 'urgency' | 'recommended';
export type Role = 'seeker' | 'provider' | 'admin';

export interface Handling {
  preparedAt: string;
  storage: string;
  reheating: string;
  providerNote: string;
}

export interface Feedback {
  name: string;
  rating: number;
  comment: string;
  when: string;
}

/** Moderation status. Absent on a vendor means 'trusted'. Never derived from ratings. */
export type TrustStatus = 'trusted' | 'under-review' | 'suspended';

export interface Vendor {
  id: string;
  name: string;
  description: string;
  rating: number;
  yearsOperating: number;
  licenceNote: string;
  /** Optional so existing vendor data still type-checks; absent means 'trusted'. */
  trustStatus?: TrustStatus;
}

export interface Listing {
  id: string;
  name: string;
  vendorId: string;
  vendor: string;
  area: string;
  distanceKm: number;
  portionsRemaining: number;
  portionsTotal: number;
  price: number;
  originalPrice: number;
  isVeg: boolean;
  category: Category;
  tags: string[];
  pickupStart: string;
  pickupDeadline: string;
  addedAt: string;
  image: string;
  /** Simulated map position: percent of map width (x) and height (y). */
  x: number;
  y: number;
  handling: Handling;
  allergens: string[];
  feedback: Feedback[];
}

/** Static template; timestamps are computed relative to now by getListings(). */
export interface ListingTemplate
  extends Omit<Listing, 'pickupStart' | 'pickupDeadline' | 'addedAt'> {
  startOffsetMin: number;
  deadlineOffsetMin: number;
  addedAgoMin: number;
}

export interface ToastItem {
  id: number;
  message: string;
}

