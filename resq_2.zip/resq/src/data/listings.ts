import type { Listing } from './types';
import { listingTemplates } from './listingTemplates';

export { vendors, findVendor } from './vendors';

const MINUTE_MS = 60_000;

/** Builds listings with pickup and added times relative to `now`, so the demo always looks live. */
export function getListings(now: number = Date.now()): Listing[] {
  return listingTemplates.map(
    ({ startOffsetMin, deadlineOffsetMin, addedAgoMin, ...rest }): Listing => ({
      ...rest,
      pickupStart: new Date(now + startOffsetMin * MINUTE_MS).toISOString(),
      pickupDeadline: new Date(now + deadlineOffsetMin * MINUTE_MS).toISOString(),
      addedAt: new Date(now - addedAgoMin * MINUTE_MS).toISOString(),
    }),
  );
}

