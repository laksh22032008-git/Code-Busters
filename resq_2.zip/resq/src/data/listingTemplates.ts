import type { ListingTemplate } from './types';

export const listingTemplates: ListingTemplate[] = [
  {
    id: 'l-pulao', name: 'Vegetable Pulao', vendorId: 'green-leaf', vendor: 'Copper Carrot Catering',
    area: 'Indiranagar', distanceKm: 0.8, portionsRemaining: 5, portionsTotal: 12, price: 0,
    originalPrice: 120, isVeg: true, category: 'Meals', tags: ['Hot meal', 'Rice', 'Wedding batch'],
    startOffsetMin: -30, deadlineOffsetMin: 40, addedAgoMin: 50, image: '/food/photos/pulao.jpg', x: 28, y: 34,
    handling: { preparedAt: 'Cooked at 11:30 AM (synthetic demo record)', storage: 'Hot-held above 60°C, then chilled within 2 hours', reheating: 'Reheat until steaming before eating', providerNote: 'Contains whole spices; no added colour.' },
    allergens: ['Nuts (may contain traces)'],
    feedback: [
      { name: 'Zone 4 Community Kitchen', rating: 5, comment: 'Fluffy rice and plenty of vegetables.', when: '2 hours ago' },
      { name: 'Zone 2 Night Shelter', rating: 4, comment: 'Good portion for dinner. Pickup was quick.', when: 'Yesterday' },
    ],
  },
  {
    id: 'l-paneer', name: 'Paneer Meal Box', vendorId: 'daily-bowl', vendor: 'Moonlit Ladle Corporate Meals',
    area: 'Koramangala', distanceKm: 1.6, portionsRemaining: 4, portionsTotal: 10, price: 0,
    originalPrice: 180, isVeg: true, category: 'Meals', tags: ['Protein', 'Corporate lunch', 'Boxed'],
    startOffsetMin: -20, deadlineOffsetMin: 120, addedAgoMin: 90, image: '/food/photos/paneer-meal.jpg', x: 52, y: 62,
    handling: { preparedAt: 'Packed at 1:00 PM after the lunch service', storage: 'Chilled until pickup', reheating: 'Eat within 4 hours or reheat thoroughly', providerNote: 'Paneer is made in-house on the same day.' },
    allergens: ['Milk', 'Gluten (wheat roti)'],
    feedback: [
      { name: 'Zone 1 Community Kitchen', rating: 5, comment: 'Lovely paneer and well sealed box.', when: '3 hours ago' },
      { name: 'Zone 6 Night Shelter', rating: 4, comment: 'Filling. Would take again.', when: '2 days ago' },
    ],
  },
  {
    id: 'l-biryani', name: 'Chicken Biryani Trays', vendorId: 'urban-tiffin', vendor: 'The Hungry Comet Events',
    area: 'Koramangala', distanceKm: 2.4, portionsRemaining: 2, portionsTotal: 8, price: 0,
    originalPrice: 220, isVeg: false, category: 'Meals', tags: ['Spiced', 'Biryani', 'Wedding batch'],
    startOffsetMin: -10, deadlineOffsetMin: 35, addedAgoMin: 60, image: '/food/photos/biryani.jpg', x: 70, y: 46,
    handling: { preparedAt: 'Dum-cooked at 6:00 PM (synthetic demo record)', storage: 'Hot-held above 60°C in the kitchen, then chilled', reheating: 'Reheat to piping hot before serving', providerNote: 'Bone-in chicken; check for bones.' },
    allergens: ['Milk (ghee)', 'Gluten (wheat-based marinade)'],
    feedback: [
      { name: 'Zone 3 Community Kitchen', rating: 5, comment: 'Aromatic and not too oily.', when: '1 hour ago' },
      { name: 'Zone 5 Night Shelter', rating: 4, comment: 'Generous rice portion.', when: 'Last week' },
    ],
  },
  {
    id: 'l-veg-biryani', name: 'Veg Biryani Trays', vendorId: 'saffron-lane', vendor: 'Saffron Orbit Events',
    area: 'Koramangala', distanceKm: 3.1, portionsRemaining: 7, portionsTotal: 10, price: 0,
    originalPrice: 150, isVeg: true, category: 'Meals', tags: ['Fragrant', 'Biryani', 'Dinner'],
    startOffsetMin: 0, deadlineOffsetMin: 200, addedAgoMin: 15, image: '/food/photos/veg-biryani.jpg', x: 40, y: 72,
    handling: { preparedAt: 'Cooked at 5:30 PM for dinner service', storage: 'Chilled after service', reheating: 'Reheat until steaming', providerNote: 'Made with onion and tomato base.' },
    allergens: ['Milk (ghee)', 'Cashew nuts'],
    feedback: [
      { name: 'Zone 4 Community Kitchen', rating: 5, comment: 'Very fragrant and well cooked.', when: '30 min ago' },
    ],
  },
  {
    id: 'l-chapati-curry', name: 'Rotis & Dal Curry', vendorId: 'annapurna', vendor: 'Ember Spoon Wedding Kitchen',
    area: 'Indiranagar', distanceKm: 4.2, portionsRemaining: 12, portionsTotal: 20, price: 0,
    originalPrice: 100, isVeg: true, category: 'Meals', tags: ['Free', 'Family pack', 'Home style'],
    startOffsetMin: -40, deadlineOffsetMin: 90, addedAgoMin: 120, image: '/food/photos/chapati-curry.jpg', x: 20, y: 80,
    handling: { preparedAt: 'Rotis rolled at 12:00 PM, dal cooked at 12:30 PM', storage: 'Hot-held above 60°C in insulated containers', reheating: 'Warm rotis briefly on a pan', providerNote: 'Family pack; sized for 2 to 3 people.' },
    allergens: ['Gluten (wheat)'],
    feedback: [
      { name: 'Zone 2 Community Kitchen', rating: 5, comment: 'Feels like home cooking. Great value.', when: '4 hours ago' },
      { name: 'Zone 7 Night Shelter', rating: 4, comment: 'Dal was a little mild, still good.', when: 'Yesterday' },
    ],
  },
  {
    id: 'l-rice-thali', name: 'Steamed Rice & Dal', vendorId: 'harvest-table', vendor: 'Willow Plate Weddings',
    area: 'Indiranagar', distanceKm: 5.8, portionsRemaining: 0, portionsTotal: 6, price: 0,
    originalPrice: 140, isVeg: true, category: 'Meals', tags: ['Thali', 'Seasonal', 'Lunch'],
    startOffsetMin: -60, deadlineOffsetMin: 180, addedAgoMin: 200, image: '/food/photos/rice-thali.jpg', x: 88, y: 20,
    handling: { preparedAt: 'Thali assembled at 12:15 PM', storage: 'Kept covered and chilled', reheating: 'Reheat rice and curries separately', providerNote: 'Seasonal menu; items change daily.' },
    allergens: ['Milk', 'Mustard'],
    feedback: [
      { name: 'Zone 1 Night Shelter', rating: 5, comment: 'Lots of variety in one thali.', when: '5 hours ago' },
    ],
  },
  {
    id: 'l-sandwich', name: 'Packed Meal Box (Sandwiches)', vendorId: 'fresh-fork', vendor: 'Fig & Fern Catering',
    area: 'Indiranagar', distanceKm: 1.1, portionsRemaining: 9, portionsTotal: 15, price: 0,
    originalPrice: 90, isVeg: true, category: 'Snacks', tags: ['Quick bite', 'Corporate event'],
    startOffsetMin: -5, deadlineOffsetMin: 55, addedAgoMin: 25, image: '/food/photos/sandwich.jpg', x: 33, y: 58,
    handling: { preparedAt: 'Assembled at 3:00 PM from morning prep', storage: 'Chilled', reheating: 'Eat cold; no reheating needed', providerNote: 'Bread baked the same morning.' },
    allergens: ['Gluten (bread)', 'Egg (mayonnaise)'],
    feedback: [
      { name: 'Zone 4 Community Kitchen', rating: 4, comment: 'Crisp vegetables, fresh bread.', when: '1 hour ago' },
    ],
  },
  {
    id: 'l-bakery-bag', name: 'Assorted Bakery Bag', vendorId: 'harvest-table', vendor: 'Willow Plate Weddings',
    area: 'Koramangala', distanceKm: 2.0, portionsRemaining: 6, portionsTotal: 9, price: 0,
    originalPrice: 110, isVeg: true, category: 'Bakery', tags: ['Bakery', 'Bread', 'Day-old'],
    startOffsetMin: -15, deadlineOffsetMin: 75, addedAgoMin: 40, image: '/food/photos/bakery.jpg', x: 47, y: 40,
    handling: { preparedAt: 'Baked at 7:00 AM', storage: 'Room temperature in paper bags', reheating: 'Toast bread lightly for best texture', providerNote: 'Bread is day-old; best eaten within 24 hours.' },
    allergens: ['Gluten', 'Milk', 'Egg'],
    feedback: [
      { name: 'Zone 3 Night Shelter', rating: 5, comment: 'Great bread for toast the next morning.', when: '2 hours ago' },
    ],
  },
  {
    id: 'l-croissant-muffin', name: 'Muffins & Croissants', vendorId: 'fresh-fork', vendor: 'Fig & Fern Catering',
    area: 'Koramangala', distanceKm: 3.6, portionsRemaining: 3, portionsTotal: 8, price: 0,
    originalPrice: 120, isVeg: true, category: 'Bakery', tags: ['Bakery', 'Sweet', 'Breakfast'],
    startOffsetMin: -30, deadlineOffsetMin: 28, addedAgoMin: 95, image: '/food/photos/croissant.jpg', x: 60, y: 82,
    handling: { preparedAt: 'Baked at 6:30 AM', storage: 'Kept in a closed display case', reheating: 'Warm croissants for 2 minutes in an oven', providerNote: 'Contains dark chocolate and almond.' },
    allergens: ['Gluten', 'Milk', 'Egg', 'Almond', 'Soy'],
    feedback: [
      { name: 'Zone 6 Community Kitchen', rating: 4, comment: 'Muffins were moist. Croissant slightly stale.', when: '3 hours ago' },
    ],
  },
  {
    id: 'l-idli-dosa', name: 'Idli Sambar & Dosa', vendorId: 'green-leaf', vendor: 'Copper Carrot Catering',
    area: 'Indiranagar', distanceKm: 4.8, portionsRemaining: 10, portionsTotal: 14, price: 0,
    originalPrice: 60, isVeg: true, category: 'Snacks', tags: ['Breakfast', 'South Indian'],
    startOffsetMin: -10, deadlineOffsetMin: 95, addedAgoMin: 35, image: '/food/photos/idli-dosa.jpg', x: 14, y: 52,
    handling: { preparedAt: 'Idli steamed at 8:00 AM, dosa batter fermented overnight', storage: 'Chilled in sealed containers', reheating: 'Steam idli for 2 minutes before eating', providerNote: 'Sambar prepared fresh each morning.' },
    allergens: ['Gluten (urad dal blend)', 'Mustard'],
    feedback: [
      { name: 'Zone 5 Community Kitchen', rating: 5, comment: 'Soft idlis and good chutney.', when: '6 hours ago' },
    ],
  },
  {
    id: 'l-millet-bowl', name: 'Millet Bowl', vendorId: 'mantra-millets', vendor: 'Mellow Millet Corporate',
    area: 'Indiranagar', distanceKm: 0.4, portionsRemaining: 4, portionsTotal: 10, price: 0,
    originalPrice: 130, isVeg: true, category: 'Meals', tags: ['Millet', 'Healthy', 'Bowl'],
    startOffsetMin: -5, deadlineOffsetMin: 30, addedAgoMin: 70, image: '/food/photos/millet-bowl.jpg', x: 36, y: 24,
    handling: { preparedAt: 'Cooked at 11:00 AM with ragi and foxtail millet', storage: 'Chilled after service', reheating: 'Eat cold or warm gently', providerNote: 'Bowls packed to order.' },
    allergens: ['Sesame', 'Peanut (may contain)'],
    feedback: [
      { name: 'Zone 2 Night Shelter', rating: 5, comment: 'Filling and tasty. Loved the greens.', when: '50 min ago' },
    ],
  },
  {
    id: 'l-chicken-wrap', name: 'Chicken Wrap Bundle', vendorId: 'urban-tiffin', vendor: 'The Hungry Comet Events',
    area: 'Koramangala', distanceKm: 1.9, portionsRemaining: 8, portionsTotal: 12, price: 0,
    originalPrice: 95, isVeg: false, category: 'Snacks', tags: ['Wrap', 'Protein', 'Evening'],
    startOffsetMin: -25, deadlineOffsetMin: 140, addedAgoMin: 10, image: '/food/photos/chicken-wrap.jpg', x: 55, y: 52,
    handling: { preparedAt: 'Grilled at 4:30 PM', storage: 'Chilled in wrapped sleeves', reheating: 'Eat within 3 hours; do not reheat in foil', providerNote: 'Synthetic demo record; sourcing not verified.' },
    allergens: ['Gluten (tortilla)', 'Milk (sauce)', 'Egg'],
    feedback: [
      { name: 'Zone 1 Night Shelter', rating: 4, comment: 'Good wrap for a quick dinner.', when: '20 min ago' },
    ],
  },
];
