import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { AppShell } from './components/AppShell';
import { AppStateProvider } from './context/AppStateContext';
import { DiscoverPage } from './pages/DiscoverPage';
import { MapPage } from './pages/MapPage';
import { ReservationsPage } from './pages/ReservationsPage';
import { SavedPage } from './pages/SavedPage';
import { ProfilePage } from './pages/ProfilePage';
import { ProviderOverviewPage } from './pages/ProviderOverviewPage';
import { ProviderListingsPage } from './pages/ProviderListingsPage';
import { ProviderPickupsPage } from './pages/ProviderPickupsPage';
import { ProviderImpactPage } from './pages/ProviderImpactPage';
import { ProviderProfilePage } from './pages/ProviderProfilePage';
import { AdminPage } from './pages/AdminPage';
import { NotFoundPage } from './pages/NotFoundPage';

export function App() {
  return (
    <BrowserRouter>
      <AppStateProvider>
        <Routes>
          <Route element={<AppShell />}>
            <Route path="/" element={<Navigate to="/discover" replace />} />
            <Route path="/discover" element={<DiscoverPage />} />
            <Route path="/map" element={<MapPage />} />
            <Route path="/reservations" element={<ReservationsPage />} />
            <Route path="/saved" element={<SavedPage />} />
            <Route path="/profile" element={<ProfilePage />} />
            <Route path="/provider" element={<ProviderOverviewPage />} />
            <Route path="/provider/listings" element={<ProviderListingsPage />} />
            <Route path="/provider/pickups" element={<ProviderPickupsPage />} />
            <Route path="/provider/impact" element={<ProviderImpactPage />} />
            <Route path="/provider/profile" element={<ProviderProfilePage />} />
            <Route path="/admin" element={<AdminPage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Route>
        </Routes>
      </AppStateProvider>
    </BrowserRouter>
  );
}
