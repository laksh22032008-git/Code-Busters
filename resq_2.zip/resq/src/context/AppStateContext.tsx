import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import type { FilterCategory, Listing, Role, SortKey, ToastItem } from '../data/types';
import { getListings } from '../data/listings';
import * as providerStore from '../provider/store';
import { useProviderState } from '../provider/useProviderState';
import type {
  ListingReport,
  PickupClaim,
  PostListingInput,
  ProviderListingRecord,
  ProviderState,
  ReservationView,
  Result,
} from '../provider/types';
import { DEMO_SEEKER_ID } from '../provider/types';
import type { AppNotification } from '../lib/notifications';

export const AREAS = ['Indiranagar', 'Koramangala', 'HSR Layout', 'Jayanagar', 'Whitefield', 'Malleshwaram'];

const SAVED_KEY = 'resqfood.saved';
const ROLE_KEY = 'resqfood.role';
const DEFAULT_LOCATION = 'Indiranagar';
const DEFAULT_COLLECTOR = 'Demo seeker';
const TOAST_MS = 3200;
const TICK_MS = 30_000;
const EXPIRY_CHECK_MS = 60_000;

export interface AppStateValue {
  listings: Listing[];
  now: number;
  saved: Set<string>;
  toggleSaved: (id: string) => void;
  category: FilterCategory;
  setCategory: (category: FilterCategory) => void;
  query: string;
  setQuery: (query: string) => void;
  availableOnly: boolean;
  setAvailableOnly: (value: boolean) => void;
  sort: SortKey;
  setSort: (sort: SortKey) => void;
  selectedListingId: string | null;
  openListing: (id: string) => void;
  closeListing: () => void;
  role: Role;
  setRole: (role: Role) => void;
  location: string;
  setLocation: (location: string) => void;
  toasts: ToastItem[];
  showToast: (message: string) => void;
  dismissToast: (id: number) => void;
  notificationsOpen: boolean;
  setNotificationsOpen: (open: boolean) => void;
  provider: ProviderState;
  reservations: ReservationView[];
  /** Notifications from real events, newest first. */
  notifications: AppNotification[];
  postListing: (input: PostListingInput) => Result<ProviderListingRecord>;
  updateListing: (id: string, patch: object) => Result;
  cancelListing: (id: string, reason?: string) => Result;
  markUnavailable: (id: string) => Result;
  claimListing: (listingId: string, portions: number, collectorName?: string) => Result<PickupClaim>;
  markClaimReady: (claimId: string) => Result;
  confirmPickup: (claimId: string, code: string) => Result;
  reportListing: (listingId: string, reason: string) => Result<ListingReport>;
  advancePickupStage: (listingId: string) => Result;
  cancelClaim: (claimId: string) => Result;
  deleteListing: (id: string) => Result;
  removeReservation: (claimId: string) => Result;
  updateProfile: (patch: object) => Result;
  resetProviderDemo: () => void;
}

const AppStateContext = createContext<AppStateValue | null>(null);

function readSaved(): string[] {
  try {
    const raw = window.localStorage.getItem(SAVED_KEY);
    const parsed: unknown = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed.filter((v): v is string => typeof v === 'string') : [];
  } catch {
    return [];
  }
}

function readRole(): Role {
  const raw = window.localStorage.getItem(ROLE_KEY);
  return raw === 'provider' || raw === 'admin' ? raw : 'seeker';
}

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [saved, setSaved] = useState<Set<string>>(() => new Set(readSaved()));
  const [category, setCategory] = useState<FilterCategory>('all');
  const [query, setQuery] = useState('');
  const [availableOnly, setAvailableOnly] = useState(false);
  const [sort, setSort] = useState<SortKey>('recommended');
  const [selectedListingId, setSelectedListingId] = useState<string | null>(null);
  const [role, setRoleState] = useState<Role>(readRole);
  const [location, setLocation] = useState(DEFAULT_LOCATION);
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [now, setNow] = useState(() => Date.now());
  const toastSeq = useRef(0);
  const { provider, commit, getLatest } = useProviderState();

  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), TICK_MS);
    return () => window.clearInterval(id);
  }, []);

  // Records expiry notices once on mount, then every 60 seconds. Commits only when something new was added.
  useEffect(() => {
    const checkExpiry = () => {
      const at = Date.now();
      const latest = getLatest();
      const next = providerStore.expiryNotifications(latest, at, getListings(at));
      if (next !== latest) commit(next);
    };
    checkExpiry();
    const id = window.setInterval(checkExpiry, EXPIRY_CHECK_MS);
    return () => window.clearInterval(id);
  }, [commit, getLatest]);

  useEffect(() => {
    window.localStorage.setItem(SAVED_KEY, JSON.stringify([...saved]));
  }, [saved]);

  const listings = useMemo(() => providerStore.mergeListings(getListings(now), provider, now), [now, provider]);
  const reservations = useMemo(
    () => providerStore.reservationsFor(provider, DEMO_SEEKER_ID, getListings(now), now),
    [provider, now, listings],
  );
  const notifications = useMemo(() => [...(provider.notifications ?? [])].reverse(), [provider.notifications]);

  const toggleSaved = useCallback((id: string) => {
    setSaved((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const setRole = useCallback((next: Role) => {
    setRoleState(next);
    window.localStorage.setItem(ROLE_KEY, next);
  }, []);

  const dismissToast = useCallback((id: number) => {
    setToasts((prev) => prev.filter((toast) => toast.id !== id));
  }, []);

  const showToast = useCallback(
    (message: string) => {
      toastSeq.current += 1;
      const id = toastSeq.current;
      setToasts((prev) => [...prev, { id, message }]);
      window.setTimeout(() => dismissToast(id), TOAST_MS);
    },
    [dismissToast],
  );

  const openListing = useCallback((id: string) => setSelectedListingId(id), []);
  const closeListing = useCallback(() => setSelectedListingId(null), []);

  // Applies a pure provider result: commits state on success, toasts either way.
  // A failure commits only when it carries a state (e.g. a saved wrong-code count).
  const settle = useCallback(
    <T,>(result: Result<T>, successMessage: string): Result<T> => {
      if (result.ok) {
        commit(result.state);
        showToast(successMessage);
      } else {
        if (result.state) commit(result.state);
        showToast(result.error);
      }
      return result;
    },
    [commit, showToast],
  );

  const postListing = useCallback(
    (input: PostListingInput) =>
      settle(providerStore.postListing(getLatest(), input, Date.now()), 'Listing posted to the feed'),
    [getLatest, settle],
  );
  const updateListing = useCallback(
    (id: string, patch: object) =>
      settle(providerStore.updateListing(getLatest(), id, patch, Date.now()), 'Listing updated'),
    [getLatest, settle],
  );
  const cancelListing = useCallback(
    (id: string, reason = '') =>
      settle(providerStore.cancelListing(getLatest(), id, reason, Date.now()), 'Listing cancelled'),
    [getLatest, settle],
  );
  const markUnavailable = useCallback(
    (id: string) => settle(providerStore.markUnavailable(getLatest(), id, Date.now()), 'Listing marked unavailable'),
    [getLatest, settle],
  );
  const claimListing = useCallback(
    (listingId: string, portions: number, collectorName = DEFAULT_COLLECTOR) => {
      const at = Date.now();
      return settle(
        providerStore.claimListing(getLatest(), getListings(at), listingId, portions, collectorName, at),
        'Pickup reserved (demo)',
      );
    },
    [getLatest, settle],
  );
  const markClaimReady = useCallback(
    (claimId: string) => settle(providerStore.markClaimReady(getLatest(), claimId, Date.now()), 'Pickup marked ready'),
    [getLatest, settle],
  );
  const confirmPickup = useCallback(
    (claimId: string, code: string) => {
      const at = Date.now();
      return settle(
        providerStore.confirmPickup(getLatest(), claimId, code, at, getListings(at)),
        'Pickup confirmed',
      );
    },
    [getLatest, settle],
  );
  const reportListing = useCallback(
    (listingId: string, reason: string) => {
      const at = Date.now();
      return settle(
        providerStore.reportListing(getLatest(), getListings(at), listingId, reason, at),
        'Report sent. Thank you for helping keep ResQFood safe.',
      );
    },
    [getLatest, settle],
  );
  const advancePickupStage = useCallback(
    (listingId: string) => {
      const at = Date.now();
      return settle(
        providerStore.advancePickupStage(getLatest(), getListings(at), listingId, at),
        'Pickup stage advanced (demo)',
      );
    },
    [getLatest, settle],
  );
  const cancelClaim = useCallback(
    (claimId: string) =>
      settle(
        providerStore.cancelClaim(getLatest(), claimId, getListings(Date.now()), Date.now()),
        'Reservation cancelled',
      ),
    [getLatest, settle],
  );
  const deleteListing = useCallback(
    (id: string) =>
      settle(
        providerStore.deleteListing(getLatest(), id, getListings(Date.now()), Date.now()),
        'Expired listing deleted',
      ),
    [getLatest, settle],
  );
  const removeReservation = useCallback(
    (claimId: string) =>
      settle(
        providerStore.removeReservation(getLatest(), claimId, getListings(Date.now()), Date.now()),
        'Reservation removed from your list',
      ),
    [getLatest, settle],
  );
  const updateProfile = useCallback(
    (patch: object) => settle(providerStore.updateProfile(getLatest(), patch), 'Business profile saved'),
    [getLatest, settle],
  );
  const resetProviderDemo = useCallback(() => {
    commit(providerStore.seedProviderState(Date.now()));
    showToast('Provider demo reset');
  }, [commit, showToast]);

  const value = useMemo<AppStateValue>(
    () => ({
      listings,
      now,
      saved,
      toggleSaved,
      category,
      setCategory,
      query,
      setQuery,
      availableOnly,
      setAvailableOnly,
      sort,
      setSort,
      selectedListingId,
      openListing,
      closeListing,
      role,
      setRole,
      location,
      setLocation,
      toasts,
      showToast,
      dismissToast,
      notificationsOpen,
      setNotificationsOpen,
      provider,
      reservations,
      notifications,
      postListing,
      updateListing,
      cancelListing,
      markUnavailable,
      claimListing,
      markClaimReady,
      confirmPickup,
      reportListing,
      advancePickupStage,
      cancelClaim,
      deleteListing,
      removeReservation,
      updateProfile,
      resetProviderDemo,
    }),
    [
      listings, now, saved, toggleSaved, category, query, availableOnly, sort,
      selectedListingId, openListing, closeListing, role, setRole, location,
      toasts, showToast, dismissToast, notificationsOpen, provider, reservations, notifications, postListing,
      updateListing, cancelListing, markUnavailable, claimListing, markClaimReady,
      confirmPickup, reportListing, advancePickupStage, cancelClaim, deleteListing, removeReservation, updateProfile, resetProviderDemo,
    ],
  );

  return <AppStateContext.Provider value={value}>{children}</AppStateContext.Provider>;
}

export function useAppState(): AppStateValue {
  const ctx = useContext(AppStateContext);
  if (!ctx) throw new Error('useAppState must be used inside AppStateProvider');
  return ctx;
}
