# Photo attribution

slug | file | Commons page | author | licence

paneer-meal | paneer-meal.jpg | https://commons.wikimedia.org/wiki/File:Paneer_Curry_with_Rice.jpg | UserWiki | CC BY-SA 4.0
croissant | croissant.jpg | https://commons.wikimedia.org/wiki/File:Croissant_with_jam_and_butter_-_Little_Miss_Piggies.jpg | Andy Li | CC0
chicken-wrap | chicken-wrap.jpg | https://commons.wikimedia.org/wiki/File:Handmade_Chicken_Shawarma_Wrap_-_Lavash.jpg | Andy Li | CC0
millet-bowl | millet-bowl.jpg | https://commons.wikimedia.org/wiki/File:Smokey_Millet_Super_Grain_Bowl_With_Crispy_Tofu.jpg | Simmer + Sauce | CC BY 3.0
pulao | pulao.jpg | https://commons.wikimedia.org/wiki/File:VEGETABLE_PULAO_~_An_Indian_cuisine_made_from_fried_rice_mixed_with_fried_vegetables.jpg | Jagisnowjughead | CC BY-SA 4.0
veg-biryani | veg-biryani.jpg | https://commons.wikimedia.org/wiki/File:Vegetable_Biryani_IMG_001.jpg | Phadke09 | CC BY-SA 4.0
biryani | biryani.jpg | https://commons.wikimedia.org/wiki/File:A_home_made_plate_of_mutton_biryani_served_with_chicken_kassa_cooked_in_the_bengali_style.jpg | Subhrajyoti07 | CC BY-SA 4.0
chapati-curry | chapati-curry.jpg | https://commons.wikimedia.org/wiki/File:Roti_with_Dhal_and_Chicken_Curry_Sauce,_Chicken_Curry_Puff_-_Rich_Maha_AUD4,_AUD2_(4635003943).jpg | Alpha from Melbourne, Australia | CC BY-SA 2.0
rice-thali | rice-thali.jpg | https://commons.wikimedia.org/wiki/File:South_Indian_thali-Saravana_bhawan-New_Delhi-6.jpg | Siva301in | CC BY-SA 4.0
sandwich | sandwich.jpg | https://commons.wikimedia.org/wiki/File:Fried_shrimp_sandwich_with_rice_and_beans.jpg | FranHogan | CC BY-SA 4.0
bakery | bakery.jpg | https://commons.wikimedia.org/wiki/File:Loaves_of_Bread_(Unsplash).jpg | Clark Young clark1 | CC0
idli-dosa | idli-dosa.jpg | https://commons.wikimedia.org/wiki/File:Idli_Dosa_with_sambar.jpg | Anugya..Chidar | CC BY-SA 4.0
